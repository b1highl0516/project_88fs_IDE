// ═══════════════════════════════════════════════════════════════════════════
// 路由定義 - Route Definitions
// ═══════════════════════════════════════════════════════════════════════════

import { RouteDefinition } from '../router';
import EditorView from '../views/EditorView';
import SettingsView from '../views/SettingsView';
import AIWorkspaceView from '../views/AIWorkspaceView';
import FileDetailView from '../views/FileDetailView';
import WelcomeView from '../views/WelcomeView';
import RoutingDemoView from '../views/RoutingDemoView';
import RouteAnalysisView from '../views/RouteAnalysisView';
import QuickSetupView from '../views/QuickSetupView';

export const routes: RouteDefinition[] = [
  {
    path: '/',
    component: WelcomeView,
    title: 'Welcome',
    meta: { layout: 'default', breadcrumb: 'Home' },
  },
  {
    path: '/editor',
    component: EditorView,
    title: 'Editor',
    meta: { layout: 'default', breadcrumb: 'Editor' },
  },
  {
    path: '/editor/:fileId',
    component: FileDetailView,
    title: 'File',
    meta: { layout: 'default', breadcrumb: 'File Detail' },
  },
  {
    path: '/ai',
    component: AIWorkspaceView,
    title: 'AI Workspace',
    meta: { layout: 'default', breadcrumb: 'AI Workspace' },
  },
  {
    path: '/ai/:sessionId',
    component: AIWorkspaceView,
    title: 'AI Session',
    meta: { layout: 'default', breadcrumb: 'AI Session' },
  },
  {
    path: '/settings',
    component: SettingsView,
    title: 'Settings',
    meta: { layout: 'minimal', breadcrumb: 'Settings' },
  },
  {
    path: '/settings/:section',
    component: SettingsView,
    title: 'Settings',
    meta: { layout: 'minimal', breadcrumb: 'Settings Section' },
  },
  {
    path: '/routing',
    component: RoutingDemoView,
    title: 'Routing Demo',
    meta: { layout: 'default', breadcrumb: 'Routing Demo' },
  },
  {
    path: '/analysis',
    component: RouteAnalysisView,
    title: 'Route Analysis',
    meta: { layout: 'full', breadcrumb: 'Performance Analysis' },
  },
  {
    path: '/setup',
    component: QuickSetupView,
    title: 'Quick Setup',
    meta: { layout: 'full', breadcrumb: 'API Key Setup' },
  },
];

export default routes;

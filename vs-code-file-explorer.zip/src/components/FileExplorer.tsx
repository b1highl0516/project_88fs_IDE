import { useState, useCallback, useRef, useEffect } from 'react';
import { FileNode, ContextMenuAction, ContextMenuPosition } from '../types';
import { fileTree } from '../data';
import TreeNode from './TreeNode';
import ContextMenu from './ContextMenu';
import FileIcon from './FileIcon';

// Flatten tree for shift-select
function flattenTree(nodes: FileNode[], expandedFolders: Set<string>): FileNode[] {
  const result: FileNode[] = [];
  const sortedNodes = [...nodes].sort((a, b) => {
    if (a.type !== b.type) return a.type === 'folder' ? -1 : 1;
    return a.name.localeCompare(b.name);
  });

  for (const node of sortedNodes) {
    result.push(node);
    if (node.type === 'folder' && expandedFolders.has(node.id) && node.children) {
      result.push(...flattenTree(node.children, expandedFolders));
    }
  }
  return result;
}

function SearchIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
      <circle cx="7" cy="7" r="4.5" stroke="#cccccc" strokeWidth="1.2" />
      <line x1="10.5" y1="10.5" x2="14" y2="14" stroke="#cccccc" strokeWidth="1.2" strokeLinecap="round" />
    </svg>
  );
}

function CollapseAllIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
      <path d="M9 3L5 7L9 11" stroke="#cccccc" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M14 1V15" stroke="#cccccc" strokeWidth="1.2" strokeLinecap="round" />
    </svg>
  );
}

function NewFileIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
      <path d="M4 1.5H10L13 4.5V14C13 14.3 12.7 14.5 12.5 14.5H4C3.7 14.5 3.5 14.3 3.5 14V2C3.5 1.7 3.7 1.5 4 1.5Z" stroke="#cccccc" strokeWidth="1" fill="none" />
      <path d="M10 1.5V4.5H13" stroke="#cccccc" strokeWidth="1" fill="none" />
      <line x1="8" y1="7" x2="8" y2="12" stroke="#cccccc" strokeWidth="1.2" strokeLinecap="round" />
      <line x1="5.5" y1="9.5" x2="10.5" y2="9.5" stroke="#cccccc" strokeWidth="1.2" strokeLinecap="round" />
    </svg>
  );
}

function NewFolderIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
      <path d="M1.5 3C1.5 2.4 2 2 2.5 2H6.5L8 4H13.5C14 4 14.5 4.4 14.5 5V12C14.5 12.6 14 13 13.5 13H2.5C2 13 1.5 12.6 1.5 12V3Z" stroke="#cccccc" strokeWidth="1" fill="none" />
      <line x1="8" y1="6" x2="8" y2="11" stroke="#cccccc" strokeWidth="1.2" strokeLinecap="round" />
      <line x1="5.5" y1="8.5" x2="10.5" y2="8.5" stroke="#cccccc" strokeWidth="1.2" strokeLinecap="round" />
    </svg>
  );
}

function RefreshIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
      <path d="M13 8A5 5 0 1 1 8 3" stroke="#cccccc" strokeWidth="1.2" strokeLinecap="round" />
      <path d="M8 1L11 3L8 5" stroke="#cccccc" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" fill="none" />
    </svg>
  );
}

export default function FileExplorer() {
  const [tree, setTree] = useState<FileNode[]>(fileTree);
  const [expandedFolders, setExpandedFolders] = useState<Set<string>>(new Set(['1']));
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [lastSelectedId, setLastSelectedId] = useState<string | null>(null);
  const [contextMenu, setContextMenu] = useState<{
    position: ContextMenuPosition;
    node: FileNode | null;
  } | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [showSearch, setShowSearch] = useState(false);
  const [notification, setNotification] = useState<string | null>(null);
  const [renaming, setRenaming] = useState<string | null>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);
  const explorerRef = useRef<HTMLDivElement>(null);

  const showNotification = useCallback((msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 2500);
  }, []);

  const flatNodes = flattenTree(tree, expandedFolders);

  const toggleFolder = useCallback((id: string) => {
    setExpandedFolders((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  }, []);

  const handleSelect = useCallback(
    (id: string, e: React.MouseEvent) => {
      if (e.shiftKey && lastSelectedId) {
        // Shift-click: select range
        const flatIds = flatNodes.map((n) => n.id);
        const startIdx = flatIds.indexOf(lastSelectedId);
        const endIdx = flatIds.indexOf(id);
        if (startIdx !== -1 && endIdx !== -1) {
          const [from, to] = startIdx < endIdx ? [startIdx, endIdx] : [endIdx, startIdx];
          const rangeIds = flatIds.slice(from, to + 1);
          setSelectedIds((prev) => {
            const next = new Set(prev);
            rangeIds.forEach((rid) => next.add(rid));
            return next;
          });
        }
      } else if (e.ctrlKey || e.metaKey) {
        // Ctrl/Cmd-click: toggle individual
        setSelectedIds((prev) => {
          const next = new Set(prev);
          if (next.has(id)) {
            next.delete(id);
          } else {
            next.add(id);
          }
          return next;
        });
        setLastSelectedId(id);
      } else {
        // Normal click: single select
        setSelectedIds(new Set([id]));
        setLastSelectedId(id);
      }
    },
    [lastSelectedId, flatNodes]
  );

  const handleContextMenu = useCallback(
    (e: React.MouseEvent, node: FileNode) => {
      // If node is not in selection, select it alone
      if (!selectedIds.has(node.id)) {
        setSelectedIds(new Set([node.id]));
        setLastSelectedId(node.id);
      }
      setContextMenu({
        position: { x: e.clientX, y: e.clientY },
        node,
      });
    },
    [selectedIds]
  );

  const closeContextMenu = useCallback(() => {
    setContextMenu(null);
  }, []);

  const handleBackgroundClick = useCallback(() => {
    setSelectedIds(new Set());
    setLastSelectedId(null);
  }, []);

  const handleBackgroundContextMenu = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    setContextMenu({
      position: { x: e.clientX, y: e.clientY },
      node: null,
    });
  }, []);

  const collapseAll = useCallback(() => {
    setExpandedFolders(new Set());
  }, []);

  const expandAll = useCallback(() => {
    const allFolderIds = new Set<string>();
    const collect = (nodes: FileNode[]) => {
      for (const n of nodes) {
        if (n.type === 'folder') {
          allFolderIds.add(n.id);
          if (n.children) collect(n.children);
        }
      }
    };
    collect(tree);
    setExpandedFolders(allFolderIds);
  }, [tree]);

  // Delete selected node(s) from tree
  const deleteNodes = useCallback((ids: Set<string>) => {
    const removeFromTree = (nodes: FileNode[]): FileNode[] => {
      return nodes
        .filter((n) => !ids.has(n.id))
        .map((n) => ({
          ...n,
          children: n.children ? removeFromTree(n.children) : undefined,
        }));
    };
    setTree((prev) => removeFromTree(prev));
    setSelectedIds(new Set());
    showNotification(`Deleted ${ids.size} item${ids.size > 1 ? 's' : ''}`);
  }, [showNotification]);

  // Find node by ID
  const findNode = useCallback((nodes: FileNode[], id: string): FileNode | null => {
    for (const n of nodes) {
      if (n.id === id) return n;
      if (n.children) {
        const found = findNode(n.children, id);
        if (found) return found;
      }
    }
    return null;
  }, []);

  // Duplicate node
  const duplicateNode = useCallback((id: string) => {
    const addDuplicate = (nodes: FileNode[]): FileNode[] => {
      const result: FileNode[] = [];
      for (const n of nodes) {
        result.push({
          ...n,
          children: n.children ? addDuplicate(n.children) : undefined,
        });
        if (n.id === id) {
          const suffix = n.type === 'file' ? ' copy' : ' copy';
          const nameWithoutExt = n.name.lastIndexOf('.') > 0
            ? n.name.substring(0, n.name.lastIndexOf('.'))
            : n.name;
          const ext = n.name.lastIndexOf('.') > 0
            ? n.name.substring(n.name.lastIndexOf('.'))
            : '';
          const dupNode: FileNode = {
            ...n,
            id: n.id + '-dup-' + Date.now(),
            name: nameWithoutExt + suffix + ext,
            children: n.children ? JSON.parse(JSON.stringify(n.children)) : undefined,
          };
          result.push(dupNode);
        }
      }
      return result;
    };
    setTree((prev) => addDuplicate(prev));
    showNotification('Item duplicated');
  }, [showNotification]);

  // Add new file/folder
  const addNewItem = useCallback((parentId: string | null, type: 'file' | 'folder') => {
    const newId = 'new-' + Date.now();
    const newNode: FileNode = {
      id: newId,
      name: type === 'file' ? 'untitled' : 'new-folder',
      type,
      extension: type === 'file' ? 'ts' : undefined,
      children: type === 'folder' ? [] : undefined,
    };

    if (!parentId) {
      setTree((prev) => [...prev, newNode]);
    } else {
      const addToParent = (nodes: FileNode[]): FileNode[] => {
        return nodes.map((n) => {
          if (n.id === parentId && n.type === 'folder') {
            return {
              ...n,
              children: [...(n.children || []), newNode],
            };
          }
          return {
            ...n,
            children: n.children ? addToParent(n.children) : undefined,
          };
        });
      };
      setTree((prev) => addToParent(prev));
      setExpandedFolders((prev) => new Set([...prev, parentId]));
    }
    showNotification(`New ${type} created`);
  }, [showNotification]);

  // Rename node
  const renameNode = useCallback((id: string, newName: string) => {
    if (!newName.trim()) return;
    const ext = newName.lastIndexOf('.') > 0
      ? newName.substring(newName.lastIndexOf('.') + 1)
      : '';
    const updateInTree = (nodes: FileNode[]): FileNode[] => {
      return nodes.map((n) => {
        if (n.id === id) {
          return { ...n, name: newName.trim(), extension: n.type === 'file' ? ext : n.extension };
        }
        return {
          ...n,
          children: n.children ? updateInTree(n.children) : undefined,
        };
      });
    };
    setTree((prev) => updateInTree(prev));
    setRenaming(null);
    showNotification('Item renamed');
  }, [showNotification]);

  // Generate context menu actions
  const getContextActions = useCallback((): ContextMenuAction[] => {
    const node = contextMenu?.node;
    const multiSelected = selectedIds.size > 1;

    if (multiSelected) {
      return [
        {
          label: `Delete ${selectedIds.size} items`,
          icon: '🗑',
          shortcut: 'Delete',
          danger: true,
          action: () => deleteNodes(selectedIds),
        },
      ];
    }

    if (!node) {
      // Background context menu
      return [
        {
          label: 'New File',
          icon: '📄',
          shortcut: 'Ctrl+N',
          action: () => addNewItem(null, 'file'),
          dividerAfter: false,
        },
        {
          label: 'New Folder',
          icon: '📁',
          action: () => addNewItem(null, 'folder'),
          dividerAfter: true,
        },
        {
          label: 'Expand All',
          icon: '⊞',
          action: expandAll,
        },
        {
          label: 'Collapse All',
          icon: '⊟',
          action: collapseAll,
        },
      ];
    }

    const isFolder = node.type === 'folder';
    const actions: ContextMenuAction[] = [];

    if (isFolder) {
      actions.push(
        {
          label: 'New File',
          icon: '📄',
          action: () => addNewItem(node.id, 'file'),
        },
        {
          label: 'New Folder',
          icon: '📁',
          action: () => addNewItem(node.id, 'folder'),
          dividerAfter: true,
        }
      );
    }

    actions.push(
      {
        label: 'Cut',
        icon: '✂️',
        shortcut: 'Ctrl+X',
        action: () => showNotification('Cut: ' + node.name),
      },
      {
        label: 'Copy',
        icon: '📋',
        shortcut: 'Ctrl+C',
        action: () => showNotification('Copied: ' + node.name),
      },
    );

    if (isFolder) {
      actions.push({
        label: 'Paste',
        icon: '📌',
        shortcut: 'Ctrl+V',
        action: () => showNotification('Paste into: ' + node.name),
        dividerAfter: true,
      });
    } else {
      actions[actions.length - 1].dividerAfter = true;
    }

    actions.push(
      {
        label: 'Copy Path',
        icon: '📎',
        shortcut: 'Shift+Alt+C',
        action: () => showNotification('Path copied'),
      },
      {
        label: 'Copy Relative Path',
        icon: '🔗',
        shortcut: 'Ctrl+Shift+C',
        action: () => showNotification('Relative path copied'),
        dividerAfter: true,
      },
      {
        label: 'Rename',
        icon: '✏️',
        shortcut: 'F2',
        action: () => setRenaming(node.id),
      },
      {
        label: 'Duplicate',
        icon: '📑',
        action: () => duplicateNode(node.id),
        dividerAfter: true,
      },
      {
        label: 'Delete',
        icon: '🗑',
        shortcut: 'Delete',
        danger: true,
        action: () => deleteNodes(new Set([node.id])),
      }
    );

    if (isFolder) {
      actions.splice(actions.length - 1, 0, {
        label: expandedFolders.has(node.id) ? 'Collapse' : 'Expand',
        icon: expandedFolders.has(node.id) ? '⊟' : '⊞',
        action: () => toggleFolder(node.id),
        dividerAfter: false,
      });
    }

    return actions;
  }, [contextMenu, selectedIds, deleteNodes, addNewItem, expandAll, collapseAll, duplicateNode, showNotification, expandedFolders, toggleFolder]);

  // Filter tree by search query
  const filterTree = useCallback(
    (nodes: FileNode[], query: string): FileNode[] => {
      if (!query.trim()) return nodes;
      const lq = query.toLowerCase();

      return nodes
        .map((node) => {
          if (node.type === 'folder') {
            const filteredChildren = node.children ? filterTree(node.children, query) : [];
            const nameMatches = node.name.toLowerCase().includes(lq);
            if (filteredChildren.length > 0 || nameMatches) {
              return { ...node, children: filteredChildren.length > 0 ? filteredChildren : node.children };
            }
            return null;
          }
          return node.name.toLowerCase().includes(lq) ? node : null;
        })
        .filter(Boolean) as FileNode[];
    },
    []
  );

  useEffect(() => {
    if (showSearch && searchInputRef.current) {
      searchInputRef.current.focus();
    }
  }, [showSearch]);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'f' && (e.ctrlKey || e.metaKey)) {
        e.preventDefault();
        setShowSearch((prev) => !prev);
      }
      if (e.key === 'Delete' && selectedIds.size > 0) {
        deleteNodes(selectedIds);
      }
      if (e.key === 'F2' && selectedIds.size === 1) {
        const [id] = selectedIds;
        setRenaming(id);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedIds, deleteNodes]);

  const displayTree = searchQuery ? filterTree(tree, searchQuery) : tree;

  // Expand all folders when searching
  useEffect(() => {
    if (searchQuery.trim()) {
      const allFolderIds = new Set<string>();
      const collect = (nodes: FileNode[]) => {
        for (const n of nodes) {
          if (n.type === 'folder') {
            allFolderIds.add(n.id);
            if (n.children) collect(n.children);
          }
        }
      };
      collect(tree);
      setExpandedFolders(allFolderIds);
    }
  }, [searchQuery, tree]);

  const selectedCount = selectedIds.size;

  return (
    <div className="flex flex-col h-full" style={{ backgroundColor: '#252526' }}>
      {/* Header */}
      <div
        className="flex items-center justify-between px-4 h-[35px] flex-shrink-0 uppercase text-[11px] font-semibold tracking-wider"
        style={{ color: '#bbbbbb', borderBottom: '1px solid #1e1e1e' }}
      >
        <span>Explorer</span>
        <div className="flex items-center gap-1">
          <button
            className="p-1 rounded opacity-70 hover:opacity-100 hover:bg-[#383838] transition-all cursor-pointer"
            title="New File (Ctrl+N)"
            onClick={() => addNewItem(null, 'file')}
          >
            <NewFileIcon />
          </button>
          <button
            className="p-1 rounded opacity-70 hover:opacity-100 hover:bg-[#383838] transition-all cursor-pointer"
            title="New Folder"
            onClick={() => addNewItem(null, 'folder')}
          >
            <NewFolderIcon />
          </button>
          <button
            className="p-1 rounded opacity-70 hover:opacity-100 hover:bg-[#383838] transition-all cursor-pointer"
            title="Refresh Explorer"
            onClick={() => {
              setTree(fileTree);
              showNotification('Explorer refreshed');
            }}
          >
            <RefreshIcon />
          </button>
          <button
            className="p-1 rounded opacity-70 hover:opacity-100 hover:bg-[#383838] transition-all cursor-pointer"
            title="Collapse Folders"
            onClick={collapseAll}
          >
            <CollapseAllIcon />
          </button>
        </div>
      </div>

      {/* Project Title */}
      <div
        className="flex items-center px-2 h-[22px] flex-shrink-0 cursor-pointer"
        style={{ backgroundColor: '#252526' }}
        onClick={() => setExpandedFolders(prev => {
          const next = new Set(prev);
          // toggle root level folders
          return next;
        })}
      >
        <svg width="10" height="10" viewBox="0 0 10 10" fill="none" className="mr-1">
          <path d="M2 3L5 6L8 3" stroke="#cccccc" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
        <span className="text-[11px] font-bold uppercase tracking-wider" style={{ color: '#cccccc' }}>
          my-project
        </span>
      </div>

      {/* Search Bar */}
      {showSearch && (
        <div className="px-2 py-2 flex-shrink-0" style={{ borderBottom: '1px solid #3c3c3c' }}>
          <div className="flex items-center gap-2 px-2 py-1 rounded" style={{ backgroundColor: '#3c3c3c' }}>
            <SearchIcon />
            <input
              ref={searchInputRef}
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search files..."
              className="flex-1 bg-transparent border-none outline-none text-[13px]"
              style={{ color: '#cccccc' }}
              onKeyDown={(e) => {
                if (e.key === 'Escape') {
                  setShowSearch(false);
                  setSearchQuery('');
                }
              }}
            />
            {searchQuery && (
              <button
                className="text-[#cccccc] hover:text-white text-xs cursor-pointer"
                onClick={() => {
                  setSearchQuery('');
                  searchInputRef.current?.focus();
                }}
              >
                ✕
              </button>
            )}
          </div>
        </div>
      )}

      {/* File Tree */}
      <div
        ref={explorerRef}
        className="flex-1 overflow-y-auto overflow-x-hidden py-1"
        onClick={handleBackgroundClick}
        onContextMenu={handleBackgroundContextMenu}
        style={{
          scrollbarWidth: 'thin',
          scrollbarColor: '#424242 transparent',
        }}
      >
        {displayTree.length === 0 && searchQuery ? (
          <div className="px-4 py-8 text-center text-[13px]" style={{ color: '#6e6e6e' }}>
            No results found for "{searchQuery}"
          </div>
        ) : (
          displayTree.map((node) => (
            <TreeNodeWithRename
              key={node.id}
              node={node}
              depth={0}
              expandedFolders={expandedFolders}
              selectedIds={selectedIds}
              lastSelectedId={lastSelectedId}
              onToggleFolder={toggleFolder}
              onSelect={handleSelect}
              onContextMenu={handleContextMenu}
              flatNodes={flatNodes}
              renaming={renaming}
              onRename={renameNode}
              onCancelRename={() => setRenaming(null)}
            />
          ))
        )}
      </div>

      {/* Status Bar */}
      <div
        className="flex items-center justify-between px-3 h-[22px] flex-shrink-0 text-[11px]"
        style={{
          backgroundColor: '#1e1e1e',
          color: '#6e6e6e',
          borderTop: '1px solid #3c3c3c',
        }}
      >
        <span>
          {selectedCount > 0
            ? `${selectedCount} item${selectedCount > 1 ? 's' : ''} selected`
            : `${flatNodes.length} items`}
        </span>
        <span className="flex items-center gap-2">
          <span className="opacity-60">Ctrl+F to search</span>
          <span>•</span>
          <span className="opacity-60">Ctrl/⌘+Click to multi-select</span>
        </span>
      </div>

      {/* Context Menu */}
      {contextMenu && (
        <ContextMenu
          position={contextMenu.position}
          actions={getContextActions()}
          onClose={closeContextMenu}
        />
      )}

      {/* Notification Toast */}
      {notification && (
        <div
          className="fixed bottom-8 left-1/2 -translate-x-1/2 px-4 py-2 rounded-lg text-[13px] shadow-lg z-[10000]"
          style={{
            backgroundColor: '#007acc',
            color: '#ffffff',
            animation: 'slideUp 0.2s ease-out',
          }}
        >
          {notification}
        </div>
      )}
    </div>
  );
}

// Wrapper to handle renaming inline
function TreeNodeWithRename({
  node,
  depth,
  expandedFolders,
  selectedIds,
  lastSelectedId,
  onToggleFolder,
  onSelect,
  onContextMenu,
  flatNodes,
  renaming,
  onRename,
  onCancelRename,
}: {
  node: FileNode;
  depth: number;
  expandedFolders: Set<string>;
  selectedIds: Set<string>;
  lastSelectedId: string | null;
  onToggleFolder: (id: string) => void;
  onSelect: (id: string, e: React.MouseEvent) => void;
  onContextMenu: (e: React.MouseEvent, node: FileNode) => void;
  flatNodes: FileNode[];
  renaming: string | null;
  onRename: (id: string, newName: string) => void;
  onCancelRename: () => void;
}) {
  const isRenaming = renaming === node.id;
  const isFolder = node.type === 'folder';
  const isExpanded = expandedFolders.has(node.id);

  const sortedChildren = isFolder && node.children
    ? [...node.children].sort((a, b) => {
        if (a.type !== b.type) return a.type === 'folder' ? -1 : 1;
        return a.name.localeCompare(b.name);
      })
    : [];

  if (isRenaming) {
    return (
      <div className="select-none">
        <div
          className="flex items-center"
          style={{
            paddingLeft: `${depth * 16 + 8}px`,
            height: '22px',
            backgroundColor: '#04395e',
          }}
        >
          {/* Indent guides */}
          {Array.from({ length: depth }).map((_, i) => (
            <div
              key={i}
              className="absolute top-0 bottom-0 w-px"
              style={{
                left: `${i * 16 + 16}px`,
                backgroundColor: '#404040',
              }}
            />
          ))}

          <span className="flex-shrink-0 flex items-center justify-center w-4 h-4">
            {isFolder && (
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none" className={isExpanded ? 'rotate-90' : ''}>
                <path d="M6 4L10 8L6 12" stroke="#c5c5c5" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            )}
          </span>

          <span className="flex-shrink-0 flex items-center mx-1">
            <FileIcon name={node.name} extension={node.extension} isFolder={isFolder} isOpen={isExpanded} size={16} />
          </span>

          <RenameInput
            initialValue={node.name}
            onSubmit={(newName) => onRename(node.id, newName)}
            onCancel={onCancelRename}
          />
        </div>

        {isFolder && isExpanded && (
          <div>
            {sortedChildren.map((child) => (
              <TreeNodeWithRename
                key={child.id}
                node={child}
                depth={depth + 1}
                expandedFolders={expandedFolders}
                selectedIds={selectedIds}
                lastSelectedId={lastSelectedId}
                onToggleFolder={onToggleFolder}
                onSelect={onSelect}
                onContextMenu={onContextMenu}
                flatNodes={flatNodes}
                renaming={renaming}
                onRename={onRename}
                onCancelRename={onCancelRename}
              />
            ))}
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="select-none">
      <TreeNode
        node={node}
        depth={depth}
        isExpanded={isExpanded}
        isSelected={selectedIds.has(node.id)}
        onToggleFolder={onToggleFolder}
        onSelect={onSelect}
        onContextMenu={onContextMenu}
      />
      {isFolder && isExpanded && (
        <div>
          {sortedChildren.map((child) => (
            <TreeNodeWithRename
              key={child.id}
              node={child}
              depth={depth + 1}
              expandedFolders={expandedFolders}
              selectedIds={selectedIds}
              lastSelectedId={lastSelectedId}
              onToggleFolder={onToggleFolder}
              onSelect={onSelect}
              onContextMenu={onContextMenu}
              flatNodes={flatNodes}
              renaming={renaming}
              onRename={onRename}
              onCancelRename={onCancelRename}
            />
          ))}
        </div>
      )}
    </div>
  );
}

// FileIcon imported at top of file

function RenameInput({
  initialValue,
  onSubmit,
  onCancel,
}: {
  initialValue: string;
  onSubmit: (value: string) => void;
  onCancel: () => void;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [value, setValue] = useState(initialValue);

  useEffect(() => {
    if (inputRef.current) {
      inputRef.current.focus();
      // Select filename without extension
      const dotIdx = initialValue.lastIndexOf('.');
      if (dotIdx > 0) {
        inputRef.current.setSelectionRange(0, dotIdx);
      } else {
        inputRef.current.select();
      }
    }
  }, [initialValue]);

  return (
    <input
      ref={inputRef}
      type="text"
      value={value}
      onChange={(e) => setValue(e.target.value)}
      onKeyDown={(e) => {
        e.stopPropagation();
        if (e.key === 'Enter') {
          onSubmit(value);
        }
        if (e.key === 'Escape') {
          onCancel();
        }
      }}
      onBlur={() => onSubmit(value)}
      onClick={(e) => e.stopPropagation()}
      className="flex-1 text-[13px] px-1 py-0 border rounded outline-none"
      style={{
        backgroundColor: '#3c3c3c',
        color: '#cccccc',
        borderColor: '#007acc',
        height: '20px',
      }}
    />
  );
}

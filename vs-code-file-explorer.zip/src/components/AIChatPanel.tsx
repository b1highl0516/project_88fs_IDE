import { useState, useRef, useEffect, useCallback } from 'react';
import {
  AISlot,
  ChatMessage,
  ChatSession,
  CollabMode,
  PROVIDER_LABELS,
  AI_SLOT_DEFAULTS,
} from '../types';
import { sendChatRequest } from '../services/aiService';
import AISettingsModal from './AISettingsModal';

const QUICK_ACTIONS = [
  { icon: '💡', label: 'Explain', prompt: 'Explain this code step by step:\n```\n// paste code\n```' },
  { icon: '🐛', label: 'Debug', prompt: 'Debug this error:\n```\n// paste error\n```' },
  { icon: '✨', label: 'Generate', prompt: 'Generate code for: ' },
  { icon: '♻️', label: 'Refactor', prompt: 'Refactor this code:\n```\n// paste code\n```' },
  { icon: '📝', label: 'Tests', prompt: 'Write tests for:\n```\n// paste code\n```' },
  { icon: '🤝', label: 'Collab', prompt: 'All agents: discuss the best approach for implementing ' },
];

// ─── Markdown Renderer ───────────────────────────────────
function renderMarkdown(text: string): React.ReactNode[] {
  const elements: React.ReactNode[] = [];
  const lines = text.split('\n');
  let inCode = false, codeLang = '', codeLines: string[] = [], k = 0;
  const pushCode = () => { elements.push(<CodeBlock key={k++} code={codeLines.join('\n')} language={codeLang} />); codeLines = []; codeLang = ''; };
  for (const line of lines) {
    if (line.startsWith('```')) { if (inCode) { pushCode(); inCode = false; } else { inCode = true; codeLang = line.slice(3).trim(); } continue; }
    if (inCode) { codeLines.push(line); continue; }
    if (line.startsWith('### ')) elements.push(<div key={k++} className="text-[13px] font-bold mt-2 mb-0.5" style={{ color: '#e0e0e0' }}>{inlineParse(line.slice(4))}</div>);
    else if (line.startsWith('## ')) elements.push(<div key={k++} className="text-[14px] font-bold mt-2 mb-0.5" style={{ color: '#e0e0e0' }}>{inlineParse(line.slice(3))}</div>);
    else if (line.startsWith('# ')) elements.push(<div key={k++} className="text-[15px] font-bold mt-2 mb-0.5" style={{ color: '#e0e0e0' }}>{inlineParse(line.slice(2))}</div>);
    else if (line.startsWith('- ') || line.startsWith('* ')) elements.push(<div key={k++} className="text-[12px] leading-[1.6] pl-3 flex gap-1.5" style={{ color: '#ccc' }}><span style={{ color: '#007acc' }}>•</span><span>{inlineParse(line.slice(2))}</span></div>);
    else if (/^\d+\.\s/.test(line)) { const m = line.match(/^(\d+)\.\s(.*)$/); if (m) elements.push(<div key={k++} className="text-[12px] leading-[1.6] pl-3 flex gap-1.5" style={{ color: '#ccc' }}><span style={{ color: '#007acc' }}>{m[1]}.</span><span>{inlineParse(m[2])}</span></div>); }
    else if (line.trim() === '') elements.push(<div key={k++} className="h-1.5" />);
    else elements.push(<div key={k++} className="text-[12px] leading-[1.6]" style={{ color: '#ccc' }}>{inlineParse(line)}</div>);
  }
  if (inCode) pushCode();
  return elements;
}

function inlineParse(text: string): React.ReactNode[] {
  const parts: React.ReactNode[] = [];
  const rx = /(\*\*(.+?)\*\*)|(`([^`]+?)`)|((?<!\*)\*(?!\*)(.+?)(?<!\*)\*(?!\*))/g;
  let last = 0, m, k = 0;
  while ((m = rx.exec(text)) !== null) {
    if (m.index > last) parts.push(<span key={k++}>{text.slice(last, m.index)}</span>);
    if (m[1]) parts.push(<strong key={k++} style={{ color: '#e0e0e0' }}>{m[2]}</strong>);
    else if (m[3]) parts.push(<code key={k++} className="px-1 py-0.5 rounded text-[11px]" style={{ backgroundColor: '#1e1e1e', color: '#ce9178', fontFamily: "monospace" }}>{m[4]}</code>);
    else if (m[5]) parts.push(<em key={k++} style={{ color: '#c586c0' }}>{m[6]}</em>);
    last = m.index + m[0].length;
  }
  if (last < text.length) parts.push(<span key={k++}>{text.slice(last)}</span>);
  return parts.length > 0 ? parts : [text];
}

function CodeBlock({ code, language }: { code: string; language: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <div className="my-1.5 rounded overflow-hidden" style={{ border: '1px solid #3c3c3c' }}>
      <div className="flex items-center justify-between px-2.5 py-0.5" style={{ backgroundColor: '#2d2d2d' }}>
        <span className="text-[10px] font-mono" style={{ color: '#969696' }}>{language || 'text'}</span>
        <button onClick={() => { navigator.clipboard.writeText(code); setCopied(true); setTimeout(() => setCopied(false), 2000); }} className="text-[10px] px-1.5 py-0.5 rounded cursor-pointer hover:bg-[#3c3c3c]" style={{ color: copied ? '#4ec9b0' : '#969696' }}>{copied ? '✓' : 'Copy'}</button>
      </div>
      <pre className="px-2.5 py-1.5 overflow-x-auto text-[11px] leading-[1.5]" style={{ backgroundColor: '#1e1e1e', color: '#d4d4d4', fontFamily: "monospace", margin: 0 }}><code>{code}</code></pre>
    </div>
  );
}

function Dots({ color = '#007acc' }: { color?: string }) {
  return (
    <span className="inline-flex items-center gap-0.5 mx-0.5">
      <span className="w-1 h-1 rounded-full animate-bounce" style={{ backgroundColor: color, animationDelay: '0ms' }} />
      <span className="w-1 h-1 rounded-full animate-bounce" style={{ backgroundColor: color, animationDelay: '150ms' }} />
      <span className="w-1 h-1 rounded-full animate-bounce" style={{ backgroundColor: color, animationDelay: '300ms' }} />
    </span>
  );
}

// ─── Main Component ──────────────────────────────────────
export default function AIChatPanel() {
  const [slots, setSlots] = useState<AISlot[]>(() => {
    try { const s = localStorage.getItem('ai-slots-v2'); if (s) return JSON.parse(s); } catch {}
    return AI_SLOT_DEFAULTS;
  });
  const [sessions, setSessions] = useState<ChatSession[]>(() => {
    try { const s = localStorage.getItem('ai-sessions-v2'); if (s) return JSON.parse(s); } catch {}
    return [{ id: 'default', title: 'New Chat', messages: [], createdAt: Date.now(), updatedAt: Date.now() }];
  });
  const [activeSessionId, setActiveSessionId] = useState('default');
  const [input, setInput] = useState('');
  const [loadingSlots, setLoadingSlots] = useState<Set<string>>(new Set());
  const [showSettings, setShowSettings] = useState(false);
  const [settingsTab, setSettingsTab] = useState(0);
  const [showSessions, setShowSessions] = useState(false);
  const [collabMode, setCollabMode] = useState<CollabMode>('all');
  const [selectedSlot, setSelectedSlot] = useState<string>('ai-1');
  const [roundRobinIdx, setRoundRobinIdx] = useState(0);
  const abortsRef = useRef<Map<string, AbortController>>(new Map());
  const chatEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const session = sessions.find(s => s.id === activeSessionId) || sessions[0];
  const messages = session?.messages || [];
  const enabledSlots = slots.filter(s => s.enabled);
  const isLoading = loadingSlots.size > 0;

  useEffect(() => { localStorage.setItem('ai-slots-v2', JSON.stringify(slots)); }, [slots]);
  useEffect(() => { localStorage.setItem('ai-sessions-v2', JSON.stringify(sessions)); }, [sessions]);
  useEffect(() => { chatEndRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);

  const updateSession = useCallback((sid: string, fn: (s: ChatSession) => ChatSession) => {
    setSessions(prev => prev.map(s => s.id === sid ? fn(s) : s));
  }, []);

  // Determine which slots respond this turn
  const getRespondingSlots = useCallback((): AISlot[] => {
    if (enabledSlots.length === 0) return [];
    if (collabMode === 'all') return enabledSlots;
    if (collabMode === 'select') return enabledSlots.filter(s => s.id === selectedSlot);
    // round-robin
    const idx = roundRobinIdx % enabledSlots.length;
    setRoundRobinIdx(prev => prev + 1);
    return [enabledSlots[idx]];
  }, [collabMode, enabledSlots, selectedSlot, roundRobinIdx]);

  const handleSend = useCallback(async () => {
    const trimmed = input.trim();
    if (!trimmed || isLoading) return;

    const responding = getRespondingSlots();
    if (responding.length === 0) { return; }

    const userMsg: ChatMessage = { id: `u-${Date.now()}`, role: 'user', content: trimmed, timestamp: Date.now() };

    // Create placeholder assistant messages for each responding slot
    const assistantMsgs: ChatMessage[] = responding.map(slot => ({
      id: `a-${slot.id}-${Date.now()}`,
      role: 'assistant' as const,
      content: '',
      timestamp: Date.now(),
      isStreaming: true,
      model: slot.config.model,
      slotId: slot.id,
      slotName: slot.name,
      slotColor: slot.color,
    }));

    const isFirst = messages.length === 0;
    const allNewMsgs = [userMsg, ...assistantMsgs];

    updateSession(activeSessionId, s => ({
      ...s,
      messages: [...s.messages, ...allNewMsgs],
      title: isFirst ? trimmed.slice(0, 50) : s.title,
      updatedAt: Date.now(),
    }));

    setInput('');
    setLoadingSlots(new Set(responding.map(s => s.id)));

    // Build context: all previous messages + user's new message
    // For collaboration: each AI can see what the others said
    const contextMsgs = [...messages, userMsg];

    // Fire all requests in parallel
    const promises = responding.map(async (slot) => {
      const msgId = assistantMsgs.find(m => m.slotId === slot.id)!.id;
      const controller = new AbortController();
      abortsRef.current.set(slot.id, controller);

      // Inject collaboration context into system prompt
      const collabContext = responding.length > 1
        ? `\n\nYou are working in a multi-AI collaboration. Other agents: ${responding.filter(s => s.id !== slot.id).map(s => s.name).join(', ')}. Build upon their work if they have already responded.`
        : '';

      const configWithCollab = {
        ...slot.config,
        systemPrompt: slot.config.systemPrompt + collabContext,
      };

      // Convert chat messages to format expected by API, including slot attribution
      const apiMessages: ChatMessage[] = contextMsgs.map(m => {
        if (m.role === 'assistant' && m.slotId && m.slotName) {
          return { ...m, content: `[${m.slotName}]: ${m.content}` };
        }
        return m;
      });

      await sendChatRequest(
        configWithCollab,
        apiMessages,
        (text) => {
          updateSession(activeSessionId, s => ({
            ...s,
            messages: s.messages.map(m => m.id === msgId ? { ...m, content: text, isStreaming: true } : m),
          }));
        },
        (fullText, tokensUsed) => {
          updateSession(activeSessionId, s => ({
            ...s,
            messages: s.messages.map(m => m.id === msgId ? { ...m, content: fullText, isStreaming: false, tokensUsed } : m),
            updatedAt: Date.now(),
          }));
          setLoadingSlots(prev => { const n = new Set(prev); n.delete(slot.id); return n; });
          abortsRef.current.delete(slot.id);
        },
        (err) => {
          updateSession(activeSessionId, s => ({
            ...s,
            messages: s.messages.map(m => m.id === msgId ? { ...m, content: `⚠️ Error: ${err}`, isStreaming: false } : m),
          }));
          setLoadingSlots(prev => { const n = new Set(prev); n.delete(slot.id); return n; });
          abortsRef.current.delete(slot.id);
        },
        controller.signal
      );
    });

    await Promise.allSettled(promises);
  }, [input, isLoading, messages, getRespondingSlots, activeSessionId, updateSession]);

  const handleStop = useCallback(() => {
    abortsRef.current.forEach(c => c.abort());
    abortsRef.current.clear();
    setLoadingSlots(new Set());
  }, []);

  const newSession = useCallback(() => {
    const s: ChatSession = { id: `s-${Date.now()}`, title: 'New Chat', messages: [], createdAt: Date.now(), updatedAt: Date.now() };
    setSessions(prev => [s, ...prev]);
    setActiveSessionId(s.id);
    setShowSessions(false);
  }, []);

  const deleteSession = useCallback((id: string) => {
    setSessions(prev => {
      const f = prev.filter(s => s.id !== id);
      if (f.length === 0) { const fb: ChatSession = { id: `s-${Date.now()}`, title: 'New Chat', messages: [], createdAt: Date.now(), updatedAt: Date.now() }; setActiveSessionId(fb.id); return [fb]; }
      if (id === activeSessionId) setActiveSessionId(f[0].id);
      return f;
    });
  }, [activeSessionId]);

  const clearSession = useCallback(() => {
    updateSession(activeSessionId, s => ({ ...s, messages: [], title: 'New Chat', updatedAt: Date.now() }));
  }, [activeSessionId, updateSession]);

  const handleKeyDown = (e: React.KeyboardEvent) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); } };

  const anyConfigured = enabledSlots.some(s => s.config.apiKey || s.config.provider === 'custom');

  return (
    <div className="flex flex-col h-full" style={{ backgroundColor: '#252526' }}>
      {/* ─── Header ─── */}
      <div className="flex items-center justify-between px-3 h-[35px] flex-shrink-0" style={{ borderBottom: '1px solid #1e1e1e' }}>
        <div className="flex items-center gap-2">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="10" stroke="#007acc" strokeWidth="1.5" fill="none" /><circle cx="7" cy="9" r="1.5" fill="#007acc" /><circle cx="12" cy="7" r="1.5" fill="#e5c07b" /><circle cx="17" cy="9" r="1.5" fill="#c678dd" /><path d="M7 15C8.5 17 10 18 12 18C14 18 15.5 17 17 15" stroke="#007acc" strokeWidth="1.5" strokeLinecap="round" fill="none" /></svg>
          <span className="text-[11px] font-semibold uppercase tracking-wider" style={{ color: '#bbbbbb' }}>AI Team</span>
        </div>
        <div className="flex items-center gap-0.5">
          <button onClick={() => setShowSessions(!showSessions)} className="p-1 rounded opacity-70 hover:opacity-100 hover:bg-[#383838] transition-all cursor-pointer" title="Sessions">
            <svg width="13" height="13" viewBox="0 0 16 16" fill="none"><rect x="2" y="2" width="12" height="3" rx="0.5" stroke="#ccc" strokeWidth="1" fill="none" /><rect x="2" y="6.5" width="12" height="3" rx="0.5" stroke="#ccc" strokeWidth="1" fill="none" /><rect x="2" y="11" width="12" height="3" rx="0.5" stroke="#ccc" strokeWidth="1" fill="none" /></svg>
          </button>
          <button onClick={newSession} className="p-1 rounded opacity-70 hover:opacity-100 hover:bg-[#383838] transition-all cursor-pointer" title="New Chat">
            <svg width="13" height="13" viewBox="0 0 16 16" fill="none"><line x1="8" y1="2" x2="8" y2="14" stroke="#ccc" strokeWidth="1.5" strokeLinecap="round" /><line x1="2" y1="8" x2="14" y2="8" stroke="#ccc" strokeWidth="1.5" strokeLinecap="round" /></svg>
          </button>
          <button onClick={clearSession} className="p-1 rounded opacity-70 hover:opacity-100 hover:bg-[#383838] transition-all cursor-pointer" title="Clear">
            <svg width="13" height="13" viewBox="0 0 16 16" fill="none"><path d="M3 4H13L12 14H4L3 4Z" stroke="#ccc" strokeWidth="1" fill="none" /><line x1="2" y1="4" x2="14" y2="4" stroke="#ccc" strokeWidth="1" strokeLinecap="round" /><path d="M6 4V2H10V4" stroke="#ccc" strokeWidth="1" fill="none" /></svg>
          </button>
          <button onClick={() => { setSettingsTab(0); setShowSettings(true); }} className="p-1 rounded opacity-70 hover:opacity-100 hover:bg-[#383838] transition-all cursor-pointer" title="Settings">
            <svg width="13" height="13" viewBox="0 0 16 16" fill="none"><circle cx="8" cy="8" r="2" stroke="#ccc" strokeWidth="1.2" fill="none" /><path d="M8 1V3M8 13V15M1 8H3M13 8H15M3.17 3.17L4.58 4.58M11.42 11.42L12.83 12.83M12.83 3.17L11.42 4.58M4.58 11.42L3.17 12.83" stroke="#ccc" strokeWidth="1.2" strokeLinecap="round" /></svg>
          </button>
        </div>
      </div>

      {/* ─── Agent Status Bar ─── */}
      <div className="flex items-center gap-1 px-2.5 py-1.5 flex-shrink-0" style={{ backgroundColor: '#1e1e1e', borderBottom: '1px solid #2d2d2d' }}>
        {slots.map((s, i) => (
          <button
            key={s.id}
            onClick={() => { setSettingsTab(i); setShowSettings(true); }}
            className="flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] cursor-pointer transition-all hover:bg-[#2d2d2d]"
            style={{ color: s.enabled ? '#cccccc' : '#5a5a5a', opacity: s.enabled ? 1 : 0.5 }}
            title={`${s.name} — ${PROVIDER_LABELS[s.config.provider]} / ${s.config.model}\n${s.role}`}
          >
            <div className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ backgroundColor: s.enabled ? s.color : '#5a5a5a' }}>
              {loadingSlots.has(s.id) && <div className="w-1.5 h-1.5 rounded-full animate-ping" style={{ backgroundColor: s.color }} />}
            </div>
            <span className="font-medium">{s.name}</span>
          </button>
        ))}
        <div className="flex-1" />
        {/* Collab mode selector */}
        <div className="flex items-center gap-0.5">
          {(['all', 'round-robin', 'select'] as CollabMode[]).map(m => (
            <button key={m} onClick={() => setCollabMode(m)}
              className="px-1.5 py-0.5 rounded text-[9px] font-medium cursor-pointer transition-all uppercase"
              style={{ backgroundColor: collabMode === m ? '#007acc' : 'transparent', color: collabMode === m ? '#fff' : '#6e6e6e' }}
            >{m === 'round-robin' ? 'Robin' : m === 'select' ? 'Pick' : 'All'}</button>
          ))}
        </div>
      </div>

      {/* Select-mode slot picker */}
      {collabMode === 'select' && (
        <div className="flex items-center gap-1 px-2.5 py-1 flex-shrink-0" style={{ backgroundColor: '#1a1a1a', borderBottom: '1px solid #2d2d2d' }}>
          <span className="text-[9px] uppercase font-medium mr-1" style={{ color: '#6e6e6e' }}>Target:</span>
          {enabledSlots.map(s => (
            <button key={s.id} onClick={() => setSelectedSlot(s.id)}
              className="flex items-center gap-1 px-2 py-0.5 rounded text-[10px] cursor-pointer font-medium"
              style={{ backgroundColor: selectedSlot === s.id ? s.color : '#2d2d2d', color: selectedSlot === s.id ? '#fff' : '#999' }}
            ><div className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: s.color }} />{s.name}</button>
          ))}
        </div>
      )}

      {/* Sessions */}
      {showSessions && (
        <div className="flex-shrink-0 max-h-[160px] overflow-y-auto" style={{ backgroundColor: '#1e1e1e', borderBottom: '1px solid #3c3c3c', scrollbarWidth: 'thin', scrollbarColor: '#424242 transparent' }}>
          {sessions.map(s => (
            <div key={s.id} className="flex items-center gap-2 px-3 py-1.5 cursor-pointer text-[11px] group"
              style={{ backgroundColor: s.id === activeSessionId ? '#04395e' : 'transparent', color: '#cccccc' }}
              onClick={() => { setActiveSessionId(s.id); setShowSessions(false); }}
              onMouseEnter={e => { if (s.id !== activeSessionId) e.currentTarget.style.backgroundColor = '#2a2d2e'; }}
              onMouseLeave={e => { if (s.id !== activeSessionId) e.currentTarget.style.backgroundColor = 'transparent'; }}
            >
              <span className="flex-1 truncate">{s.title}</span>
              <span className="text-[9px] opacity-40">{s.messages.length}</span>
              <button className="opacity-0 group-hover:opacity-70 hover:!opacity-100 cursor-pointer" onClick={e => { e.stopPropagation(); deleteSession(s.id); }} style={{ color: '#f14c4c' }}>✕</button>
            </div>
          ))}
        </div>
      )}

      {/* ─── Messages ─── */}
      <div className="flex-1 overflow-y-auto px-2.5 py-2.5 space-y-2" style={{ scrollbarWidth: 'thin', scrollbarColor: '#424242 transparent' }}>
        {messages.length === 0 && (
          <EmptyState
            slots={slots}
            anyConfigured={anyConfigured}
            onConfigure={() => setShowSettings(true)}
            onAction={prompt => { setInput(prompt); inputRef.current?.focus(); }}
          />
        )}
        {messages.map(msg => (
          <MessageBubble key={msg.id} message={msg} />
        ))}
        <div ref={chatEndRef} />
      </div>

      {/* ─── Input ─── */}
      <div className="flex-shrink-0 px-2.5 pb-2.5">
        <div className="rounded-lg overflow-hidden" style={{ border: '1px solid #3c3c3c', backgroundColor: '#1e1e1e' }}>
          <textarea
            ref={inputRef}
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={anyConfigured ? `Message ${collabMode === 'all' ? 'all agents' : collabMode === 'select' ? enabledSlots.find(s => s.id === selectedSlot)?.name || 'agent' : 'next agent'}... (Enter to send)` : 'Configure at least one AI agent...'}
            disabled={!anyConfigured}
            rows={2}
            className="w-full px-3 py-2 text-[12px] outline-none resize-none bg-transparent leading-[1.5]"
            style={{ color: '#cccccc', opacity: anyConfigured ? 1 : 0.4 }}
          />
          <div className="flex items-center justify-between px-2 pb-1.5">
            <div className="flex items-center gap-0.5">
              {QUICK_ACTIONS.map((a, i) => (
                <button key={i} onClick={() => { setInput(a.prompt); inputRef.current?.focus(); }}
                  className="text-[11px] px-1.5 py-0.5 rounded cursor-pointer transition-colors hover:bg-[#2d2d2d]"
                  style={{ color: '#5a5a5a' }} title={a.label}
                >{a.icon}</button>
              ))}
            </div>
            <div className="flex items-center gap-1.5">
              {isLoading && (
                <button onClick={handleStop} className="flex items-center gap-1 px-2 py-0.5 rounded text-[10px] cursor-pointer" style={{ backgroundColor: '#5a1d1d', color: '#f14c4c' }}>
                  <svg width="8" height="8" viewBox="0 0 8 8" fill="currentColor"><rect width="8" height="8" rx="1" /></svg>Stop
                </button>
              )}
              <button onClick={handleSend} disabled={!input.trim() || isLoading || !anyConfigured}
                className="flex items-center gap-1 px-2.5 py-1 rounded text-[11px] font-medium cursor-pointer transition-all"
                style={{ backgroundColor: !input.trim() || isLoading || !anyConfigured ? '#2d2d2d' : '#007acc', color: !input.trim() || isLoading || !anyConfigured ? '#5a5a5a' : '#fff' }}
              >
                {isLoading ? <Dots /> : <><svg width="10" height="10" viewBox="0 0 16 16" fill="none"><path d="M2 2L14 8L2 14V9L10 8L2 7V2Z" fill="currentColor" /></svg>Send</>}
              </button>
            </div>
          </div>
        </div>
        {/* Mode indicator */}
        <div className="flex items-center justify-center gap-2 mt-1">
          <span className="text-[9px]" style={{ color: '#3c3c3c' }}>
            {collabMode === 'all' && `→ ${enabledSlots.map(s => s.name).join(' + ')} respond together`}
            {collabMode === 'round-robin' && `→ agents take turns responding`}
            {collabMode === 'select' && `→ ${enabledSlots.find(s => s.id === selectedSlot)?.name || '?'} responds`}
          </span>
        </div>
      </div>

      {showSettings && <AISettingsModal slots={slots} onSave={setSlots} onClose={() => setShowSettings(false)} initialTab={settingsTab} />}
    </div>
  );
}

// ─── Empty State ─────────────────────────────────────────
function EmptyState({ slots, anyConfigured, onConfigure, onAction }: { slots: AISlot[]; anyConfigured: boolean; onConfigure: () => void; onAction: (p: string) => void }) {
  const enabled = slots.filter(s => s.enabled);
  return (
    <div className="flex flex-col items-center justify-center h-full text-center px-3">
      {/* 3 agent circles */}
      <div className="flex items-center gap-3 mb-4">
        {slots.map(s => (
          <div key={s.id} className="flex flex-col items-center gap-1">
            <div className="w-10 h-10 rounded-full flex items-center justify-center text-[16px] font-bold transition-all"
              style={{ backgroundColor: s.enabled ? s.color + '22' : '#2d2d2d', border: `2px solid ${s.enabled ? s.color : '#3c3c3c'}`, color: s.enabled ? s.color : '#5a5a5a' }}
            >{s.name.charAt(0)}</div>
            <span className="text-[9px] font-medium" style={{ color: s.enabled ? s.color : '#5a5a5a' }}>{s.name}</span>
            <span className="text-[8px]" style={{ color: '#5a5a5a' }}>{s.enabled ? PROVIDER_LABELS[s.config.provider] : 'Disabled'}</span>
          </div>
        ))}
      </div>
      {/* Connection lines */}
      {enabled.length >= 2 && (
        <div className="text-[9px] mb-3 px-3 py-1 rounded-full" style={{ backgroundColor: '#1e1e1e', color: '#6e6e6e' }}>
          {enabled.length} agents connected — collaborative mode
        </div>
      )}
      <h3 className="text-[13px] font-semibold mb-1" style={{ color: '#e0e0e0' }}>AI Team Workspace</h3>
      <p className="text-[11px] mb-3" style={{ color: '#6e6e6e' }}>
        {anyConfigured ? 'Send a message and all enabled agents will collaborate.' : 'Configure at least one agent to begin.'}
      </p>
      <div className="grid grid-cols-3 gap-1 w-full max-w-[320px]">
        {QUICK_ACTIONS.map((a, i) => (
          <button key={i} onClick={() => onAction(a.prompt)} className="flex items-center gap-1.5 px-2 py-1.5 rounded text-[10px] text-left cursor-pointer transition-colors"
            style={{ backgroundColor: '#2d2d2d', color: '#cccccc', border: '1px solid #3c3c3c' }}
            onMouseEnter={e => { e.currentTarget.style.borderColor = '#007acc'; }}
            onMouseLeave={e => { e.currentTarget.style.borderColor = '#3c3c3c'; }}
          ><span>{a.icon}</span><span>{a.label}</span></button>
        ))}
      </div>
      {!anyConfigured && (
        <button onClick={onConfigure} className="mt-3 px-4 py-1.5 rounded text-[11px] font-medium cursor-pointer" style={{ backgroundColor: '#007acc', color: '#fff' }}>⚙ Configure Agents</button>
      )}
    </div>
  );
}

// ─── Message Bubble ──────────────────────────────────────
function MessageBubble({ message }: { message: ChatMessage }) {
  const isUser = message.role === 'user';
  const isCollab = message.role === 'collab-status';
  const isStreaming = message.isStreaming;
  const color = message.slotColor || '#007acc';

  if (isCollab) {
    return (
      <div className="flex items-center justify-center py-1">
        <span className="text-[9px] px-3 py-0.5 rounded-full" style={{ backgroundColor: '#1e1e1e', color: '#5a5a5a' }}>{message.content}</span>
      </div>
    );
  }

  return (
    <div className={`flex flex-col ${isUser ? 'items-end' : 'items-start'}`}>
      <div className="flex items-center gap-1 mb-0.5 px-0.5">
        {!isUser && (
          <div className="w-3.5 h-3.5 rounded-full flex items-center justify-center text-[7px] font-bold" style={{ backgroundColor: color + '33', color, border: `1px solid ${color}55` }}>
            {(message.slotName || 'AI').charAt(0)}
          </div>
        )}
        <span className="text-[9px] font-medium" style={{ color: isUser ? '#6e6e6e' : color }}>
          {isUser ? 'You' : message.slotName || 'AI'}
          {message.model && !isUser && <span className="opacity-50 font-normal"> · {message.model}</span>}
        </span>
        {isUser && (
          <div className="w-3.5 h-3.5 rounded-full flex items-center justify-center" style={{ backgroundColor: '#3c3c3c' }}>
            <svg width="8" height="8" viewBox="0 0 16 16" fill="none"><circle cx="8" cy="5.5" r="3" stroke="#999" strokeWidth="1.2" fill="none" /><path d="M2.5 14C2.5 11 5 9 8 9C11 9 13.5 11 13.5 14" stroke="#999" strokeWidth="1.2" strokeLinecap="round" fill="none" /></svg>
          </div>
        )}
      </div>
      <div className="max-w-[96%] rounded-lg px-2.5 py-1.5 text-[12px] leading-[1.6]"
        style={{
          backgroundColor: isUser ? '#04395e' : '#1e1e1e',
          color: '#cccccc',
          borderLeft: !isUser ? `2px solid ${color}` : undefined,
          border: isUser ? '1px solid #065a9e' : `1px solid #2d2d2d`,
        }}
      >
        {isUser ? (
          <div className="whitespace-pre-wrap text-[12px]">{message.content}</div>
        ) : (
          <div>
            {message.content ? renderMarkdown(message.content) : null}
            {isStreaming && !message.content && <Dots color={color} />}
            {isStreaming && message.content && <span className="inline-block w-[2px] h-[12px] ml-0.5 animate-pulse" style={{ backgroundColor: color }} />}
          </div>
        )}
      </div>
      {!isUser && !isStreaming && message.tokensUsed && (
        <span className="text-[8px] mt-0.5 px-0.5" style={{ color: '#3c3c3c' }}>{message.tokensUsed} tokens</span>
      )}
    </div>
  );
}

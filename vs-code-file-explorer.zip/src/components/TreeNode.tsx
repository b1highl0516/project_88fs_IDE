import { useCallback } from 'react';
import { FileNode } from '../types';
import FileIcon from './FileIcon';

interface TreeNodeProps {
  node: FileNode;
  depth: number;
  isExpanded: boolean;
  isSelected: boolean;
  onToggleFolder: (id: string) => void;
  onSelect: (id: string, e: React.MouseEvent) => void;
  onContextMenu: (e: React.MouseEvent, node: FileNode) => void;
}

function ChevronIcon({ isOpen }: { isOpen: boolean }) {
  return (
    <svg
      width="16"
      height="16"
      viewBox="0 0 16 16"
      fill="none"
      className={`transition-transform duration-150 ${isOpen ? 'rotate-90' : ''}`}
    >
      <path d="M6 4L10 8L6 12" stroke="#c5c5c5" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export default function TreeNode({
  node,
  depth,
  isExpanded,
  isSelected,
  onToggleFolder,
  onSelect,
  onContextMenu,
}: TreeNodeProps) {
  const isFolder = node.type === 'folder';

  const handleClick = useCallback(
    (e: React.MouseEvent) => {
      e.stopPropagation();
      if (isFolder && !e.ctrlKey && !e.metaKey && !e.shiftKey) {
        onToggleFolder(node.id);
      }
      onSelect(node.id, e);
    },
    [isFolder, node.id, onToggleFolder, onSelect]
  );

  const handleContextMenu = useCallback(
    (e: React.MouseEvent) => {
      e.preventDefault();
      e.stopPropagation();
      onContextMenu(e, node);
    },
    [node, onContextMenu]
  );

  const handleChevronClick = useCallback(
    (e: React.MouseEvent) => {
      e.stopPropagation();
      onToggleFolder(node.id);
    },
    [node.id, onToggleFolder]
  );

  return (
    <div
      className="flex items-center cursor-pointer group relative"
      style={{
        paddingLeft: `${depth * 16 + 8}px`,
        height: '22px',
        backgroundColor: isSelected ? '#04395e' : 'transparent',
      }}
      onClick={handleClick}
      onContextMenu={handleContextMenu}
      onMouseEnter={(e) => {
        if (!isSelected) {
          (e.currentTarget as HTMLElement).style.backgroundColor = '#2a2d2e';
        }
      }}
      onMouseLeave={(e) => {
        if (!isSelected) {
          (e.currentTarget as HTMLElement).style.backgroundColor = 'transparent';
        }
      }}
    >
      {/* Indent guides */}
      {Array.from({ length: depth }).map((_, i) => (
        <div
          key={i}
          className="absolute top-0 bottom-0 w-px"
          style={{
            left: `${i * 16 + 16}px`,
            backgroundColor: '#404040',
          }}
        />
      ))}

      {/* Chevron for folders */}
      <span
        className="flex-shrink-0 flex items-center justify-center w-4 h-4"
        onClick={isFolder ? handleChevronClick : undefined}
      >
        {isFolder && <ChevronIcon isOpen={isExpanded} />}
      </span>

      {/* File/Folder icon */}
      <span className="flex-shrink-0 flex items-center mx-1">
        <FileIcon
          extension={node.extension}
          isFolder={isFolder}
          isOpen={isExpanded}
          name={node.name}
          size={16}
        />
      </span>

      {/* Name */}
      <span
        className="truncate text-[13px] leading-[22px]"
        style={{ color: '#cccccc' }}
      >
        {node.name}
      </span>
    </div>
  );
}

import { useState, useEffect } from 'react';
import { AISlot, AIProvider, DEFAULT_MODELS, DEFAULT_ENDPOINTS, PROVIDER_LABELS } from '../types';

interface AISettingsModalProps {
  slots: AISlot[];
  onSave: (slots: AISlot[]) => void;
  onClose: () => void;
  initialTab?: number;
}

const SLOT_COLOR_OPTIONS = [
  '#007acc', '#e5c07b', '#c678dd', '#e06c75', '#98c379',
  '#61afef', '#d19a66', '#56b6c2', '#e44d26', '#4ec9b0',
];

export default function AISettingsModal({ slots, onSave, onClose, initialTab }: AISettingsModalProps) {
  const [draft, setDraft] = useState<AISlot[]>(slots.map(s => ({ ...s, config: { ...s.config } })));
  const [activeTab, setActiveTab] = useState(initialTab ?? 0);
  const [showApiKey, setShowApiKey] = useState(false);
  const [testStatus, setTestStatus] = useState<Record<string, 'idle' | 'testing' | 'success' | 'error'>>({});
  const [testMsg, setTestMsg] = useState<Record<string, string>>({});

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [onClose]);

  const slot = draft[activeTab];

  const updateSlot = (partial: Partial<AISlot>) => {
    setDraft(prev => prev.map((s, i) => i === activeTab ? { ...s, ...partial } : s));
  };

  const updateConfig = (partial: Partial<AISlot['config']>) => {
    setDraft(prev => prev.map((s, i) => i === activeTab ? { ...s, config: { ...s.config, ...partial } } : s));
  };

  const handleProviderChange = (provider: AIProvider) => {
    updateConfig({
      provider,
      apiEndpoint: DEFAULT_ENDPOINTS[provider],
      model: DEFAULT_MODELS[provider][0],
    });
    setTestStatus(p => ({ ...p, [slot.id]: 'idle' }));
  };

  const handleTest = async () => {
    const id = slot.id;
    setTestStatus(p => ({ ...p, [id]: 'testing' }));
    setTestMsg(p => ({ ...p, [id]: '' }));
    const cfg = slot.config;
    try {
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (cfg.provider === 'anthropic') {
        headers['x-api-key'] = cfg.apiKey;
        headers['anthropic-version'] = '2023-06-01';
        headers['anthropic-dangerous-direct-browser-access'] = 'true';
        const res = await fetch(cfg.apiEndpoint, {
          method: 'POST', headers,
          body: JSON.stringify({ model: cfg.model, messages: [{ role: 'user', content: 'Say hi' }], max_tokens: 16 }),
        });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
      } else if (cfg.provider === 'google') {
        const ep = `https://generativelanguage.googleapis.com/v1beta/models/${cfg.model}:generateContent?key=${cfg.apiKey}`;
        const res = await fetch(ep, {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ contents: [{ role: 'user', parts: [{ text: 'Say hi' }] }], generationConfig: { maxOutputTokens: 16 } }),
        });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
      } else {
        if (cfg.apiKey) headers['Authorization'] = `Bearer ${cfg.apiKey}`;
        const res = await fetch(cfg.apiEndpoint, {
          method: 'POST', headers,
          body: JSON.stringify({ model: cfg.model, messages: [{ role: 'user', content: 'Say hi' }], max_tokens: 16 }),
        });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
      }
      setTestStatus(p => ({ ...p, [id]: 'success' }));
      setTestMsg(p => ({ ...p, [id]: 'Connected!' }));
    } catch (err: any) {
      setTestStatus(p => ({ ...p, [id]: 'error' }));
      setTestMsg(p => ({ ...p, [id]: err.message }));
    }
  };

  const ts = testStatus[slot.id] || 'idle';
  const tm = testMsg[slot.id] || '';

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center" onClick={onClose}>
      <div className="absolute inset-0 bg-black/60" />
      <div
        className="relative w-[640px] max-h-[88vh] rounded-lg shadow-2xl overflow-hidden flex flex-col"
        style={{ backgroundColor: '#252526', border: '1px solid #3c3c3c' }}
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3 flex-shrink-0" style={{ borderBottom: '1px solid #3c3c3c' }}>
          <div className="flex items-center gap-2">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
              <circle cx="12" cy="12" r="3" stroke="#007acc" strokeWidth="2" fill="none" />
              <path d="M12 2V5M12 19V22M2 12H5M19 12H22M4.93 4.93L7.05 7.05M16.95 16.95L19.07 19.07M19.07 4.93L16.95 7.05M7.05 16.95L4.93 19.07" stroke="#007acc" strokeWidth="2" strokeLinecap="round" />
            </svg>
            <span className="text-[14px] font-semibold" style={{ color: '#e0e0e0' }}>AI Multi-Agent Settings</span>
          </div>
          <button onClick={onClose} className="w-6 h-6 flex items-center justify-center rounded hover:bg-[#3c3c3c] cursor-pointer" style={{ color: '#969696' }}>✕</button>
        </div>

        {/* Slot Tabs */}
        <div className="flex items-center px-3 pt-2 gap-1 flex-shrink-0">
          {draft.map((s, i) => (
            <button
              key={s.id}
              onClick={() => { setActiveTab(i); setShowApiKey(false); }}
              className="flex items-center gap-2 px-3 py-1.5 rounded-t text-[12px] font-medium cursor-pointer transition-all"
              style={{
                backgroundColor: activeTab === i ? '#1e1e1e' : '#2d2d2d',
                color: activeTab === i ? '#ffffff' : '#969696',
                borderBottom: activeTab === i ? `2px solid ${s.color}` : '2px solid transparent',
              }}
            >
              <div className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ backgroundColor: s.color, opacity: s.enabled ? 1 : 0.3 }} />
              <span>{s.name}</span>
              {!s.enabled && <span className="text-[9px] opacity-50">OFF</span>}
            </button>
          ))}
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4" style={{ backgroundColor: '#1e1e1e', scrollbarWidth: 'thin', scrollbarColor: '#424242 transparent' }}>
          {/* Enable + Name + Color */}
          <div className="flex items-center gap-4">
            <button
              onClick={() => updateSlot({ enabled: !slot.enabled })}
              className="w-[42px] h-[22px] rounded-full relative cursor-pointer transition-colors duration-200 flex-shrink-0"
              style={{ backgroundColor: slot.enabled ? slot.color : '#3c3c3c' }}
            >
              <div className="w-[18px] h-[18px] rounded-full absolute top-[2px] transition-all duration-200" style={{ backgroundColor: '#ffffff', left: slot.enabled ? '22px' : '2px' }} />
            </button>
            <div className="flex-1">
              <label className="text-[10px] font-semibold uppercase tracking-wider block mb-1" style={{ color: '#6e6e6e' }}>Agent Name</label>
              <input
                type="text" value={slot.name}
                onChange={e => updateSlot({ name: e.target.value })}
                className="w-full px-2.5 py-1.5 rounded text-[13px] outline-none border"
                style={{ backgroundColor: '#252526', color: '#cccccc', borderColor: '#3c3c3c' }}
                onFocus={e => (e.target.style.borderColor = slot.color)}
                onBlur={e => (e.target.style.borderColor = '#3c3c3c')}
              />
            </div>
            <div>
              <label className="text-[10px] font-semibold uppercase tracking-wider block mb-1" style={{ color: '#6e6e6e' }}>Color</label>
              <div className="flex gap-1">
                {SLOT_COLOR_OPTIONS.map(c => (
                  <button key={c} onClick={() => updateSlot({ color: c })} className="w-5 h-5 rounded-full cursor-pointer transition-transform hover:scale-110" style={{ backgroundColor: c, outline: slot.color === c ? '2px solid #ffffff' : 'none', outlineOffset: '1px' }} />
                ))}
              </div>
            </div>
          </div>

          {/* Role */}
          <div>
            <label className="text-[10px] font-semibold uppercase tracking-wider mb-1 block" style={{ color: '#6e6e6e' }}>Role Description</label>
            <input
              type="text" value={slot.role}
              onChange={e => updateSlot({ role: e.target.value })}
              placeholder="e.g. Lead Architect, Code Reviewer..."
              className="w-full px-2.5 py-1.5 rounded text-[12px] outline-none border"
              style={{ backgroundColor: '#252526', color: '#cccccc', borderColor: '#3c3c3c' }}
              onFocus={e => (e.target.style.borderColor = slot.color)}
              onBlur={e => (e.target.style.borderColor = '#3c3c3c')}
            />
          </div>

          {/* Provider */}
          <div>
            <label className="text-[10px] font-semibold uppercase tracking-wider mb-1.5 block" style={{ color: '#6e6e6e' }}>Provider</label>
            <div className="grid grid-cols-5 gap-1.5">
              {(Object.keys(PROVIDER_LABELS) as AIProvider[]).map(p => (
                <button key={p} onClick={() => handleProviderChange(p)}
                  className="px-2 py-1.5 rounded text-[11px] font-medium transition-all cursor-pointer text-center"
                  style={{ backgroundColor: slot.config.provider === p ? slot.color : '#2d2d2d', color: slot.config.provider === p ? '#ffffff' : '#cccccc', border: `1px solid ${slot.config.provider === p ? slot.color : '#3c3c3c'}` }}
                >{PROVIDER_LABELS[p]}</button>
              ))}
            </div>
          </div>

          {/* API Key */}
          <div>
            <label className="text-[10px] font-semibold uppercase tracking-wider mb-1 block" style={{ color: '#6e6e6e' }}>
              API Key {slot.config.provider === 'custom' && <span className="opacity-50">(Optional)</span>}
            </label>
            <div className="relative">
              <input
                type={showApiKey ? 'text' : 'password'} value={slot.config.apiKey}
                onChange={e => updateConfig({ apiKey: e.target.value })}
                placeholder={`${PROVIDER_LABELS[slot.config.provider]} API key...`}
                className="w-full px-2.5 py-1.5 rounded text-[12px] outline-none border pr-14"
                style={{ backgroundColor: '#252526', color: '#cccccc', borderColor: '#3c3c3c' }}
                onFocus={e => (e.target.style.borderColor = slot.color)}
                onBlur={e => (e.target.style.borderColor = '#3c3c3c')}
              />
              <button onClick={() => setShowApiKey(!showApiKey)} className="absolute right-2 top-1/2 -translate-y-1/2 text-[10px] px-1.5 py-0.5 rounded cursor-pointer hover:bg-[#3c3c3c]" style={{ color: '#969696' }}>{showApiKey ? 'Hide' : 'Show'}</button>
            </div>
          </div>

          {/* Endpoint + Model */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] font-semibold uppercase tracking-wider mb-1 block" style={{ color: '#6e6e6e' }}>Endpoint</label>
              <input type="text" value={slot.config.apiEndpoint} onChange={e => updateConfig({ apiEndpoint: e.target.value })}
                className="w-full px-2.5 py-1.5 rounded text-[11px] outline-none border font-mono"
                style={{ backgroundColor: '#252526', color: '#cccccc', borderColor: '#3c3c3c' }}
                onFocus={e => (e.target.style.borderColor = slot.color)}
                onBlur={e => (e.target.style.borderColor = '#3c3c3c')}
              />
            </div>
            <div>
              <label className="text-[10px] font-semibold uppercase tracking-wider mb-1 block" style={{ color: '#6e6e6e' }}>Model</label>
              <div className="flex gap-1">
                <select value={slot.config.model} onChange={e => updateConfig({ model: e.target.value })}
                  className="flex-1 px-2 py-1.5 rounded text-[11px] outline-none border cursor-pointer appearance-none"
                  style={{ backgroundColor: '#252526', color: '#cccccc', borderColor: '#3c3c3c' }}
                >
                  {DEFAULT_MODELS[slot.config.provider].map(m => <option key={m} value={m}>{m}</option>)}
                </select>
                <input type="text" value={slot.config.model} onChange={e => updateConfig({ model: e.target.value })}
                  className="w-[120px] px-2 py-1.5 rounded text-[11px] outline-none border"
                  style={{ backgroundColor: '#252526', color: '#cccccc', borderColor: '#3c3c3c' }}
                  onFocus={e => (e.target.style.borderColor = slot.color)}
                  onBlur={e => (e.target.style.borderColor = '#3c3c3c')}
                  placeholder="Custom..."
                />
              </div>
            </div>
          </div>

          {/* Temp + MaxTokens + Stream */}
          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="text-[10px] font-semibold uppercase tracking-wider mb-1 block" style={{ color: '#6e6e6e' }}>Temperature: {slot.config.temperature.toFixed(1)}</label>
              <input type="range" min="0" max="2" step="0.1" value={slot.config.temperature} onChange={e => updateConfig({ temperature: parseFloat(e.target.value) })} className="w-full accent-[#007acc] cursor-pointer" style={{ accentColor: slot.color }} />
            </div>
            <div>
              <label className="text-[10px] font-semibold uppercase tracking-wider mb-1 block" style={{ color: '#6e6e6e' }}>Max Tokens</label>
              <input type="number" value={slot.config.maxTokens} onChange={e => updateConfig({ maxTokens: Math.max(1, parseInt(e.target.value) || 0) })}
                className="w-full px-2.5 py-1.5 rounded text-[11px] outline-none border"
                style={{ backgroundColor: '#252526', color: '#cccccc', borderColor: '#3c3c3c' }}
                onFocus={e => (e.target.style.borderColor = slot.color)}
                onBlur={e => (e.target.style.borderColor = '#3c3c3c')}
              />
            </div>
            <div className="flex items-end pb-1">
              <button onClick={() => updateConfig({ stream: !slot.config.stream })} className="flex items-center gap-2 cursor-pointer">
                <div className="w-[36px] h-[18px] rounded-full relative transition-colors duration-200" style={{ backgroundColor: slot.config.stream ? slot.color : '#3c3c3c' }}>
                  <div className="w-[14px] h-[14px] rounded-full absolute top-[2px] transition-all duration-200" style={{ backgroundColor: '#ffffff', left: slot.config.stream ? '20px' : '2px' }} />
                </div>
                <span className="text-[11px]" style={{ color: '#cccccc' }}>Stream</span>
              </button>
            </div>
          </div>

          {/* System Prompt */}
          <div>
            <label className="text-[10px] font-semibold uppercase tracking-wider mb-1 block" style={{ color: '#6e6e6e' }}>System Prompt</label>
            <textarea value={slot.config.systemPrompt} onChange={e => updateConfig({ systemPrompt: e.target.value })}
              rows={3}
              className="w-full px-2.5 py-2 rounded text-[11px] outline-none border resize-y font-mono leading-[1.5]"
              style={{ backgroundColor: '#252526', color: '#cccccc', borderColor: '#3c3c3c', minHeight: '60px' }}
              onFocus={e => (e.target.style.borderColor = slot.color)}
              onBlur={e => (e.target.style.borderColor = '#3c3c3c')}
            />
          </div>

          {/* Test */}
          <div className="rounded-lg p-2.5 flex items-center justify-between" style={{ backgroundColor: '#252526', border: '1px solid #3c3c3c' }}>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full" style={{ backgroundColor: ts === 'success' ? '#4ec9b0' : ts === 'error' ? '#f14c4c' : ts === 'testing' ? '#dcdcaa' : '#5a5a5a' }} />
              <span className="text-[11px]" style={{ color: ts === 'success' ? '#4ec9b0' : ts === 'error' ? '#f14c4c' : '#969696' }}>
                {ts === 'idle' && 'Not tested'}{ts === 'testing' && 'Testing...'}{ts === 'success' && tm}{ts === 'error' && tm}
              </span>
            </div>
            <button onClick={handleTest} disabled={ts === 'testing'} className="px-3 py-1 rounded text-[11px] font-medium cursor-pointer" style={{ backgroundColor: slot.color, color: '#ffffff', opacity: ts === 'testing' ? 0.5 : 1 }}>
              {ts === 'testing' ? '...' : 'Test'}
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-5 py-3 flex-shrink-0" style={{ borderTop: '1px solid #3c3c3c', backgroundColor: '#252526' }}>
          <div className="text-[11px] flex items-center gap-3" style={{ color: '#6e6e6e' }}>
            {draft.filter(s => s.enabled).length} of 3 agents enabled
          </div>
          <div className="flex items-center gap-3">
            <button onClick={onClose} className="px-4 py-1.5 rounded text-[12px] cursor-pointer hover:bg-[#3c3c3c]" style={{ color: '#cccccc', border: '1px solid #3c3c3c' }}>Cancel</button>
            <button onClick={() => { onSave(draft); onClose(); }} className="px-5 py-1.5 rounded text-[12px] font-medium cursor-pointer" style={{ backgroundColor: '#007acc', color: '#ffffff' }}>Save All</button>
          </div>
        </div>
      </div>
    </div>
  );
}

import { useEffect, useRef } from 'react';
import { ContextMenuAction, ContextMenuPosition } from '../types';

interface ContextMenuProps {
  position: ContextMenuPosition;
  actions: ContextMenuAction[];
  onClose: () => void;
}

export default function ContextMenu({ position, actions, onClose }: ContextMenuProps) {
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        onClose();
      }
    };
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    const handleScroll = () => onClose();

    document.addEventListener('mousedown', handleClick);
    document.addEventListener('keydown', handleKeyDown);
    document.addEventListener('scroll', handleScroll, true);

    return () => {
      document.removeEventListener('mousedown', handleClick);
      document.removeEventListener('keydown', handleKeyDown);
      document.removeEventListener('scroll', handleScroll, true);
    };
  }, [onClose]);

  // Adjust position to keep menu in viewport
  useEffect(() => {
    if (menuRef.current) {
      const rect = menuRef.current.getBoundingClientRect();
      const vw = window.innerWidth;
      const vh = window.innerHeight;

      if (rect.right > vw) {
        menuRef.current.style.left = `${position.x - rect.width}px`;
      }
      if (rect.bottom > vh) {
        menuRef.current.style.top = `${position.y - rect.height}px`;
      }
    }
  }, [position]);

  return (
    <div
      ref={menuRef}
      className="fixed z-[9999] min-w-[220px] py-1 rounded-md shadow-2xl border animate-in fade-in-0 zoom-in-95 duration-100"
      style={{
        left: position.x,
        top: position.y,
        backgroundColor: '#252526',
        borderColor: '#454545',
        boxShadow: '0 4px 25px rgba(0, 0, 0, 0.5)',
      }}
    >
      {actions.map((action, index) => (
        <div key={index}>
          <button
            className="w-full flex items-center gap-3 px-3 py-[6px] text-[13px] text-left transition-colors duration-75 cursor-pointer"
            style={{
              color: action.danger ? '#f14c4c' : '#cccccc',
            }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLButtonElement).style.backgroundColor = '#04395e';
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLButtonElement).style.backgroundColor = 'transparent';
            }}
            onClick={() => {
              action.action();
              onClose();
            }}
          >
            <span className="w-4 text-center opacity-70">{action.icon}</span>
            <span className="flex-1">{action.label}</span>
            {action.shortcut && (
              <span className="text-[11px] opacity-50 ml-6">{action.shortcut}</span>
            )}
          </button>
          {action.dividerAfter && (
            <div className="my-1 mx-2 border-t" style={{ borderColor: '#454545' }} />
          )}
        </div>
      ))}
    </div>
  );
}

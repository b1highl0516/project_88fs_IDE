import React from 'react';

interface FileIconProps {
  extension?: string;
  isFolder?: boolean;
  isOpen?: boolean;
  size?: number;
}

const iconColors: Record<string, string> = {
  ts: '#3178c6',
  tsx: '#3178c6',
  js: '#f7df1e',
  jsx: '#f7df1e',
  json: '#cbcb41',
  html: '#e34c26',
  css: '#563d7c',
  scss: '#c6538c',
  md: '#519aba',
  svg: '#ffb13b',
  png: '#a074c4',
  jpg: '#a074c4',
  jpeg: '#a074c4',
  gif: '#a074c4',
  ico: '#a074c4',
  yml: '#e44d26',
  yaml: '#e44d26',
  env: '#ecd53f',
  txt: '#89898a',
  woff2: '#ec6649',
  ttf: '#ec6649',
  lock: '#89898a',
  gitignore: '#f54d27',
  dockerfile: '#2496ed',
};

// SVG-based icons for different file types
function TypeScriptIcon({ size = 16 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none">
      <rect width="16" height="16" rx="2" fill="#3178c6" />
      <path d="M4.5 8.5H7.5V9.5H6.5V13H5.5V9.5H4.5V8.5Z" fill="white" />
      <path d="M8 12.2C8.3 12.7 8.8 13 9.5 13C10.3 13 11 12.5 11 11.7C11 10.8 10.3 10.5 9.7 10.2C9.2 10 8.8 9.8 8.8 9.4C8.8 9 9.1 8.8 9.5 8.8C9.8 8.8 10.1 9 10.3 9.3L11 8.8C10.7 8.3 10.2 8 9.5 8C8.7 8 8 8.5 8 9.3C8 10.1 8.7 10.5 9.2 10.7C9.7 10.9 10.2 11.1 10.2 11.6C10.2 12.1 9.9 12.3 9.5 12.3C9.1 12.3 8.7 12 8.5 11.7L8 12.2Z" fill="white" />
    </svg>
  );
}

function JavaScriptIcon({ size = 16 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none">
      <rect width="16" height="16" rx="2" fill="#f7df1e" />
      <path d="M5 8.5V12C5 12.5 4.8 13 4.2 13C3.7 13 3.4 12.7 3.2 12.3L4 11.8C4.1 12 4.2 12.2 4.3 12.2C4.5 12.2 4.5 12 4.5 11.8V8.5H5Z" fill="#323330" />
      <path d="M6.5 12.2C6.8 12.7 7.3 13 8 13C8.8 13 9.5 12.5 9.5 11.7C9.5 10.8 8.8 10.5 8.2 10.2C7.7 10 7.3 9.8 7.3 9.4C7.3 9 7.6 8.8 8 8.8C8.3 8.8 8.6 9 8.8 9.3L9.5 8.8C9.2 8.3 8.7 8 8 8C7.2 8 6.5 8.5 6.5 9.3C6.5 10.1 7.2 10.5 7.7 10.7C8.2 10.9 8.7 11.1 8.7 11.6C8.7 12.1 8.4 12.3 8 12.3C7.6 12.3 7.2 12 7 11.7L6.5 12.2Z" fill="#323330" />
    </svg>
  );
}

function JsonIcon({ size = 16 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none">
      <path d="M4 3C4 2.4 4.4 2 5 2H6L6.5 3H5V7.5L4 8.5L5 9.5V14H6.5L6 15H5C4.4 15 4 14.6 4 14V10L3 9V8L4 7V3Z" fill="#cbcb41" />
      <path d="M12 3C12 2.4 11.6 2 11 2H10L9.5 3H11V7.5L12 8.5L11 9.5V14H9.5L10 15H11C11.6 15 12 14.6 12 14V10L13 9V8L12 7V3Z" fill="#cbcb41" />
      <circle cx="7" cy="8.5" r="1" fill="#cbcb41" />
      <circle cx="9" cy="8.5" r="1" fill="#cbcb41" />
    </svg>
  );
}

function HtmlIcon({ size = 16 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none">
      <path d="M2 1L3.2 14L8 15.5L12.8 14L14 1H2Z" fill="#e34c26" opacity="0.9" />
      <path d="M8 2.5V14.3L11.8 13.2L12.8 2.5H8Z" fill="#ef652a" />
      <path d="M5.5 5.5H10.5L10.3 7.5H6L6.2 9.5H10L9.7 12.5L8 13L6.3 12.5L6.2 11H7.5L7.6 12L8 12.1L8.4 12L8.5 10H5.8L5.5 5.5Z" fill="white" />
    </svg>
  );
}

function CssIcon({ size = 16 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none">
      <path d="M2 1L3.2 14L8 15.5L12.8 14L14 1H2Z" fill="#1572b6" opacity="0.9" />
      <path d="M8 2.5V14.3L11.8 13.2L12.8 2.5H8Z" fill="#33a9dc" />
      <path d="M5.5 5.5H10.5L10.3 7.5H6L6.2 9.5H10L9.7 12.5L8 13L6.3 12.5L6.2 11H7.5L7.6 12L8 12.1L8.4 12L8.5 10H5.8L5.5 5.5Z" fill="white" />
    </svg>
  );
}

function MarkdownIcon({ size = 16 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none">
      <rect x="1" y="3" width="14" height="10" rx="1.5" stroke="#519aba" strokeWidth="1.2" fill="none" />
      <path d="M3.5 10.5V5.5L5.5 8L7.5 5.5V10.5" stroke="#519aba" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" fill="none" />
      <path d="M10 8.5L12 10.5L14 8.5" stroke="#519aba" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" fill="none" />
      <line x1="12" y1="5.5" x2="12" y2="10.5" stroke="#519aba" strokeWidth="1.2" strokeLinecap="round" />
    </svg>
  );
}

function ImageIcon({ size = 16 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none">
      <rect x="1.5" y="2.5" width="13" height="11" rx="1.5" stroke="#a074c4" strokeWidth="1.2" fill="none" />
      <circle cx="5" cy="6" r="1.5" fill="#a074c4" />
      <path d="M1.5 11L5 8L8 11L10.5 9L14.5 12" stroke="#a074c4" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" fill="none" />
    </svg>
  );
}

function YamlIcon({ size = 16 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none">
      <rect x="2" y="1" width="12" height="14" rx="1.5" fill="none" stroke="#e44d26" strokeWidth="1.2" />
      <path d="M5 5L7 7.5V10" stroke="#e44d26" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" fill="none" />
      <path d="M9 5L7 7.5" stroke="#e44d26" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" fill="none" />
      <line x1="5" y1="12" x2="11" y2="12" stroke="#e44d26" strokeWidth="1.2" strokeLinecap="round" />
    </svg>
  );
}

function SvgIcon({ size = 16 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none">
      <rect x="1.5" y="2.5" width="13" height="11" rx="1.5" stroke="#ffb13b" strokeWidth="1.2" fill="none" />
      <circle cx="8" cy="8" r="3" stroke="#ffb13b" strokeWidth="1.2" fill="none" />
      <path d="M5 8C5 6.3 6.3 5 8 5" stroke="#ffb13b" strokeWidth="1.2" strokeLinecap="round" fill="none" />
    </svg>
  );
}

function EnvIcon({ size = 16 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none">
      <path d="M8 1L14 4.5V11.5L8 15L2 11.5V4.5L8 1Z" stroke="#ecd53f" strokeWidth="1.2" fill="none" />
      <circle cx="8" cy="7" r="1.5" fill="#ecd53f" />
      <line x1="8" y1="9.5" x2="8" y2="12" stroke="#ecd53f" strokeWidth="1.5" strokeLinecap="round" />
    </svg>
  );
}

function DockerIcon({ size = 16 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none">
      <rect x="2" y="6" width="3" height="2.5" rx="0.3" stroke="#2496ed" strokeWidth="0.8" fill="none" />
      <rect x="5.5" y="6" width="3" height="2.5" rx="0.3" stroke="#2496ed" strokeWidth="0.8" fill="none" />
      <rect x="9" y="6" width="3" height="2.5" rx="0.3" stroke="#2496ed" strokeWidth="0.8" fill="none" />
      <rect x="2" y="3" width="3" height="2.5" rx="0.3" stroke="#2496ed" strokeWidth="0.8" fill="none" />
      <rect x="5.5" y="3" width="3" height="2.5" rx="0.3" stroke="#2496ed" strokeWidth="0.8" fill="none" />
      <path d="M1 10C1 10 2 13 8 13C14 13 14.5 10 14.5 10" stroke="#2496ed" strokeWidth="1.2" strokeLinecap="round" fill="none" />
    </svg>
  );
}

function GitIcon({ size = 16 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none">
      <path d="M14.5 7.3L8.7 1.5C8.3 1.1 7.7 1.1 7.3 1.5L1.5 7.3C1.1 7.7 1.1 8.3 1.5 8.7L7.3 14.5C7.7 14.9 8.3 14.9 8.7 14.5L14.5 8.7C14.9 8.3 14.9 7.7 14.5 7.3Z" fill="#f54d27" />
      <circle cx="8" cy="8" r="1.2" fill="white" />
      <circle cx="8" cy="4.5" r="0.8" fill="white" />
      <line x1="8" y1="5.3" x2="8" y2="6.8" stroke="white" strokeWidth="0.8" />
      <circle cx="10.5" cy="10" r="0.8" fill="white" />
      <line x1="8.8" y1="8.8" x2="10" y2="9.5" stroke="white" strokeWidth="0.8" />
    </svg>
  );
}

function ScssIcon({ size = 16 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none">
      <circle cx="8" cy="8" r="7" fill="#c6538c" />
      <path d="M5 10.5C5.3 11 6 11.3 6.8 11C7.8 10.5 7.5 9.5 6.5 9C5.5 8.5 5 7.5 5.5 6.5C6 5.5 7.5 5 8.5 5.5C9.3 5.8 9.8 6.5 10 7" stroke="white" strokeWidth="1.2" strokeLinecap="round" fill="none" />
    </svg>
  );
}

function FontIcon({ size = 16 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none">
      <rect x="2" y="2" width="12" height="12" rx="2" stroke="#ec6649" strokeWidth="1.2" fill="none" />
      <path d="M5 12L8 4L11 12" stroke="#ec6649" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" fill="none" />
      <line x1="6" y1="10" x2="10" y2="10" stroke="#ec6649" strokeWidth="1.2" strokeLinecap="round" />
    </svg>
  );
}

function DefaultFileIcon({ size = 16, color = '#89898a' }: { size?: number; color?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none">
      <path d="M4 1.5H10L13 4.5V14C13 14.3 12.7 14.5 12.5 14.5H4C3.7 14.5 3.5 14.3 3.5 14V2C3.5 1.7 3.7 1.5 4 1.5Z" stroke={color} strokeWidth="1.2" fill="none" />
      <path d="M10 1.5V4.5H13" stroke={color} strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" fill="none" />
    </svg>
  );
}

function FolderIcon({ isOpen, size = 16 }: { isOpen: boolean; size?: number }) {
  if (isOpen) {
    return (
      <svg width={size} height={size} viewBox="0 0 16 16" fill="none">
        <path d="M1.5 3.5C1.5 2.9 2 2.5 2.5 2.5H6L7.5 4.5H13C13.6 4.5 14 4.9 14 5.5V6H3L1.5 13V3.5Z" fill="#dcb67a" opacity="0.8" />
        <path d="M2 6H14L12.5 13.5H1L2 6Z" fill="#dcb67a" />
      </svg>
    );
  }
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none">
      <path d="M1.5 3C1.5 2.4 2 2 2.5 2H6.5L8 4H13.5C14 4 14.5 4.4 14.5 5V13C14.5 13.6 14 14 13.5 14H2.5C2 14 1.5 13.6 1.5 13V3Z" fill="#dcb67a" />
    </svg>
  );
}

export function getFileIcon(extension?: string, isFolder?: boolean, isOpen?: boolean, size: number = 16): React.ReactNode {
  if (isFolder) {
    return <FolderIcon isOpen={isOpen || false} size={size} />;
  }

  switch (extension) {
    case 'ts':
    case 'tsx':
      return <TypeScriptIcon size={size} />;
    case 'js':
    case 'jsx':
      return <JavaScriptIcon size={size} />;
    case 'json':
      return <JsonIcon size={size} />;
    case 'html':
      return <HtmlIcon size={size} />;
    case 'css':
      return <CssIcon size={size} />;
    case 'scss':
    case 'sass':
      return <ScssIcon size={size} />;
    case 'md':
      return <MarkdownIcon size={size} />;
    case 'svg':
      return <SvgIcon size={size} />;
    case 'png':
    case 'jpg':
    case 'jpeg':
    case 'gif':
    case 'ico':
      return <ImageIcon size={size} />;
    case 'yml':
    case 'yaml':
      return <YamlIcon size={size} />;
    case 'woff2':
    case 'woff':
    case 'ttf':
    case 'eot':
      return <FontIcon size={size} />;
    default:
      break;
  }

  // Match by filename patterns handled via extension fallbacks
  const color = extension ? iconColors[extension] || '#89898a' : '#89898a';
  return <DefaultFileIcon size={size} color={color} />;
}

export function getSpecialFileIcon(name: string, size: number = 16): React.ReactNode | null {
  const lower = name.toLowerCase();
  if (lower === 'dockerfile' || lower.startsWith('docker-compose')) {
    return <DockerIcon size={size} />;
  }
  if (lower === '.gitignore' || lower === '.gitmodules' || lower === '.gitattributes') {
    return <GitIcon size={size} />;
  }
  if (lower === '.env' || lower.startsWith('.env.')) {
    return <EnvIcon size={size} />;
  }
  if (lower === '.eslintrc.json' || lower === '.eslintrc.js' || lower === '.eslintrc') {
    return (
      <svg width={size} height={size} viewBox="0 0 16 16" fill="none">
        <path d="M8 1L14.5 4.75V12.25L8 16L1.5 12.25V4.75L8 1Z" fill="#4b32c3" />
        <path d="M8 4L12 6.25V10.75L8 13L4 10.75V6.25L8 4Z" fill="white" fillOpacity="0.5" />
      </svg>
    );
  }
  if (lower === '.prettierrc' || lower === '.prettierrc.json') {
    return (
      <svg width={size} height={size} viewBox="0 0 16 16" fill="none">
        <rect x="1" y="1" width="14" height="14" rx="2" fill="#1a2b34" />
        <rect x="3" y="3.5" width="6" height="1.5" rx="0.5" fill="#56b3b4" />
        <rect x="3" y="6.5" width="10" height="1.5" rx="0.5" fill="#ea5e5e" />
        <rect x="3" y="9.5" width="4" height="1.5" rx="0.5" fill="#bf85bf" />
        <rect x="8.5" y="9.5" width="4.5" height="1.5" rx="0.5" fill="#f7ce68" />
      </svg>
    );
  }
  if (lower === 'license' || lower === 'licence') {
    return (
      <svg width={size} height={size} viewBox="0 0 16 16" fill="none">
        <path d="M4 1.5H10L13 4.5V14C13 14.3 12.7 14.5 12.5 14.5H4C3.7 14.5 3.5 14.3 3.5 14V2C3.5 1.7 3.7 1.5 4 1.5Z" stroke="#d4aa00" strokeWidth="1.2" fill="none" />
        <path d="M10 1.5V4.5H13" stroke="#d4aa00" strokeWidth="1.2" fill="none" />
        <circle cx="8" cy="9" r="2.5" stroke="#d4aa00" strokeWidth="1" fill="none" />
        <path d="M6.5 11L6 14L8 13L10 14L9.5 11" stroke="#d4aa00" strokeWidth="1" fill="none" />
      </svg>
    );
  }
  return null;
}

export default function FileIcon({ extension, isFolder, isOpen, size = 16, name }: FileIconProps & { name?: string }) {
  // Check special file names first
  if (name && !isFolder) {
    const specialIcon = getSpecialFileIcon(name, size);
    if (specialIcon) return <span className="flex-shrink-0 flex items-center">{specialIcon}</span>;
  }

  return <span className="flex-shrink-0 flex items-center">{getFileIcon(extension, isFolder, isOpen, size)}</span>;
}

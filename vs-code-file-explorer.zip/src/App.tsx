// ═══════════════════════════════════════════════════════════════════════════
// VS Code AI Team - Main Application with Routing
// ═══════════════════════════════════════════════════════════════════════════

import { useState } from 'react';
import { RouterProvider, Link, useLocation, useNavigate } from './router';
import { routes } from './routes';
import FileExplorer from './components/FileExplorer';
import AIChatPanel from './components/AIChatPanel';

type SidebarView = 'explorer' | 'search' | 'git' | 'debug' | 'extensions';

export default function App() {
  return (
    <RouterProvider
      routes={routes}
      onNavigate={(path, prev) => {
        console.log(`[Router] ${prev} → ${path}`);
      }}
    >
      <MainLayout />
    </RouterProvider>
  );
}

function MainLayout() {
  const location = useLocation();
  const [sidebarView, setSidebarView] = useState<SidebarView>('explorer');
  const [showAIPanel, setShowAIPanel] = useState(false);

  // Determine if AI panel should be shown based on route
  const isAIRoute = location.path.startsWith('/ai');
  const isSettingsRoute = location.path.startsWith('/settings');
  const isAnalysisRoute = location.path.startsWith('/analysis');
  const isSetupRoute = location.path.startsWith('/setup');
  const isFullLayout = isSettingsRoute || isAnalysisRoute || isSetupRoute;

  return (
    <div className="h-screen w-screen flex flex-col overflow-hidden" style={{ backgroundColor: '#1e1e1e', color: '#cccccc' }}>
      {/* Title Bar */}
      <TitleBar currentPath={location.path} />

      {/* Main Content */}
      <div className="flex flex-1 overflow-hidden">
        {/* Activity Bar */}
        <ActivityBar
          sidebarView={sidebarView}
          setSidebarView={setSidebarView}
          showAIPanel={showAIPanel || isAIRoute}
          setShowAIPanel={setShowAIPanel}
          currentPath={location.path}
        />

        {/* Left Sidebar - hide on settings/analysis */}
        {!isFullLayout && (
          <div className="flex flex-col flex-shrink-0" style={{ width: '260px', backgroundColor: '#252526', borderRight: '1px solid #1e1e1e' }}>
            {sidebarView === 'explorer' && <FileExplorer />}
            {sidebarView === 'search' && <SearchPanel />}
            {sidebarView === 'git' && <GitPanel />}
            {sidebarView === 'debug' && <DebugPanel />}
            {sidebarView === 'extensions' && <ExtensionsPanel />}
          </div>
        )}

        {/* Main Content Area - Route renders here */}
        <div className="flex-1 flex flex-col overflow-hidden min-w-0">
          {/* Route-based content is rendered via RouterProvider */}
        </div>

        {/* AI Panel (Right Sidebar) - show when toggled or on AI route */}
        {(showAIPanel || isAIRoute) && !isFullLayout && (
          <div className="flex-shrink-0 flex flex-col" style={{ width: '380px', borderLeft: '1px solid #1e1e1e', backgroundColor: '#252526' }}>
            <AIChatPanel />
          </div>
        )}
      </div>

      {/* Bottom Panel / Terminal */}
      <BottomPanel />

      {/* Status Bar */}
      <StatusBar
        path={location.path}
        showAIPanel={showAIPanel || isAIRoute}
        toggleAIPanel={() => setShowAIPanel(p => !p)}
      />
    </div>
  );
}

// ─── Title Bar ───────────────────────────────────────────────────────────────
function TitleBar({ currentPath }: { currentPath: string }) {
  return (
    <div className="h-[30px] flex items-center px-4 text-[12px] flex-shrink-0" style={{ backgroundColor: '#323233', color: '#969696' }}>
      <div className="flex items-center gap-3 flex-1">
        <div className="flex items-center gap-2">
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
            <path d="M1 3.5L5.5 1L15 5.5L10.5 8L15 10.5L5.5 15L1 12.5V3.5Z" fill="#007acc" />
            <path d="M5.5 1L15 5.5L10.5 8L1 3.5L5.5 1Z" fill="#2ba0f5" />
          </svg>
          <span>VS Code</span>
        </div>
        <div className="flex items-center gap-3 text-[12px]">
          <Link to="/" className="hover:text-white cursor-pointer">Home</Link>
          <Link to="/editor" className="hover:text-white cursor-pointer">Editor</Link>
          <Link to="/ai" className="hover:text-white cursor-pointer">AI</Link>
          <Link to="/routing" className="hover:text-white cursor-pointer">Routing</Link>
          <Link to="/analysis" className="hover:text-white cursor-pointer">Analysis</Link>
          <Link to="/setup" className="hover:text-white cursor-pointer" style={{ color: '#e5c07b' }}>🔑 Setup</Link>
          <Link to="/settings" className="hover:text-white cursor-pointer">Settings</Link>
        </div>
      </div>
      <div className="text-center flex-1">
        <span className="text-[12px]">{currentPath} — VS Code AI Team</span>
      </div>
      <div className="flex items-center gap-0 flex-1 justify-end">
        <button className="w-[46px] h-[30px] flex items-center justify-center hover:bg-[#505050] cursor-pointer">
          <svg width="10" height="1" viewBox="0 0 10 1"><rect width="10" height="1" fill="#969696" /></svg>
        </button>
        <button className="w-[46px] h-[30px] flex items-center justify-center hover:bg-[#505050] cursor-pointer">
          <svg width="10" height="10" viewBox="0 0 10 10"><rect x="0.5" y="0.5" width="9" height="9" stroke="#969696" fill="none" /></svg>
        </button>
        <button className="w-[46px] h-[30px] flex items-center justify-center hover:bg-[#c42b1c] cursor-pointer">
          <svg width="10" height="10" viewBox="0 0 10 10"><line x1="1" y1="1" x2="9" y2="9" stroke="#969696" strokeWidth="1.2" /><line x1="9" y1="1" x2="1" y2="9" stroke="#969696" strokeWidth="1.2" /></svg>
        </button>
      </div>
    </div>
  );
}

// ─── Activity Bar ────────────────────────────────────────────────────────────
function ActivityBar({
  sidebarView,
  setSidebarView,
  showAIPanel,
  setShowAIPanel,
  currentPath,
}: {
  sidebarView: SidebarView;
  setSidebarView: (v: SidebarView) => void;
  showAIPanel: boolean;
  setShowAIPanel: (v: boolean) => void;
  currentPath: string;
}) {
  const navigate = useNavigate();

  return (
    <div className="w-12 flex flex-col items-center py-1 flex-shrink-0" style={{ backgroundColor: '#333333' }}>
      <ActivityBarIcon active={sidebarView === 'explorer'} title="Explorer" onClick={() => setSidebarView('explorer')}>
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M17.5 0H8.5L7 1.5V6H2.5L1 7.5V22.07L2.5 23.57H13.5L15 22.07V17.57H20L21.5 16.07V4.5L17.5 0Z" fill="currentColor" /></svg>
      </ActivityBarIcon>
      <ActivityBarIcon active={sidebarView === 'search'} title="Search" onClick={() => setSidebarView('search')}>
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none"><circle cx="10" cy="10" r="6" stroke="currentColor" strokeWidth="2" fill="none" /><line x1="14.5" y1="14.5" x2="20" y2="20" stroke="currentColor" strokeWidth="2" strokeLinecap="round" /></svg>
      </ActivityBarIcon>
      <ActivityBarIcon active={sidebarView === 'git'} title="Source Control" onClick={() => setSidebarView('git')} badge="3">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none"><circle cx="8" cy="6" r="2.5" stroke="currentColor" strokeWidth="1.5" fill="none" /><circle cx="8" cy="18" r="2.5" stroke="currentColor" strokeWidth="1.5" fill="none" /><circle cx="16" cy="12" r="2.5" stroke="currentColor" strokeWidth="1.5" fill="none" /></svg>
      </ActivityBarIcon>
      <ActivityBarIcon active={currentPath === '/routing'} title="Routing Demo" onClick={() => navigate('/routing')}>
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
          <path d="M4 6H14M14 6L10 2M14 6L10 10" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M20 18H10M10 18L14 14M10 18L14 22" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
          <circle cx="4" cy="18" r="2" stroke="currentColor" strokeWidth="1.5" fill="none" />
          <circle cx="20" cy="6" r="2" stroke="currentColor" strokeWidth="1.5" fill="none" />
        </svg>
      </ActivityBarIcon>
      <ActivityBarIcon active={currentPath === '/analysis'} title="Route Analysis" onClick={() => navigate('/analysis')}>
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
          <circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="1.5" fill="none" />
          <circle cx="12" cy="12" r="4" stroke="currentColor" strokeWidth="1" strokeDasharray="2 2" fill="none" />
          <circle cx="12" cy="12" r="1.5" fill="currentColor" />
          <line x1="12" y1="3" x2="12" y2="6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
          <line x1="12" y1="18" x2="12" y2="21" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
          <line x1="3" y1="12" x2="6" y2="12" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
          <line x1="18" y1="12" x2="21" y2="12" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
        </svg>
      </ActivityBarIcon>

      <div className="flex-1" />

      {/* AI Team */}
      <ActivityBarIcon active={showAIPanel} title="AI Team" onClick={() => setShowAIPanel(!showAIPanel)}>
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
          <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="1.5" fill="none" />
          <circle cx="7" cy="9" r="1.5" fill="currentColor" />
          <circle cx="12" cy="7" r="1.5" fill="currentColor" />
          <circle cx="17" cy="9" r="1.5" fill="currentColor" />
          <path d="M7 15C8.5 17 10 18 12 18C14 18 15.5 17 17 15" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" fill="none" />
        </svg>
      </ActivityBarIcon>

      <ActivityBarIcon active={currentPath.startsWith('/settings')} title="Settings" onClick={() => navigate('/settings')}>
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="3" stroke="currentColor" strokeWidth="1.5" fill="none" /><path d="M12 2V5M12 19V22M2 12H5M19 12H22" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" /></svg>
      </ActivityBarIcon>
    </div>
  );
}

function ActivityBarIcon({ children, active = false, title, onClick, badge }: { children: React.ReactNode; active?: boolean; title: string; onClick?: () => void; badge?: string }) {
  return (
    <button className="w-12 h-12 flex items-center justify-center relative cursor-pointer transition-all" style={{ color: active ? '#ffffff' : '#858585', opacity: active ? 1 : 0.6 }} title={title} onClick={onClick}>
      {active && <div className="absolute left-0 top-1 bottom-1 w-[2px]" style={{ backgroundColor: '#ffffff' }} />}
      {children}
      {badge && <div className="absolute top-1.5 right-1.5 min-w-[16px] h-[16px] rounded-full flex items-center justify-center text-[10px] font-bold px-1" style={{ backgroundColor: '#007acc', color: '#ffffff' }}>{badge}</div>}
    </button>
  );
}

// ─── Bottom Panel ────────────────────────────────────────────────────────────
function BottomPanel() {
  return (
    <div className="h-[100px] flex-shrink-0 flex flex-col" style={{ borderTop: '1px solid #007acc' }}>
      <div className="flex items-center h-[30px] px-4 gap-4 text-[12px] flex-shrink-0" style={{ backgroundColor: '#1e1e1e', color: '#969696' }}>
        <span className="cursor-pointer hover:text-white">Problems</span>
        <span className="cursor-pointer hover:text-white">Output</span>
        <span className="pb-[2px]" style={{ color: '#ffffff', borderBottom: '1px solid #ffffff' }}>Terminal</span>
      </div>
      <div className="flex-1 px-4 py-2 text-[12px] overflow-auto" style={{ backgroundColor: '#1e1e1e', fontFamily: 'monospace' }}>
        <div style={{ color: '#6a9955' }}>~/my-project $</div>
        <div style={{ color: '#cccccc' }}>Router loaded • {routes.length} routes registered</div>
        <div style={{ color: '#4ec9b0' }}>✓ Hash-based routing active</div>
      </div>
    </div>
  );
}

// ─── Status Bar ──────────────────────────────────────────────────────────────
function StatusBar({ path, showAIPanel, toggleAIPanel }: { path: string; showAIPanel: boolean; toggleAIPanel: () => void }) {
  return (
    <div className="h-[22px] flex items-center justify-between px-3 text-[12px] flex-shrink-0" style={{ backgroundColor: '#007acc', color: '#ffffff' }}>
      <div className="flex items-center gap-3">
        <span className="flex items-center gap-1">
          <svg width="12" height="12" viewBox="0 0 16 16" fill="none"><path d="M14.5 7.3L8.7 1.5C8.3 1.1 7.7 1.1 7.3 1.5L1.5 7.3C1.1 7.7 1.1 8.3 1.5 8.7L7.3 14.5C7.7 14.9 8.3 14.9 8.7 14.5L14.5 8.7C14.9 8.3 14.9 7.7 14.5 7.3Z" fill="white" /></svg>
          main
        </span>
        <span className="text-[11px] opacity-75">Route: {path}</span>
      </div>
      <div className="flex items-center gap-4">
        <span className="flex items-center gap-1.5 cursor-pointer hover:bg-[#0065a9] px-2 py-0.5 rounded-sm" onClick={toggleAIPanel}>
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none">
            <circle cx="12" cy="12" r="9" stroke="white" strokeWidth="1.5" fill="none" />
            <circle cx="7" cy="9" r="1.2" fill="white" /><circle cx="12" cy="7" r="1.2" fill="white" /><circle cx="17" cy="9" r="1.2" fill="white" />
          </svg>
          AI {showAIPanel ? 'ON' : 'OFF'}
        </span>
        <span>🔀 Router Active</span>
      </div>
    </div>
  );
}

// ─── Sidebar Panels ──────────────────────────────────────────────────────────
function SearchPanel() {
  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center px-4 h-[35px] uppercase text-[11px] font-semibold tracking-wider" style={{ color: '#bbbbbb', borderBottom: '1px solid #1e1e1e' }}>Search</div>
      <div className="px-3 py-3">
        <input type="text" placeholder="Search files..." className="w-full px-2 py-1.5 rounded text-[12px] outline-none" style={{ backgroundColor: '#3c3c3c', color: '#cccccc', border: '1px solid #4a4a4a' }} />
      </div>
      <div className="flex-1 flex items-center justify-center text-[11px]" style={{ color: '#5a5a5a' }}>Type to search</div>
    </div>
  );
}

function GitPanel() {
  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center px-4 h-[35px] uppercase text-[11px] font-semibold tracking-wider" style={{ color: '#bbbbbb', borderBottom: '1px solid #1e1e1e' }}>Source Control</div>
      <div className="px-3 py-3">
        <input type="text" placeholder="Commit message..." className="w-full px-2 py-1.5 rounded text-[12px] outline-none" style={{ backgroundColor: '#3c3c3c', color: '#cccccc' }} />
        <button className="w-full mt-2 py-1.5 rounded text-[12px] font-medium cursor-pointer" style={{ backgroundColor: '#007acc', color: '#fff' }}>✓ Commit</button>
      </div>
      <div className="px-3">
        <div className="text-[10px] uppercase font-semibold tracking-wider mb-1" style={{ color: '#969696' }}>Changes (3)</div>
        {['router/Router.tsx', 'routes/index.tsx', 'views/'].map((f, i) => (
          <div key={i} className="flex items-center gap-2 py-1 text-[11px] rounded hover:bg-[#2a2d2e]" style={{ color: '#cccccc' }}>
            <span style={{ color: '#73c991' }}>M</span><span>{f}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function DebugPanel() {
  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center px-4 h-[35px] uppercase text-[11px] font-semibold tracking-wider" style={{ color: '#bbbbbb', borderBottom: '1px solid #1e1e1e' }}>Debug</div>
      <div className="flex-1 flex flex-col items-center justify-center px-6 text-center">
        <div className="text-[32px] mb-3 opacity-30">▶</div>
        <button className="px-4 py-1.5 rounded text-[11px] cursor-pointer" style={{ backgroundColor: '#007acc', color: '#fff' }}>Start Debugging</button>
      </div>
    </div>
  );
}

function ExtensionsPanel() {
  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center px-4 h-[35px] uppercase text-[11px] font-semibold tracking-wider" style={{ color: '#bbbbbb', borderBottom: '1px solid #1e1e1e' }}>Extensions</div>
      <div className="px-3 py-3">
        <input type="text" placeholder="Search..." className="w-full px-2 py-1.5 rounded text-[12px] outline-none" style={{ backgroundColor: '#3c3c3c', color: '#cccccc' }} />
      </div>
      <div className="flex-1 overflow-y-auto px-2">
        {[
          { name: 'Router', icon: '🔀', on: true },
          { name: 'AI Team', icon: '🤖', on: true },
          { name: 'ESLint', icon: '📏', on: true },
        ].map((e, i) => (
          <div key={i} className="flex items-center gap-2 p-2 rounded hover:bg-[#2a2d2e]" style={{ color: '#cccccc' }}>
            <span className="text-[16px]">{e.icon}</span>
            <span className="text-[11px] flex-1">{e.name}</span>
            <div className="w-2 h-2 rounded-full" style={{ backgroundColor: '#4ec9b0' }} />
          </div>
        ))}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// AI 工作區視圖 - AI Workspace View
// ═══════════════════════════════════════════════════════════════════════════

import { RouteComponentProps, Link, useNavigate } from '../router';
import AIChatPanel from '../components/AIChatPanel';

export default function AIWorkspaceView({ params }: RouteComponentProps) {
  const navigate = useNavigate();
  const sessionId = params.sessionId;

  return (
    <div className="h-full flex flex-col" style={{ backgroundColor: '#1e1e1e' }}>
      {/* Header */}
      <div className="flex items-center justify-between px-4 h-[35px] flex-shrink-0" style={{ backgroundColor: '#252526', borderBottom: '1px solid #1e1e1e' }}>
        <div className="flex items-center gap-3">
          <Link to="/" className="text-[12px] hover:underline" style={{ color: '#007acc' }}>Home</Link>
          <span style={{ color: '#3c3c3c' }}>/</span>
          <span className="text-[12px] font-medium" style={{ color: '#cccccc' }}>AI Workspace</span>
          {sessionId && (
            <>
              <span style={{ color: '#3c3c3c' }}>/</span>
              <span className="text-[12px]" style={{ color: '#969696' }}>Session: {sessionId}</span>
            </>
          )}
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => navigate('/ai/new-' + Date.now())}
            className="px-2 py-1 rounded text-[11px] cursor-pointer"
            style={{ backgroundColor: '#007acc', color: '#ffffff' }}
          >
            + New Session
          </button>
        </div>
      </div>

      {/* AI Panel - Full Width */}
      <div className="flex-1 overflow-hidden">
        <AIChatPanel />
      </div>
    </div>
  );
}

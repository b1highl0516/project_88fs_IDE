// ═══════════════════════════════════════════════════════════════════════════
// 編輯器視圖 - Editor View
// ═══════════════════════════════════════════════════════════════════════════

import { Link, RouteComponentProps } from '../router';

const SAMPLE_FILES = [
  { id: 'app', name: 'App.tsx', icon: '📄', lang: 'tsx' },
  { id: 'router', name: 'Router.tsx', icon: '📄', lang: 'tsx' },
  { id: 'types', name: 'types.ts', icon: '📄', lang: 'ts' },
  { id: 'readme', name: 'README.md', icon: '📝', lang: 'md' },
  { id: 'package', name: 'package.json', icon: '📦', lang: 'json' },
];

export default function EditorView({ }: RouteComponentProps) {
  return (
    <div className="h-full flex flex-col" style={{ backgroundColor: '#1e1e1e' }}>
      {/* Tabs */}
      <div className="flex items-center h-[35px] flex-shrink-0 overflow-x-auto" style={{ backgroundColor: '#2d2d2d' }}>
        {SAMPLE_FILES.slice(0, 3).map(file => (
          <Link
            key={file.id}
            to={`/editor/${file.id}`}
            className="flex items-center gap-2 px-3 h-[35px] text-[13px] border-r flex-shrink-0"
            style={{ backgroundColor: '#2d2d2d', color: '#969696', borderColor: '#252526' }}
            activeStyle={{ backgroundColor: '#1e1e1e', color: '#ffffff', borderTop: '1px solid #007acc' }}
          >
            <span>{file.icon}</span>
            <span>{file.name}</span>
          </Link>
        ))}
      </div>

      {/* Content */}
      <div className="flex-1 flex items-center justify-center">
        <div className="text-center">
          <div className="text-[48px] mb-4 opacity-30">📂</div>
          <div className="text-[14px] mb-2" style={{ color: '#cccccc' }}>Select a file to edit</div>
          <div className="text-[12px] mb-4" style={{ color: '#6e6e6e' }}>
            Click on a file in the explorer or choose from below
          </div>

          <div className="flex flex-col gap-1 items-center">
            {SAMPLE_FILES.map(file => (
              <Link
                key={file.id}
                to={`/editor/${file.id}`}
                className="flex items-center gap-2 px-3 py-1.5 rounded text-[12px] transition-colors w-[200px]"
                style={{ backgroundColor: '#252526', color: '#cccccc' }}
                activeStyle={{ backgroundColor: '#007acc', color: '#ffffff' }}
              >
                <span>{file.icon}</span>
                <span>{file.name}</span>
                <span className="flex-1" />
                <span className="text-[10px] opacity-50">.{file.lang}</span>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

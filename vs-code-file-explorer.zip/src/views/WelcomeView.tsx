// ═══════════════════════════════════════════════════════════════════════════
// 歡迎視圖 - Welcome View
// ═══════════════════════════════════════════════════════════════════════════

import { Link, RouteComponentProps } from '../router';

export default function WelcomeView({ }: RouteComponentProps) {
  return (
    <div className="h-full flex flex-col items-center justify-center px-8" style={{ backgroundColor: '#1e1e1e' }}>
      {/* VS Code Logo */}
      <div className="mb-6">
        <svg width="80" height="80" viewBox="0 0 100 100" fill="none">
          <path d="M75 12.5L37.5 50L75 87.5L87.5 81.25V18.75L75 12.5Z" fill="#007ACC" />
          <path d="M37.5 50L75 12.5L62.5 6.25L12.5 50L62.5 93.75L75 87.5L37.5 50Z" fill="#2BA0F5" />
          <path d="M62.5 93.75L75 87.5L75 12.5L62.5 6.25V93.75Z" fill="#0065A9" />
          <path d="M12.5 50L37.5 75V25L12.5 50Z" fill="#1A7FD4" />
        </svg>
      </div>

      <h1 className="text-[24px] font-light mb-2" style={{ color: '#cccccc' }}>
        Welcome to VS Code
      </h1>
      <p className="text-[13px] mb-8" style={{ color: '#6e6e6e' }}>
        AI-Powered Multi-Agent Development Environment
      </p>

      {/* Feature Grid */}
      <div className="grid grid-cols-3 gap-3 w-full max-w-[640px] mb-8">
        <FeatureCard
          to="/editor"
          icon="📝"
          title="Editor"
          description="Open files and start coding"
        />
        <FeatureCard
          to="/ai"
          icon="🤖"
          title="AI Team"
          description="3 AI agents working together"
        />
        <FeatureCard
          to="/routing"
          icon="🔀"
          title="Routing Demo"
          description="Explore the routing system"
        />
        <FeatureCard
          to="/analysis"
          icon="⚡"
          title="Performance"
          description="Route analysis with light aura"
        />
        <FeatureCard
          to="/setup"
          icon="🔑"
          title="API Setup"
          description="Configure AI keys securely"
        />
        <FeatureCard
          to="/settings"
          icon="⚙️"
          title="Settings"
          description="Configure your workspace"
        />
      </div>

      {/* Quick Start */}
      <div className="text-[12px] space-y-1" style={{ color: '#5a5a5a' }}>
        <div className="flex items-center gap-4 justify-center">
          <span className="flex items-center gap-1">
            <kbd className="px-1.5 py-0.5 rounded text-[10px]" style={{ backgroundColor: '#3c3c3c', color: '#cccccc' }}>Ctrl</kbd>
            <span>+</span>
            <kbd className="px-1.5 py-0.5 rounded text-[10px]" style={{ backgroundColor: '#3c3c3c', color: '#cccccc' }}>P</kbd>
            <span className="ml-1">Go to File</span>
          </span>
          <span className="flex items-center gap-1">
            <kbd className="px-1.5 py-0.5 rounded text-[10px]" style={{ backgroundColor: '#3c3c3c', color: '#cccccc' }}>Ctrl</kbd>
            <span>+</span>
            <kbd className="px-1.5 py-0.5 rounded text-[10px]" style={{ backgroundColor: '#3c3c3c', color: '#cccccc' }}>Shift</kbd>
            <span>+</span>
            <kbd className="px-1.5 py-0.5 rounded text-[10px]" style={{ backgroundColor: '#3c3c3c', color: '#cccccc' }}>I</kbd>
            <span className="ml-1">AI Team</span>
          </span>
        </div>
      </div>

      {/* Version */}
      <div className="absolute bottom-4 text-[10px]" style={{ color: '#3c3c3c' }}>
        Version 1.0.0 — Built with React + Lightweight Router
      </div>
    </div>
  );
}

function FeatureCard({ to, icon, title, description }: { to: string; icon: string; title: string; description: string }) {
  return (
    <Link
      to={to}
      className="flex items-start gap-3 p-3 rounded-lg transition-all cursor-pointer group"
      style={{ backgroundColor: '#252526', border: '1px solid #3c3c3c' }}
      activeStyle={{ borderColor: '#007acc' }}
    >
      <span className="text-[24px] group-hover:scale-110 transition-transform">{icon}</span>
      <div>
        <div className="text-[13px] font-medium mb-0.5" style={{ color: '#cccccc' }}>{title}</div>
        <div className="text-[11px]" style={{ color: '#6e6e6e' }}>{description}</div>
      </div>
    </Link>
  );
}

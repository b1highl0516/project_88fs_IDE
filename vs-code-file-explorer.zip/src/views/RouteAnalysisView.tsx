// ═══════════════════════════════════════════════════════════════════════════
// 路由效能分析可視化 — Route Performance Analysis Visualization
// Light aura that extends directionally based on metric strength
// ═══════════════════════════════════════════════════════════════════════════

import { useState, useEffect, useCallback, useRef } from 'react';
import { RouteComponentProps, useRouter, Link } from '../router';
import { analyzeRoutes, AnalysisResult, PerformanceAxis } from '../services/routeAnalyzer';

export default function RouteAnalysisView({}: RouteComponentProps) {
  const router = useRouter();
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [phase, setPhase] = useState<'idle' | 'scanning' | 'done'>('idle');
  const [scanProgress, setScanProgress] = useState(0);
  const [hoveredAxis, setHoveredAxis] = useState<string | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animRef = useRef<number>(0);
  const timeRef = useRef(0);

  const runAnalysis = useCallback(() => {
    setPhase('scanning');
    setScanProgress(0);
    setResult(null);

    // Animate scan progress then run actual analysis
    let p = 0;
    const interval = setInterval(() => {
      p += Math.random() * 8 + 2;
      if (p >= 100) {
        p = 100;
        clearInterval(interval);
        const r = analyzeRoutes(router.routes);
        setResult(r);
        setTimeout(() => setPhase('done'), 300);
      }
      setScanProgress(Math.min(p, 100));
    }, 60);
  }, [router.routes]);

  // ─── Canvas Aura Rendering ─────────────────────────────────────────────
  useEffect(() => {
    if (phase !== 'done' || !result || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d')!;
    const dpr = window.devicePixelRatio || 1;

    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      canvas.width = rect.width * dpr;
      canvas.height = rect.height * dpr;
      ctx.scale(dpr, dpr);
    };
    resize();

    const W = () => canvas.width / (window.devicePixelRatio || 1);
    const H = () => canvas.height / (window.devicePixelRatio || 1);

    let t = 0;
    const animate = () => {
      t += 0.008;
      timeRef.current = t;
      const w = W(), h = H();
      ctx.clearRect(0, 0, w, h);

      const cx = w / 2;
      const cy = h / 2;
      const baseRadius = Math.min(w, h) * 0.15;

      // ─── Draw directional light aura ───
      // Each axis score controls how far the light extends in that direction
      // Higher score = brighter, farther glow in that direction
      // Lower score = dimmer, shorter glow

      for (const axis of result.axes) {
        const angleDeg = axis.angle;
        const angleRad = (angleDeg - 90) * Math.PI / 180; // -90 so 0° is top
        const strength = axis.score / 100;
        const isHovered = hoveredAxis === axis.id;

        // Lobe reach: strong metric = light extends far; weak = short
        const lobeReach = baseRadius * (0.4 + strength * 2.2) * (isHovered ? 1.15 : 1);
        const lobeBrightness = 0.15 + strength * 0.55;

        // Lobe direction vector
        const dx = Math.cos(angleRad);
        const dy = Math.sin(angleRad);

        // Draw multiple layered gradients for organic glow
        const layers = 5;
        for (let layer = 0; layer < layers; layer++) {
          const layerScale = 1 - layer * 0.15;
          const layerAlpha = lobeBrightness * (1 - layer * 0.18) * (0.85 + Math.sin(t * 2 + axis.angle * 0.1) * 0.15);
          const reach = lobeReach * layerScale;

          // Offset center toward the axis direction
          const offsetX = cx + dx * reach * 0.35;
          const offsetY = cy + dy * reach * 0.35;

          const grad = ctx.createRadialGradient(
            offsetX, offsetY, 0,
            offsetX, offsetY, reach
          );

          // Color based on score: blue→cyan→green→yellow→red
          const hue = getHueForScore(axis.score);
          const sat = isHovered ? 90 : 75;
          const light = isHovered ? 65 : 55;

          grad.addColorStop(0, `hsla(${hue}, ${sat}%, ${light}%, ${layerAlpha * 0.8})`);
          grad.addColorStop(0.3, `hsla(${hue}, ${sat}%, ${light - 10}%, ${layerAlpha * 0.5})`);
          grad.addColorStop(0.6, `hsla(${hue}, ${sat - 15}%, ${light - 20}%, ${layerAlpha * 0.2})`);
          grad.addColorStop(1, `hsla(${hue}, ${sat - 20}%, ${light - 30}%, 0)`);

          ctx.fillStyle = grad;
          ctx.beginPath();
          ctx.ellipse(
            offsetX, offsetY,
            reach * (0.6 + Math.abs(dx) * 0.5),
            reach * (0.6 + Math.abs(dy) * 0.5),
            angleRad, 0, Math.PI * 2
          );
          ctx.fill();
        }
      }

      // ─── Central bright core ───
      const coreRadius = baseRadius * 0.5;
      const coreGrad = ctx.createRadialGradient(cx, cy, 0, cx, cy, coreRadius);
      const overallHue = getHueForScore(result.overall);
      const pulse = 0.9 + Math.sin(t * 3) * 0.1;

      coreGrad.addColorStop(0, `hsla(${overallHue}, 80%, 95%, ${0.95 * pulse})`);
      coreGrad.addColorStop(0.2, `hsla(${overallHue}, 75%, 80%, ${0.7 * pulse})`);
      coreGrad.addColorStop(0.5, `hsla(${overallHue}, 65%, 55%, ${0.35 * pulse})`);
      coreGrad.addColorStop(1, `hsla(${overallHue}, 50%, 30%, 0)`);
      ctx.fillStyle = coreGrad;
      ctx.beginPath();
      ctx.arc(cx, cy, coreRadius, 0, Math.PI * 2);
      ctx.fill();

      // ─── Floating particles ───
      const particleCount = 30;
      for (let i = 0; i < particleCount; i++) {
        const angle = (i / particleCount) * Math.PI * 2 + t * 0.3;
        // Find which axis is closest and use its strength
        const closestAxis = result.axes.reduce((best, a) => {
          const aRad = (a.angle - 90) * Math.PI / 180;
          const diff = Math.abs(normalizeAngle(angle - aRad));
          return diff < best.diff ? { diff, axis: a } : best;
        }, { diff: Infinity, axis: result.axes[0] });

        const strength = closestAxis.axis.score / 100;
        const dist = baseRadius * (0.8 + strength * 1.5) * (0.7 + Math.sin(t * 1.5 + i * 2.3) * 0.3);
        const px = cx + Math.cos(angle) * dist;
        const py = cy + Math.sin(angle) * dist;
        const size = 1 + strength * 2;
        const alpha = 0.2 + strength * 0.5 + Math.sin(t * 3 + i * 1.7) * 0.15;
        const hue = getHueForScore(closestAxis.axis.score);

        ctx.fillStyle = `hsla(${hue}, 80%, 70%, ${alpha})`;
        ctx.beginPath();
        ctx.arc(px, py, size, 0, Math.PI * 2);
        ctx.fill();
      }

      // ─── Axis label lines ───
      for (const axis of result.axes) {
        const angleRad = (axis.angle - 90) * Math.PI / 180;
        const strength = axis.score / 100;
        const lineLen = baseRadius * (0.5 + strength * 2);
        const isHovered = hoveredAxis === axis.id;

        // Thin guiding line
        ctx.strokeStyle = `hsla(0, 0%, 50%, ${isHovered ? 0.4 : 0.1})`;
        ctx.lineWidth = isHovered ? 1.5 : 0.5;
        ctx.setLineDash([3, 4]);
        ctx.beginPath();
        ctx.moveTo(cx, cy);
        ctx.lineTo(cx + Math.cos(angleRad) * lineLen, cy + Math.sin(angleRad) * lineLen);
        ctx.stroke();
        ctx.setLineDash([]);

        // Score dot at end
        const dotX = cx + Math.cos(angleRad) * lineLen;
        const dotY = cy + Math.sin(angleRad) * lineLen;
        const dotSize = isHovered ? 5 : 3;
        const hue = getHueForScore(axis.score);

        ctx.fillStyle = `hsla(${hue}, 80%, 65%, ${isHovered ? 1 : 0.7})`;
        ctx.beginPath();
        ctx.arc(dotX, dotY, dotSize, 0, Math.PI * 2);
        ctx.fill();

        // Glow around dot
        const dotGlow = ctx.createRadialGradient(dotX, dotY, 0, dotX, dotY, dotSize * 4);
        dotGlow.addColorStop(0, `hsla(${hue}, 80%, 65%, 0.3)`);
        dotGlow.addColorStop(1, `hsla(${hue}, 80%, 65%, 0)`);
        ctx.fillStyle = dotGlow;
        ctx.beginPath();
        ctx.arc(dotX, dotY, dotSize * 4, 0, Math.PI * 2);
        ctx.fill();
      }

      // ─── Center text ───
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 28px system-ui, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(result.grade, cx, cy - 8);

      ctx.fillStyle = '#999999';
      ctx.font = '11px system-ui, sans-serif';
      ctx.fillText(`${result.overall}/100`, cx, cy + 14);

      animRef.current = requestAnimationFrame(animate);
    };

    animate();

    window.addEventListener('resize', resize);
    return () => {
      cancelAnimationFrame(animRef.current);
      window.removeEventListener('resize', resize);
    };
  }, [phase, result, hoveredAxis]);

  return (
    <div className="h-full flex flex-col overflow-hidden" style={{ backgroundColor: '#0d0d0d' }}>
      {/* Header */}
      <div className="flex items-center justify-between px-5 py-3 flex-shrink-0" style={{ borderBottom: '1px solid #1a1a1a' }}>
        <div className="flex items-center gap-3">
          <Link to="/routing" className="text-[11px]" style={{ color: '#555' }}>← Routing</Link>
          <span style={{ color: '#333' }}>|</span>
          <span className="text-[13px] font-medium" style={{ color: '#cccccc' }}>路由效能分析 Route Performance Analysis</span>
        </div>
        <div className="flex items-center gap-2">
          {result && (
            <span className="text-[11px] px-2 py-0.5 rounded" style={{ backgroundColor: '#1a1a1a', color: '#666' }}>
              {result.routeCount} routes · {result.avgMatchTimeUs.toFixed(1)}μs avg
            </span>
          )}
          <button
            onClick={runAnalysis}
            disabled={phase === 'scanning'}
            className="px-4 py-1.5 rounded text-[12px] font-medium cursor-pointer transition-all"
            style={{
              backgroundColor: phase === 'scanning' ? '#1a1a1a' : '#007acc',
              color: phase === 'scanning' ? '#555' : '#ffffff',
            }}
          >
            {phase === 'idle' ? '⚡ Run Analysis' : phase === 'scanning' ? `Scanning ${scanProgress.toFixed(0)}%...` : '↻ Re-Analyze'}
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Canvas Area */}
        <div className="flex-1 relative flex items-center justify-center" style={{ backgroundColor: '#0a0a0a' }}>
          {phase === 'idle' && <IdleState onStart={runAnalysis} />}

          {phase === 'scanning' && <ScanningState progress={scanProgress} />}

          {phase === 'done' && result && (
            <canvas
              ref={canvasRef}
              className="absolute inset-0 w-full h-full"
              style={{ cursor: 'crosshair' }}
            />
          )}

          {/* Axis labels overlaid on canvas */}
          {phase === 'done' && result && (
            <AxisLabels
              axes={result.axes}
              hoveredAxis={hoveredAxis}
              onHover={setHoveredAxis}
            />
          )}
        </div>

        {/* Right Panel - Details */}
        {phase === 'done' && result && (
          <div
            className="w-[300px] flex-shrink-0 overflow-y-auto"
            style={{ backgroundColor: '#111', borderLeft: '1px solid #1a1a1a', scrollbarWidth: 'thin', scrollbarColor: '#333 transparent' }}
          >
            <DetailPanel result={result} hoveredAxis={hoveredAxis} onHover={setHoveredAxis} />
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Idle State ──────────────────────────────────────────────────────────────
function IdleState({ onStart }: { onStart: () => void }) {
  return (
    <div className="flex flex-col items-center text-center z-10 px-8">
      <div className="w-20 h-20 rounded-full flex items-center justify-center mb-6" style={{ background: 'radial-gradient(circle, rgba(0,122,204,0.15) 0%, transparent 70%)', border: '1px solid #1a1a1a' }}>
        <span className="text-[36px]">⚡</span>
      </div>
      <h2 className="text-[18px] font-semibold mb-2" style={{ color: '#cccccc' }}>路由效能分析器</h2>
      <p className="text-[12px] mb-1" style={{ color: '#666' }}>Route Performance Analyzer</p>
      <p className="text-[11px] mb-6 max-w-[400px] leading-[1.6]" style={{ color: '#444' }}>
        分析路由規則的匹配速度、吞吐量、可擴展性、記憶體效率等8個維度。
        光環可視化將根據每個維度的強弱指數，向對應方向延伸或收暗。
      </p>
      <button
        onClick={onStart}
        className="px-6 py-2.5 rounded-lg text-[13px] font-medium cursor-pointer transition-all"
        style={{ backgroundColor: '#007acc', color: '#ffffff', boxShadow: '0 0 30px rgba(0,122,204,0.3)' }}
      >
        ⚡ Start Analysis
      </button>
    </div>
  );
}

// ─── Scanning State ──────────────────────────────────────────────────────────
function ScanningState({ progress }: { progress: number }) {
  return (
    <div className="flex flex-col items-center z-10">
      {/* Pulsing ring */}
      <div className="relative w-32 h-32 mb-6">
        <div className="absolute inset-0 rounded-full animate-ping" style={{ backgroundColor: 'rgba(0,122,204,0.1)' }} />
        <div className="absolute inset-4 rounded-full animate-pulse" style={{ backgroundColor: 'rgba(0,122,204,0.15)' }} />
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="text-[20px] font-bold" style={{ color: '#007acc' }}>{progress.toFixed(0)}%</span>
        </div>
        {/* Rotating ring */}
        <svg className="absolute inset-0 w-full h-full -rotate-90" viewBox="0 0 100 100">
          <circle cx="50" cy="50" r="45" fill="none" stroke="#1a1a1a" strokeWidth="2" />
          <circle cx="50" cy="50" r="45" fill="none" stroke="#007acc" strokeWidth="2.5"
            strokeDasharray={`${progress * 2.83} 283`}
            strokeLinecap="round"
            style={{ transition: 'stroke-dasharray 0.1s ease' }}
          />
        </svg>
      </div>
      <p className="text-[12px]" style={{ color: '#555' }}>Benchmarking route matching performance...</p>
    </div>
  );
}

// ─── Axis Labels Overlay ─────────────────────────────────────────────────────
function AxisLabels({
  axes,
  hoveredAxis,
  onHover,
}: {
  axes: PerformanceAxis[];
  hoveredAxis: string | null;
  onHover: (id: string | null) => void;
}) {
  return (
    <div className="absolute inset-0 pointer-events-none">
      {axes.map(axis => {
        const angleRad = (axis.angle - 90) * Math.PI / 180;
        const distance = 42 + (axis.score / 100) * 6; // % from center
        const x = 50 + Math.cos(angleRad) * distance;
        const y = 50 + Math.sin(angleRad) * distance;
        const isHovered = hoveredAxis === axis.id;

        return (
          <div
            key={axis.id}
            className="absolute pointer-events-auto cursor-pointer transition-all duration-200"
            style={{
              left: `${x}%`,
              top: `${y}%`,
              transform: 'translate(-50%, -50%)',
              opacity: isHovered ? 1 : 0.7,
            }}
            onMouseEnter={() => onHover(axis.id)}
            onMouseLeave={() => onHover(null)}
          >
            <div className="flex flex-col items-center gap-0.5">
              <span
                className="text-[10px] font-bold px-1.5 py-0.5 rounded whitespace-nowrap"
                style={{
                  backgroundColor: isHovered ? `hsla(${getHueForScore(axis.score)}, 70%, 20%, 0.9)` : 'rgba(0,0,0,0.6)',
                  color: `hsl(${getHueForScore(axis.score)}, 70%, ${isHovered ? 75 : 60}%)`,
                  border: isHovered ? `1px solid hsla(${getHueForScore(axis.score)}, 70%, 40%, 0.5)` : '1px solid transparent',
                }}
              >
                {axis.labelZh}
              </span>
              <span className="text-[9px] font-mono" style={{ color: '#555' }}>
                {axis.score}
              </span>
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ─── Detail Panel ────────────────────────────────────────────────────────────
function DetailPanel({
  result,
  hoveredAxis,
  onHover,
}: {
  result: AnalysisResult;
  hoveredAxis: string | null;
  onHover: (id: string | null) => void;
}) {
  return (
    <div className="p-4 space-y-4">
      {/* Overall Score */}
      <div className="text-center pb-4" style={{ borderBottom: '1px solid #1a1a1a' }}>
        <div className="text-[11px] uppercase tracking-wider mb-2" style={{ color: '#555' }}>Overall Score</div>
        <div className="flex items-center justify-center gap-3">
          <span
            className="text-[36px] font-black"
            style={{ color: `hsl(${getHueForScore(result.overall)}, 70%, 60%)` }}
          >
            {result.grade}
          </span>
          <div className="text-left">
            <div className="text-[24px] font-bold" style={{ color: '#cccccc' }}>{result.overall}</div>
            <div className="text-[10px]" style={{ color: '#555' }}>/ 100</div>
          </div>
        </div>
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-2 gap-2">
        <StatBox label="Routes" value={result.routeCount.toString()} sub={`${result.staticRoutes} static, ${result.dynamicRoutes} dynamic`} />
        <StatBox label="Avg Match" value={`${result.avgMatchTimeUs.toFixed(1)}μs`} sub={`Worst: ${result.worstMatchTimeUs.toFixed(0)}μs`} />
        <StatBox label="Throughput" value={formatNum(result.throughputOpsPerSec)} sub="ops/sec" />
        <StatBox label="Memory" value={`${result.memoryEstimateKB.toFixed(1)}KB`} sub={`Depth: ${result.maxDepth}`} />
      </div>

      {/* Per-Axis Detail */}
      <div>
        <div className="text-[10px] uppercase tracking-wider mb-2" style={{ color: '#555' }}>Dimension Details</div>
        {result.axes.map(axis => {
          const hue = getHueForScore(axis.score);
          const isHovered = hoveredAxis === axis.id;

          return (
            <div
              key={axis.id}
              className="flex items-center gap-2 py-2 px-2 rounded transition-all cursor-pointer"
              style={{
                backgroundColor: isHovered ? `hsla(${hue}, 60%, 15%, 0.4)` : 'transparent',
                borderLeft: isHovered ? `2px solid hsl(${hue}, 70%, 50%)` : '2px solid transparent',
              }}
              onMouseEnter={() => onHover(axis.id)}
              onMouseLeave={() => onHover(null)}
            >
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-medium" style={{ color: '#cccccc' }}>{axis.label}</span>
                  <span className="text-[9px]" style={{ color: '#555' }}>{axis.labelZh}</span>
                </div>
                <div className="text-[10px]" style={{ color: '#555' }}>{axis.description}</div>
              </div>
              <div className="flex flex-col items-end gap-0.5">
                <span
                  className="text-[13px] font-bold font-mono"
                  style={{ color: `hsl(${hue}, 70%, 60%)` }}
                >
                  {axis.score}
                </span>
                {/* Mini bar */}
                <div className="w-[50px] h-[3px] rounded-full overflow-hidden" style={{ backgroundColor: '#1a1a1a' }}>
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{
                      width: `${axis.score}%`,
                      backgroundColor: `hsl(${hue}, 70%, 55%)`,
                      boxShadow: isHovered ? `0 0 6px hsl(${hue}, 70%, 55%)` : 'none',
                    }}
                  />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Explanation */}
      <div className="p-3 rounded-lg text-[10px] leading-[1.6]" style={{ backgroundColor: '#0d0d0d', border: '1px solid #1a1a1a', color: '#555' }}>
        <p className="mb-1" style={{ color: '#888' }}>光環可視化說明：</p>
        <p>每個維度驅動光環向對應方向延伸。分數越高，光在該方向越亮、越遠；分數越低，光越暗、越短。
        中心光球代表總體評分，粒子根據最近軸心強度分布。</p>
      </div>
    </div>
  );
}

function StatBox({ label, value, sub }: { label: string; value: string; sub: string }) {
  return (
    <div className="p-2.5 rounded" style={{ backgroundColor: '#0d0d0d', border: '1px solid #1a1a1a' }}>
      <div className="text-[9px] uppercase tracking-wider mb-1" style={{ color: '#555' }}>{label}</div>
      <div className="text-[14px] font-bold font-mono" style={{ color: '#cccccc' }}>{value}</div>
      <div className="text-[9px]" style={{ color: '#444' }}>{sub}</div>
    </div>
  );
}

// ─── Utility ─────────────────────────────────────────────────────────────────
function getHueForScore(score: number): number {
  // 0 = red(0), 50 = yellow(50), 75 = cyan(180), 100 = blue/green(150)
  if (score >= 80) return 150 + (score - 80) * 1;  // green-cyan
  if (score >= 60) return 50 + (score - 60) * 5;   // yellow → green
  if (score >= 40) return 30 + (score - 40) * 1;   // orange → yellow
  return score * 0.75;                               // red → orange
}

function normalizeAngle(a: number): number {
  while (a > Math.PI) a -= 2 * Math.PI;
  while (a < -Math.PI) a += 2 * Math.PI;
  return a;
}

function formatNum(n: number): string {
  if (n >= 1000000) return (n / 1000000).toFixed(1) + 'M';
  if (n >= 1000) return (n / 1000).toFixed(0) + 'K';
  return n.toString();
}

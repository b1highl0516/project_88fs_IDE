// ═══════════════════════════════════════════════════════════════════════════
// 設置視圖 - Settings View
// ═══════════════════════════════════════════════════════════════════════════

import { RouteComponentProps, Link } from '../router';

const SETTINGS_SECTIONS = [
  { id: 'general', icon: '⚙️', title: 'General', description: 'Application preferences' },
  { id: 'ai', icon: '🤖', title: 'AI Agents', description: 'Configure AI providers and models' },
  { id: 'editor', icon: '📝', title: 'Editor', description: 'Editor appearance and behavior' },
  { id: 'keyboard', icon: '⌨️', title: 'Keyboard', description: 'Keyboard shortcuts' },
  { id: 'theme', icon: '🎨', title: 'Theme', description: 'Colors and appearance' },
  { id: 'extensions', icon: '🧩', title: 'Extensions', description: 'Manage extensions' },
];

export default function SettingsView({ params }: RouteComponentProps) {
  const section = params.section || 'general';
  const currentSection = SETTINGS_SECTIONS.find(s => s.id === section) || SETTINGS_SECTIONS[0];

  return (
    <div className="h-full flex" style={{ backgroundColor: '#1e1e1e' }}>
      {/* Sidebar */}
      <div className="w-[220px] flex-shrink-0 flex flex-col" style={{ backgroundColor: '#252526', borderRight: '1px solid #1e1e1e' }}>
        <div className="flex items-center justify-between px-4 h-[35px] flex-shrink-0" style={{ borderBottom: '1px solid #1e1e1e' }}>
          <span className="text-[11px] font-semibold uppercase tracking-wider" style={{ color: '#bbbbbb' }}>Settings</span>
          <Link to="/" className="text-[11px]" style={{ color: '#007acc' }}>✕</Link>
        </div>

        <div className="flex-1 overflow-y-auto py-2">
          {SETTINGS_SECTIONS.map(s => (
            <Link
              key={s.id}
              to={`/settings/${s.id}`}
              className="flex items-center gap-3 px-4 py-2 cursor-pointer transition-colors"
              style={{ color: section === s.id ? '#ffffff' : '#cccccc', backgroundColor: section === s.id ? '#04395e' : 'transparent' }}
            >
              <span className="text-[16px]">{s.icon}</span>
              <span className="text-[12px]">{s.title}</span>
            </Link>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center gap-3 px-6 h-[50px] flex-shrink-0" style={{ borderBottom: '1px solid #2d2d2d' }}>
          <span className="text-[24px]">{currentSection.icon}</span>
          <div>
            <div className="text-[14px] font-medium" style={{ color: '#cccccc' }}>{currentSection.title}</div>
            <div className="text-[11px]" style={{ color: '#6e6e6e' }}>{currentSection.description}</div>
          </div>
        </div>

        {/* Settings Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {section === 'general' && <GeneralSettings />}
          {section === 'ai' && <AISettings />}
          {section === 'editor' && <EditorSettings />}
          {section === 'keyboard' && <KeyboardSettings />}
          {section === 'theme' && <ThemeSettings />}
          {section === 'extensions' && <ExtensionsSettings />}
        </div>
      </div>
    </div>
  );
}

function SettingRow({ label, description, children }: { label: string; description?: string; children: React.ReactNode }) {
  return (
    <div className="flex items-start justify-between py-3" style={{ borderBottom: '1px solid #2d2d2d' }}>
      <div className="flex-1 pr-4">
        <div className="text-[13px]" style={{ color: '#cccccc' }}>{label}</div>
        {description && <div className="text-[11px] mt-0.5" style={{ color: '#6e6e6e' }}>{description}</div>}
      </div>
      <div className="flex-shrink-0">{children}</div>
    </div>
  );
}

function Toggle({ checked, onChange }: { checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      onClick={() => onChange(!checked)}
      className="w-[40px] h-[20px] rounded-full relative cursor-pointer transition-colors"
      style={{ backgroundColor: checked ? '#007acc' : '#3c3c3c' }}
    >
      <div className="w-[16px] h-[16px] rounded-full absolute top-[2px] transition-all" style={{ backgroundColor: '#fff', left: checked ? '22px' : '2px' }} />
    </button>
  );
}

function GeneralSettings() {
  return (
    <div className="max-w-[600px]">
      <SettingRow label="Auto Save" description="Save files automatically after a delay">
        <Toggle checked={true} onChange={() => {}} />
      </SettingRow>
      <SettingRow label="Confirm on Exit" description="Show confirmation dialog when closing">
        <Toggle checked={false} onChange={() => {}} />
      </SettingRow>
      <SettingRow label="Restore Tabs" description="Restore open tabs on startup">
        <Toggle checked={true} onChange={() => {}} />
      </SettingRow>
    </div>
  );
}

function AISettings() {
  return (
    <div className="max-w-[600px]">
      <div className="p-4 rounded-lg mb-4" style={{ backgroundColor: '#252526', border: '1px solid #3c3c3c' }}>
        <div className="text-[12px] mb-2" style={{ color: '#cccccc' }}>
          Configure AI agents in the AI Workspace panel.
        </div>
        <Link to="/ai" className="text-[12px]" style={{ color: '#007acc' }}>
          Open AI Workspace →
        </Link>
      </div>
      <SettingRow label="Enable AI Suggestions" description="Show AI suggestions while typing">
        <Toggle checked={true} onChange={() => {}} />
      </SettingRow>
      <SettingRow label="Streaming Responses" description="Stream AI responses in real-time">
        <Toggle checked={true} onChange={() => {}} />
      </SettingRow>
    </div>
  );
}

function EditorSettings() {
  return (
    <div className="max-w-[600px]">
      <SettingRow label="Font Size" description="Editor font size in pixels">
        <input type="number" defaultValue={14} className="w-[80px] px-2 py-1 rounded text-[12px] outline-none" style={{ backgroundColor: '#3c3c3c', color: '#cccccc', border: '1px solid #4a4a4a' }} />
      </SettingRow>
      <SettingRow label="Tab Size" description="Number of spaces per tab">
        <select defaultValue={2} className="px-2 py-1 rounded text-[12px] outline-none cursor-pointer" style={{ backgroundColor: '#3c3c3c', color: '#cccccc', border: '1px solid #4a4a4a' }}>
          <option value={2}>2</option>
          <option value={4}>4</option>
          <option value={8}>8</option>
        </select>
      </SettingRow>
      <SettingRow label="Word Wrap" description="Wrap long lines">
        <Toggle checked={true} onChange={() => {}} />
      </SettingRow>
      <SettingRow label="Minimap" description="Show code minimap">
        <Toggle checked={true} onChange={() => {}} />
      </SettingRow>
    </div>
  );
}

function KeyboardSettings() {
  const shortcuts = [
    { key: 'Ctrl+P', action: 'Go to File' },
    { key: 'Ctrl+Shift+P', action: 'Command Palette' },
    { key: 'Ctrl+Shift+I', action: 'AI Team' },
    { key: 'Ctrl+,', action: 'Settings' },
    { key: 'Ctrl+`', action: 'Terminal' },
  ];

  return (
    <div className="max-w-[600px]">
      {shortcuts.map(s => (
        <SettingRow key={s.key} label={s.action}>
          <kbd className="px-2 py-1 rounded text-[11px] font-mono" style={{ backgroundColor: '#3c3c3c', color: '#cccccc' }}>{s.key}</kbd>
        </SettingRow>
      ))}
    </div>
  );
}

function ThemeSettings() {
  const themes = [
    { id: 'dark', name: 'Dark+ (Default)', color: '#1e1e1e' },
    { id: 'light', name: 'Light+', color: '#ffffff' },
    { id: 'monokai', name: 'Monokai', color: '#272822' },
    { id: 'solarized', name: 'Solarized Dark', color: '#002b36' },
  ];

  return (
    <div className="max-w-[600px]">
      <div className="grid grid-cols-2 gap-2">
        {themes.map(t => (
          <button
            key={t.id}
            className="flex items-center gap-3 p-3 rounded-lg cursor-pointer transition-all"
            style={{ backgroundColor: '#252526', border: t.id === 'dark' ? '2px solid #007acc' : '1px solid #3c3c3c' }}
          >
            <div className="w-8 h-8 rounded" style={{ backgroundColor: t.color, border: '1px solid #4a4a4a' }} />
            <span className="text-[12px]" style={{ color: '#cccccc' }}>{t.name}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

function ExtensionsSettings() {
  return (
    <div className="max-w-[600px]">
      <div className="text-[12px] mb-4" style={{ color: '#6e6e6e' }}>
        Manage your installed extensions.
      </div>
      <div className="space-y-2">
        {[
          { name: 'AI Team Collaboration', enabled: true },
          { name: 'ESLint', enabled: true },
          { name: 'Prettier', enabled: true },
          { name: 'GitLens', enabled: false },
        ].map(ext => (
          <div key={ext.name} className="flex items-center justify-between p-3 rounded" style={{ backgroundColor: '#252526' }}>
            <span className="text-[12px]" style={{ color: '#cccccc' }}>{ext.name}</span>
            <Toggle checked={ext.enabled} onChange={() => {}} />
          </div>
        ))}
      </div>
    </div>
  );
}

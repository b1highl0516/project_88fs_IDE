// ═══════════════════════════════════════════════════════════════════════════
// 路由演示視圖 - Routing Demo View
// ═══════════════════════════════════════════════════════════════════════════

import { useState } from 'react';
import { RouteComponentProps, Link, useNavigate, useLocation, useRouter } from '../router';

export default function RoutingDemoView({ params, query, path }: RouteComponentProps) {
  const navigate = useNavigate();
  const location = useLocation();
  const router = useRouter();
  const [customPath, setCustomPath] = useState('/editor/app');

  return (
    <div className="h-full flex flex-col overflow-auto" style={{ backgroundColor: '#1e1e1e' }}>
      {/* Header */}
      <div className="flex items-center gap-3 px-6 py-4 flex-shrink-0" style={{ borderBottom: '1px solid #2d2d2d' }}>
        <span className="text-[24px]">🔀</span>
        <div>
          <div className="text-[16px] font-medium" style={{ color: '#cccccc' }}>Routing System Demo</div>
          <div className="text-[11px]" style={{ color: '#6e6e6e' }}>Lightweight type-safe router inspired by Wouter + TanStack Router</div>
        </div>
      </div>

      <div className="flex-1 overflow-auto p-6">
        <div className="max-w-[800px] mx-auto space-y-6">

          {/* Current Location */}
          <Section title="📍 Current Location" icon="location">
            <div className="grid grid-cols-2 gap-3">
              <InfoBox label="Path" value={location.path} />
              <InfoBox label="Full Path" value={path} />
              <InfoBox label="Query String" value={location.query.toString() || '(none)'} />
              <InfoBox label="Params" value={JSON.stringify(params) || '{}'} />
            </div>
          </Section>

          {/* Navigation */}
          <Section title="🧭 Navigation" icon="nav">
            <div className="flex flex-wrap gap-2 mb-4">
              <NavButton to="/" label="Home" />
              <NavButton to="/editor" label="Editor" />
              <NavButton to="/editor/router" label="Editor → Router.tsx" />
              <NavButton to="/ai" label="AI Workspace" />
              <NavButton to="/settings" label="Settings" />
              <NavButton to="/settings/ai" label="Settings → AI" />
              <NavButton to="/unknown-page" label="404 Test" />
            </div>

            <div className="flex items-center gap-2 mt-4">
              <input
                type="text"
                value={customPath}
                onChange={e => setCustomPath(e.target.value)}
                placeholder="Enter path..."
                className="flex-1 px-3 py-1.5 rounded text-[12px] outline-none"
                style={{ backgroundColor: '#3c3c3c', color: '#cccccc', border: '1px solid #4a4a4a' }}
              />
              <button
                onClick={() => navigate(customPath)}
                className="px-4 py-1.5 rounded text-[12px] cursor-pointer"
                style={{ backgroundColor: '#007acc', color: '#ffffff' }}
              >
                Navigate
              </button>
              <button
                onClick={() => navigate(customPath, { replace: true })}
                className="px-4 py-1.5 rounded text-[12px] cursor-pointer"
                style={{ backgroundColor: '#4a4a4a', color: '#cccccc' }}
              >
                Replace
              </button>
            </div>
          </Section>

          {/* Route Matching */}
          <Section title="🎯 Route Matching" icon="match">
            <div className="space-y-2">
              <MatchTest pattern="/" currentPath={location.path} />
              <MatchTest pattern="/editor" currentPath={location.path} />
              <MatchTest pattern="/editor/:fileId" currentPath={location.path} />
              <MatchTest pattern="/settings/:section" currentPath={location.path} />
              <MatchTest pattern="/ai/:sessionId" currentPath={location.path} />
            </div>
          </Section>

          {/* Available Routes */}
          <Section title="📜 Registered Routes" icon="routes">
            <div className="space-y-1">
              {router.routes.map((route, i) => (
                <div key={i} className="flex items-center gap-3 px-3 py-2 rounded" style={{ backgroundColor: '#252526' }}>
                  <code className="text-[11px] px-2 py-0.5 rounded" style={{ backgroundColor: '#1e1e1e', color: '#ce9178' }}>
                    {route.path}
                  </code>
                  <span className="text-[11px]" style={{ color: '#6e6e6e' }}>{route.title || 'Untitled'}</span>
                  <span className="flex-1" />
                  <Link to={route.path.replace(/:(\w+)/g, 'demo')} className="text-[10px]" style={{ color: '#007acc' }}>Go →</Link>
                </div>
              ))}
            </div>
          </Section>

          {/* History */}
          <Section title="📚 History Navigation" icon="history">
            <div className="flex gap-2">
              <button onClick={() => router.back()} className="px-4 py-2 rounded text-[12px] cursor-pointer flex items-center gap-2" style={{ backgroundColor: '#3c3c3c', color: '#cccccc' }}>
                ← Back
              </button>
              <button onClick={() => router.forward()} className="px-4 py-2 rounded text-[12px] cursor-pointer flex items-center gap-2" style={{ backgroundColor: '#3c3c3c', color: '#cccccc' }}>
                Forward →
              </button>
            </div>
          </Section>

          {/* Query Params */}
          <Section title="🔍 Query Parameters" icon="query">
            <div className="flex flex-wrap gap-2 mb-3">
              <button
                onClick={() => navigate('/routing?page=1&sort=asc')}
                className="px-3 py-1.5 rounded text-[11px] cursor-pointer"
                style={{ backgroundColor: '#3c3c3c', color: '#cccccc' }}
              >
                ?page=1&sort=asc
              </button>
              <button
                onClick={() => navigate('/routing?search=router&filter=active')}
                className="px-3 py-1.5 rounded text-[11px] cursor-pointer"
                style={{ backgroundColor: '#3c3c3c', color: '#cccccc' }}
              >
                ?search=router&filter=active
              </button>
              <button
                onClick={() => navigate('/routing')}
                className="px-3 py-1.5 rounded text-[11px] cursor-pointer"
                style={{ backgroundColor: '#5a1d1d', color: '#f14c4c' }}
              >
                Clear Query
              </button>
            </div>
            <div className="p-3 rounded text-[11px] font-mono" style={{ backgroundColor: '#252526', color: '#969696' }}>
              {query.toString() ? (
                Array.from(query.entries()).map(([k, v]) => (
                  <div key={k}><span style={{ color: '#9cdcfe' }}>{k}</span> = <span style={{ color: '#ce9178' }}>"{v}"</span></div>
                ))
              ) : (
                <span style={{ color: '#5a5a5a' }}>No query parameters</span>
              )}
            </div>
          </Section>

          {/* Code Example */}
          <Section title="💻 Code Examples" icon="code">
            <pre className="p-4 rounded text-[11px] leading-[1.6] overflow-x-auto" style={{ backgroundColor: '#252526', color: '#d4d4d4', fontFamily: 'monospace' }}>
{`// Define routes
const routes = [
  { path: '/', component: Home },
  { path: '/editor/:fileId', component: FileDetail },
  { path: '/settings/:section', component: Settings },
];

// Use hooks
const navigate = useNavigate();
const { path, params, query } = useLocation();

// Navigate programmatically
navigate('/editor/app');
navigate('/settings', { replace: true });

// Link component
<Link to="/editor/app">Open App.tsx</Link>
<Link to="/ai" activeStyle={{ color: 'blue' }}>AI</Link>`}
            </pre>
          </Section>

        </div>
      </div>
    </div>
  );
}

function Section({ title, children }: { title: string; icon?: string; children: React.ReactNode }) {
  return (
    <div className="rounded-lg overflow-hidden" style={{ border: '1px solid #3c3c3c' }}>
      <div className="px-4 py-2" style={{ backgroundColor: '#252526', borderBottom: '1px solid #3c3c3c' }}>
        <span className="text-[12px] font-medium" style={{ color: '#cccccc' }}>{title}</span>
      </div>
      <div className="p-4" style={{ backgroundColor: '#1e1e1e' }}>{children}</div>
    </div>
  );
}

function InfoBox({ label, value }: { label: string; value: string }) {
  return (
    <div className="p-3 rounded" style={{ backgroundColor: '#252526' }}>
      <div className="text-[10px] uppercase tracking-wider mb-1" style={{ color: '#6e6e6e' }}>{label}</div>
      <code className="text-[12px]" style={{ color: '#ce9178' }}>{value}</code>
    </div>
  );
}

function NavButton({ to, label }: { to: string; label: string }) {
  const { isActive } = useRouter();
  const active = isActive(to, true);

  return (
    <Link
      to={to}
      className="px-3 py-1.5 rounded text-[11px] cursor-pointer transition-colors"
      style={{
        backgroundColor: active ? '#007acc' : '#3c3c3c',
        color: active ? '#ffffff' : '#cccccc',
      }}
    >
      {label}
    </Link>
  );
}

function MatchTest({ pattern, currentPath }: { pattern: string; currentPath: string }) {
  const { match } = useRouter();
  const result = match(pattern);
  const matches = result !== null || pattern === currentPath ||
    (pattern.includes(':') && currentPath.startsWith(pattern.split(':')[0]));

  return (
    <div className="flex items-center gap-3 px-3 py-2 rounded" style={{ backgroundColor: '#252526' }}>
      <code className="text-[11px] flex-1" style={{ color: '#9cdcfe' }}>{pattern}</code>
      <span className={`w-2 h-2 rounded-full`} style={{ backgroundColor: matches ? '#4ec9b0' : '#5a5a5a' }} />
      <span className="text-[10px] w-[60px]" style={{ color: matches ? '#4ec9b0' : '#5a5a5a' }}>
        {matches ? 'Matches' : 'No match'}
      </span>
    </div>
  );
}

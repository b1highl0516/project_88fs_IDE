// ═══════════════════════════════════════════════════════════════════════════
// 文件詳情視圖 - File Detail View
// ═══════════════════════════════════════════════════════════════════════════

import { Link, RouteComponentProps, useNavigate } from '../router';

const FILE_CONTENTS: Record<string, { name: string; content: string; lang: string }> = {
  app: {
    name: 'App.tsx',
    lang: 'tsx',
    content: `import React from 'react';
import { RouterProvider } from './router';
import { routes } from './routes';

export default function App() {
  return (
    <RouterProvider routes={routes}>
      <MainLayout />
    </RouterProvider>
  );
}`,
  },
  router: {
    name: 'Router.tsx',
    lang: 'tsx',
    content: `// Lightweight hash-based router
// Inspired by Wouter + TanStack Router

import { createContext, useContext } from 'react';

export function RouterProvider({ routes, children }) {
  // Handle hash change events
  // Match routes with params
  // Render matched component
}

export function Link({ to, children }) {
  const navigate = useNavigate();
  return <a href={'#' + to}>{children}</a>;
}`,
  },
  types: {
    name: 'types.ts',
    lang: 'ts',
    content: `export interface RouteDefinition {
  path: string;
  component: React.ComponentType;
  title?: string;
  children?: RouteDefinition[];
  guard?: RouteGuard;
  meta?: RouteMeta;
}

export interface RouteMatch {
  route: RouteDefinition;
  params: Record<string, string>;
  score: number;
}`,
  },
  readme: {
    name: 'README.md',
    lang: 'md',
    content: `# VS Code AI Multi-Agent Team

## Features

- 🔀 **Routing Layer** - Lightweight type-safe router
- 🤖 **3 AI Agents** - Architect, Coder, Reviewer
- 📁 **File Explorer** - Tree view with multi-select
- ⚙️ **Settings** - Configure AI providers

## Getting Started

\`\`\`bash
npm install
npm run dev
\`\`\``,
  },
  package: {
    name: 'package.json',
    lang: 'json',
    content: `{
  "name": "vscode-ai-team",
  "version": "1.0.0",
  "scripts": {
    "dev": "vite",
    "build": "vite build"
  },
  "dependencies": {
    "react": "^19.0.0",
    "react-dom": "^19.0.0"
  }
}`,
  },
};

export default function FileDetailView({ params }: RouteComponentProps) {
  const navigate = useNavigate();
  const fileId = params.fileId || 'app';
  const file = FILE_CONTENTS[fileId] || FILE_CONTENTS.app;

  return (
    <div className="h-full flex flex-col" style={{ backgroundColor: '#1e1e1e' }}>
      {/* Breadcrumb */}
      <div className="flex items-center h-[22px] px-3 text-[12px] flex-shrink-0" style={{ backgroundColor: '#1e1e1e', color: '#969696', borderBottom: '1px solid #2d2d2d' }}>
        <Link to="/editor" style={{ color: '#007acc' }}>Editor</Link>
        <span className="mx-1 opacity-50">›</span>
        <span style={{ color: '#cccccc' }}>{file.name}</span>
        <span className="flex-1" />
        <span className="text-[10px] px-1.5 py-0.5 rounded" style={{ backgroundColor: '#3c3c3c', color: '#969696' }}>{file.lang}</span>
      </div>

      {/* Editor */}
      <div className="flex-1 flex overflow-hidden">
        {/* Line numbers */}
        <div className="flex flex-col items-end pr-4 pl-4 pt-3 text-[13px] leading-[20px] select-none flex-shrink-0" style={{ color: '#5a5a5a', fontFamily: 'monospace', backgroundColor: '#1e1e1e' }}>
          {file.content.split('\n').map((_, i) => (
            <div key={i} className="h-[20px]">{i + 1}</div>
          ))}
        </div>

        {/* Code */}
        <pre className="flex-1 pt-3 pr-4 overflow-auto text-[13px] leading-[20px]" style={{ fontFamily: 'monospace', color: '#d4d4d4', margin: 0 }}>
          <code>{file.content}</code>
        </pre>
      </div>

      {/* Status bar */}
      <div className="flex items-center justify-between px-3 h-[22px] text-[11px] flex-shrink-0" style={{ backgroundColor: '#252526', color: '#6e6e6e', borderTop: '1px solid #2d2d2d' }}>
        <div className="flex items-center gap-3">
          <button onClick={() => navigate('/editor')} className="hover:text-white cursor-pointer">← Back</button>
          <span>{file.name}</span>
        </div>
        <div className="flex items-center gap-3">
          <span>Ln 1, Col 1</span>
          <span>{file.lang.toUpperCase()}</span>
          <span>UTF-8</span>
        </div>
      </div>
    </div>
  );
}

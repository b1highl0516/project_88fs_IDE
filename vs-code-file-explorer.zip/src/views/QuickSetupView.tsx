// ═══════════════════════════════════════════════════════════════════════════
// 快速設置視圖 - Quick Setup View
// Secure browser-local API key configuration
// Keys are stored ONLY in your browser's localStorage — never sent to
// any server except the AI provider's own API endpoint.
// ═══════════════════════════════════════════════════════════════════════════

import { useState } from 'react';
import { RouteComponentProps, useNavigate } from '../router';
import { AISlot, AIProvider, DEFAULT_MODELS, DEFAULT_ENDPOINTS, PROVIDER_LABELS, AI_SLOT_DEFAULTS } from '../types';

const PROVIDER_INFO: Record<AIProvider, { url: string; placeholder: string; help: string }> = {
  openai: {
    url: 'https://platform.openai.com/api-keys',
    placeholder: 'sk-proj-...',
    help: 'platform.openai.com → API Keys → Create new',
  },
  anthropic: {
    url: 'https://console.anthropic.com/settings/keys',
    placeholder: 'sk-ant-...',
    help: 'console.anthropic.com → Settings → API Keys',
  },
  google: {
    url: 'https://aistudio.google.com/apikey',
    placeholder: 'AIza...',
    help: 'aistudio.google.com → Get API key',
  },
  deepseek: {
    url: 'https://platform.deepseek.com/api_keys',
    placeholder: 'sk-...',
    help: 'platform.deepseek.com → API Keys',
  },
  custom: {
    url: '',
    placeholder: '(optional)',
    help: 'For local models like Ollama — key is optional',
  },
};

export default function QuickSetupView({}: RouteComponentProps) {
  const navigate = useNavigate();

  const [slots, setSlots] = useState<AISlot[]>(() => {
    try {
      const saved = localStorage.getItem('ai-slots-v2');
      if (saved) return JSON.parse(saved);
    } catch {}
    return AI_SLOT_DEFAULTS.map(s => ({ ...s, config: { ...s.config } }));
  });

  const [activeSlot, setActiveSlot] = useState(0);
  const [showKeys, setShowKeys] = useState<Record<string, boolean>>({});
  const [testResults, setTestResults] = useState<Record<string, 'idle' | 'testing' | 'ok' | 'fail'>>({});
  const [testMessages, setTestMessages] = useState<Record<string, string>>({});
  const [saved, setSaved] = useState(false);

  const updateSlot = (idx: number, partial: Partial<AISlot>) => {
    setSlots(prev => prev.map((s, i) => i === idx ? { ...s, ...partial } : s));
  };

  const updateConfig = (idx: number, partial: Partial<AISlot['config']>) => {
    setSlots(prev => prev.map((s, i) => i === idx ? { ...s, config: { ...s.config, ...partial } } : s));
  };

  const handleProviderChange = (idx: number, provider: AIProvider) => {
    updateConfig(idx, {
      provider,
      apiEndpoint: DEFAULT_ENDPOINTS[provider],
      model: DEFAULT_MODELS[provider][0],
    });
  };

  const handleTest = async (idx: number) => {
    const s = slots[idx];
    const id = s.id;
    setTestResults(p => ({ ...p, [id]: 'testing' }));
    setTestMessages(p => ({ ...p, [id]: '' }));

    try {
      const cfg = s.config;
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };

      if (cfg.provider === 'anthropic') {
        headers['x-api-key'] = cfg.apiKey;
        headers['anthropic-version'] = '2023-06-01';
        headers['anthropic-dangerous-direct-browser-access'] = 'true';
        const res = await fetch(cfg.apiEndpoint, {
          method: 'POST', headers,
          body: JSON.stringify({ model: cfg.model, messages: [{ role: 'user', content: 'Hi' }], max_tokens: 8 }),
        });
        if (!res.ok) throw new Error(`HTTP ${res.status}: ${(await res.text()).slice(0, 100)}`);
      } else if (cfg.provider === 'google') {
        const ep = `https://generativelanguage.googleapis.com/v1beta/models/${cfg.model}:generateContent?key=${cfg.apiKey}`;
        const res = await fetch(ep, {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ contents: [{ role: 'user', parts: [{ text: 'Hi' }] }], generationConfig: { maxOutputTokens: 8 } }),
        });
        if (!res.ok) throw new Error(`HTTP ${res.status}: ${(await res.text()).slice(0, 100)}`);
      } else {
        if (cfg.apiKey) headers['Authorization'] = `Bearer ${cfg.apiKey}`;
        const res = await fetch(cfg.apiEndpoint, {
          method: 'POST', headers,
          body: JSON.stringify({ model: cfg.model, messages: [{ role: 'user', content: 'Hi' }], max_tokens: 8 }),
        });
        if (!res.ok) throw new Error(`HTTP ${res.status}: ${(await res.text()).slice(0, 100)}`);
      }
      setTestResults(p => ({ ...p, [id]: 'ok' }));
      setTestMessages(p => ({ ...p, [id]: '✓ Connected!' }));
    } catch (err: any) {
      setTestResults(p => ({ ...p, [id]: 'fail' }));
      setTestMessages(p => ({ ...p, [id]: err.message?.slice(0, 120) || 'Failed' }));
    }
  };

  const handleSave = () => {
    localStorage.setItem('ai-slots-v2', JSON.stringify(slots));
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const handleSaveAndGo = () => {
    localStorage.setItem('ai-slots-v2', JSON.stringify(slots));
    navigate('/ai');
  };

  const enabledCount = slots.filter(s => s.enabled && s.config.apiKey).length;

  return (
    <div className="h-full flex flex-col overflow-hidden" style={{ backgroundColor: '#1e1e1e' }}>
      {/* Header */}
      <div className="flex items-center justify-between px-6 py-4 flex-shrink-0" style={{ borderBottom: '1px solid #2d2d2d' }}>
        <div>
          <h1 className="text-[18px] font-semibold mb-0.5" style={{ color: '#cccccc' }}>🔑 Quick Setup — AI Agent API Keys</h1>
          <p className="text-[11px]" style={{ color: '#6e6e6e' }}>
            Keys are stored <strong style={{ color: '#4ec9b0' }}>only in your browser</strong> (localStorage). 
            They go directly to the AI provider — never through any middleman server.
          </p>
        </div>
        <div className="flex items-center gap-2">
          {saved && <span className="text-[11px]" style={{ color: '#4ec9b0' }}>✓ Saved</span>}
          <button onClick={handleSave} className="px-3 py-1.5 rounded text-[11px] cursor-pointer" style={{ backgroundColor: '#3c3c3c', color: '#cccccc' }}>
            Save
          </button>
          <button onClick={handleSaveAndGo} className="px-4 py-1.5 rounded text-[11px] font-medium cursor-pointer" style={{ backgroundColor: '#007acc', color: '#fff' }}>
            Save & Open AI →
          </button>
        </div>
      </div>

      {/* Security Notice */}
      <div className="mx-6 mt-4 p-3 rounded-lg flex items-start gap-3" style={{ backgroundColor: '#1a2a1a', border: '1px solid #2a3a2a' }}>
        <span className="text-[18px] flex-shrink-0">🔒</span>
        <div className="text-[11px] leading-[1.6]" style={{ color: '#8fbc8f' }}>
          <strong>安全說明 Security:</strong> Your API keys are stored in <code className="px-1 rounded" style={{ backgroundColor: '#0d1a0d' }}>localStorage</code> — 
          they exist only on this device, in this browser. When you chat with AI, your browser sends requests 
          directly to the provider's API (e.g. api.openai.com). No key is ever sent to or stored on any other server.
          You can clear all keys anytime in Settings or by clearing browser data.
        </div>
      </div>

      {/* Agent Setup */}
      <div className="flex-1 overflow-y-auto px-6 py-4" style={{ scrollbarWidth: 'thin', scrollbarColor: '#333 transparent' }}>
        <div className="max-w-[700px] mx-auto space-y-4">
          {slots.map((s, idx) => {
            const info = PROVIDER_INFO[s.config.provider];
            const tr = testResults[s.id] || 'idle';
            const tm = testMessages[s.id] || '';
            const isOpen = activeSlot === idx;
            const isKeySet = !!s.config.apiKey;

            return (
              <div key={s.id} className="rounded-lg overflow-hidden transition-all" style={{ border: `1px solid ${isOpen ? s.color + '55' : '#2d2d2d'}`, backgroundColor: '#181818' }}>
                {/* Agent Header - click to expand */}
                <button
                  onClick={() => setActiveSlot(idx)}
                  className="w-full flex items-center gap-3 px-4 py-3 cursor-pointer transition-all"
                  style={{ backgroundColor: isOpen ? '#1a1a1a' : 'transparent' }}
                >
                  <div className="w-8 h-8 rounded-full flex items-center justify-center text-[14px] font-bold flex-shrink-0"
                    style={{ backgroundColor: s.color + '22', border: `2px solid ${s.color}`, color: s.color }}
                  >
                    {s.name.charAt(0)}
                  </div>
                  <div className="flex-1 text-left">
                    <div className="flex items-center gap-2">
                      <span className="text-[13px] font-medium" style={{ color: '#cccccc' }}>{s.name}</span>
                      <span className="text-[10px] px-1.5 py-0.5 rounded" style={{ backgroundColor: '#252526', color: '#888' }}>
                        {PROVIDER_LABELS[s.config.provider]} / {s.config.model}
                      </span>
                    </div>
                    <div className="text-[10px]" style={{ color: '#555' }}>{s.role}</div>
                  </div>

                  {/* Status indicators */}
                  <div className="flex items-center gap-2">
                    {tr === 'ok' && <span className="text-[10px] px-1.5 py-0.5 rounded" style={{ backgroundColor: '#1a2a1a', color: '#4ec9b0' }}>✓ Connected</span>}
                    {tr === 'fail' && <span className="text-[10px] px-1.5 py-0.5 rounded" style={{ backgroundColor: '#2a1a1a', color: '#f14c4c' }}>✗ Failed</span>}
                    {isKeySet && tr === 'idle' && <span className="text-[10px] px-1.5 py-0.5 rounded" style={{ backgroundColor: '#1a1a2a', color: '#6e6e6e' }}>Key set</span>}
                    {!isKeySet && <span className="text-[10px] px-1.5 py-0.5 rounded" style={{ backgroundColor: '#2a2a1a', color: '#888855' }}>No key</span>}
                    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" style={{ transform: isOpen ? 'rotate(180deg)' : '', transition: 'transform 0.2s' }}>
                      <path d="M3 4.5L6 7.5L9 4.5" stroke="#555" strokeWidth="1.5" strokeLinecap="round" />
                    </svg>
                  </div>
                </button>

                {/* Expanded Config */}
                {isOpen && (
                  <div className="px-4 pb-4 space-y-3" style={{ borderTop: '1px solid #2d2d2d' }}>
                    {/* Enable toggle */}
                    <div className="flex items-center gap-3 pt-3">
                      <button
                        onClick={() => updateSlot(idx, { enabled: !s.enabled })}
                        className="w-[40px] h-[20px] rounded-full relative cursor-pointer transition-colors"
                        style={{ backgroundColor: s.enabled ? s.color : '#3c3c3c' }}
                      >
                        <div className="w-[16px] h-[16px] rounded-full absolute top-[2px] transition-all" style={{ backgroundColor: '#fff', left: s.enabled ? '22px' : '2px' }} />
                      </button>
                      <span className="text-[12px]" style={{ color: s.enabled ? '#cccccc' : '#555' }}>
                        {s.enabled ? 'Enabled' : 'Disabled'}
                      </span>
                    </div>

                    {/* Provider */}
                    <div>
                      <label className="text-[10px] uppercase tracking-wider font-semibold mb-1.5 block" style={{ color: '#555' }}>Provider</label>
                      <div className="flex gap-1.5">
                        {(Object.keys(PROVIDER_LABELS) as AIProvider[]).map(p => (
                          <button key={p} onClick={() => handleProviderChange(idx, p)}
                            className="px-2 py-1.5 rounded text-[10px] cursor-pointer transition-all flex-1 text-center"
                            style={{
                              backgroundColor: s.config.provider === p ? s.color : '#252526',
                              color: s.config.provider === p ? '#fff' : '#888',
                              border: `1px solid ${s.config.provider === p ? s.color : '#333'}`,
                            }}
                          >
                            {PROVIDER_LABELS[p]}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* API Key */}
                    <div>
                      <div className="flex items-center justify-between mb-1.5">
                        <label className="text-[10px] uppercase tracking-wider font-semibold" style={{ color: '#555' }}>API Key</label>
                        {info.url && (
                          <a href={info.url} target="_blank" rel="noopener noreferrer" className="text-[9px] flex items-center gap-1" style={{ color: '#007acc' }}>
                            Get key ↗
                          </a>
                        )}
                      </div>
                      <div className="flex gap-2">
                        <div className="flex-1 relative">
                          <input
                            type={showKeys[s.id] ? 'text' : 'password'}
                            value={s.config.apiKey}
                            onChange={e => updateConfig(idx, { apiKey: e.target.value })}
                            placeholder={info.placeholder}
                            className="w-full px-3 py-2 rounded text-[12px] outline-none border font-mono pr-12"
                            style={{ backgroundColor: '#111', color: '#cccccc', borderColor: '#333' }}
                            onFocus={e => (e.target.style.borderColor = s.color)}
                            onBlur={e => (e.target.style.borderColor = '#333')}
                          />
                          <button
                            onClick={() => setShowKeys(p => ({ ...p, [s.id]: !p[s.id] }))}
                            className="absolute right-2 top-1/2 -translate-y-1/2 text-[9px] px-1.5 py-0.5 rounded cursor-pointer hover:bg-[#333]"
                            style={{ color: '#666' }}
                          >
                            {showKeys[s.id] ? 'Hide' : 'Show'}
                          </button>
                        </div>
                        <button
                          onClick={() => handleTest(idx)}
                          disabled={tr === 'testing'}
                          className="px-3 py-2 rounded text-[11px] font-medium cursor-pointer flex-shrink-0 transition-all"
                          style={{
                            backgroundColor: tr === 'ok' ? '#1a2a1a' : tr === 'fail' ? '#2a1a1a' : s.color,
                            color: tr === 'ok' ? '#4ec9b0' : tr === 'fail' ? '#f14c4c' : '#ffffff',
                            opacity: tr === 'testing' ? 0.5 : 1,
                          }}
                        >
                          {tr === 'testing' ? '...' : tr === 'ok' ? '✓ OK' : tr === 'fail' ? 'Retry' : 'Test'}
                        </button>
                      </div>
                      <div className="text-[9px] mt-1" style={{ color: '#444' }}>{info.help}</div>
                      {tr === 'fail' && tm && (
                        <div className="text-[9px] mt-1 p-1.5 rounded" style={{ backgroundColor: '#1a0d0d', color: '#f14c4c' }}>
                          {tm}
                        </div>
                      )}
                    </div>

                    {/* Model */}
                    <div>
                      <label className="text-[10px] uppercase tracking-wider font-semibold mb-1.5 block" style={{ color: '#555' }}>Model</label>
                      <select
                        value={s.config.model}
                        onChange={e => updateConfig(idx, { model: e.target.value })}
                        className="w-full px-3 py-2 rounded text-[12px] outline-none cursor-pointer appearance-none"
                        style={{ backgroundColor: '#111', color: '#cccccc', border: '1px solid #333' }}
                      >
                        {DEFAULT_MODELS[s.config.provider].map(m => <option key={m} value={m}>{m}</option>)}
                      </select>
                    </div>
                  </div>
                )}
              </div>
            );
          })}

          {/* Summary */}
          <div className="p-4 rounded-lg text-center" style={{ backgroundColor: '#111', border: '1px solid #2d2d2d' }}>
            <div className="text-[12px] mb-2" style={{ color: '#888' }}>
              {enabledCount === 0 ? 'Configure at least 1 agent to start' : `${enabledCount} agent${enabledCount > 1 ? 's' : ''} ready`}
            </div>
            <div className="flex items-center justify-center gap-3">
              {slots.map(s => (
                <div key={s.id} className="flex flex-col items-center gap-1">
                  <div className="w-3 h-3 rounded-full" style={{
                    backgroundColor: s.enabled && s.config.apiKey ? s.color : '#333',
                    boxShadow: s.enabled && s.config.apiKey ? `0 0 8px ${s.color}44` : 'none',
                  }} />
                  <span className="text-[8px]" style={{ color: '#555' }}>{s.name}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

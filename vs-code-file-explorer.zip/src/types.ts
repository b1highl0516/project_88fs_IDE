export interface FileNode {
  id: string;
  name: string;
  type: 'file' | 'folder';
  children?: FileNode[];
  extension?: string;
}

export interface ContextMenuAction {
  label: string;
  icon: string;
  shortcut?: string;
  dividerAfter?: boolean;
  danger?: boolean;
  action: () => void;
}

export interface ContextMenuPosition {
  x: number;
  y: number;
}

// AI API Types
export type AIProvider = 'openai' | 'anthropic' | 'google' | 'deepseek' | 'custom';

export interface AIConfig {
  provider: AIProvider;
  apiKey: string;
  apiEndpoint: string;
  model: string;
  temperature: number;
  maxTokens: number;
  systemPrompt: string;
  stream: boolean;
}

// Multi-AI Slot
export interface AISlot {
  id: string; // 'ai-1' | 'ai-2' | 'ai-3'
  name: string;
  color: string;
  enabled: boolean;
  config: AIConfig;
  role: string; // e.g. "Lead Architect", "Code Reviewer", "QA Tester"
}

export type CollabMode = 'all' | 'round-robin' | 'select';

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system' | 'collab-status';
  content: string;
  timestamp: number;
  isStreaming?: boolean;
  model?: string;
  tokensUsed?: number;
  slotId?: string; // which AI slot produced this
  slotName?: string;
  slotColor?: string;
}

export interface ChatSession {
  id: string;
  title: string;
  messages: ChatMessage[];
  createdAt: number;
  updatedAt: number;
}

export const DEFAULT_MODELS: Record<AIProvider, string[]> = {
  openai: ['gpt-4o', 'gpt-4o-mini', 'gpt-4-turbo', 'gpt-3.5-turbo', 'o1-preview', 'o1-mini'],
  anthropic: ['claude-sonnet-4-20250514', 'claude-3-5-sonnet-20241022', 'claude-3-5-haiku-20241022', 'claude-3-opus-20240229'],
  google: ['gemini-2.0-flash', 'gemini-1.5-pro', 'gemini-1.5-flash'],
  deepseek: ['deepseek-chat', 'deepseek-coder', 'deepseek-reasoner'],
  custom: ['custom-model'],
};

export const DEFAULT_ENDPOINTS: Record<AIProvider, string> = {
  openai: 'https://api.openai.com/v1/chat/completions',
  anthropic: 'https://api.anthropic.com/v1/messages',
  google: 'https://generativelanguage.googleapis.com/v1beta/models',
  deepseek: 'https://api.deepseek.com/v1/chat/completions',
  custom: 'http://localhost:11434/v1/chat/completions',
};

export const PROVIDER_LABELS: Record<AIProvider, string> = {
  openai: 'OpenAI',
  anthropic: 'Anthropic',
  google: 'Google Gemini',
  deepseek: 'DeepSeek',
  custom: 'Custom / Local',
};

export const AI_SLOT_DEFAULTS: AISlot[] = [
  {
    id: 'ai-1',
    name: 'Architect',
    color: '#007acc',
    enabled: true,
    role: 'Lead Architect — Focus on system design, architecture patterns, and overall code structure.',
    config: {
      provider: 'openai',
      apiKey: '',
      apiEndpoint: DEFAULT_ENDPOINTS.openai,
      model: 'gpt-4o',
      temperature: 0.7,
      maxTokens: 4096,
      systemPrompt: 'You are AI Architect, a senior software architect. Focus on system design, architecture patterns, scalability, and code structure. When collaborating with other AIs, build on their suggestions and point out architectural concerns. Be concise.',
      stream: true,
    },
  },
  {
    id: 'ai-2',
    name: 'Coder',
    color: '#e5c07b',
    enabled: false,
    role: 'Senior Developer — Write implementation code, algorithms, and handle technical details.',
    config: {
      provider: 'anthropic',
      apiKey: '',
      apiEndpoint: DEFAULT_ENDPOINTS.anthropic,
      model: 'claude-sonnet-4-20250514',
      temperature: 0.5,
      maxTokens: 4096,
      systemPrompt: 'You are AI Coder, a senior developer. Focus on writing clean, efficient implementation code. When collaborating with other AIs, follow the architecture suggestions and provide concrete code implementations. Be concise.',
      stream: true,
    },
  },
  {
    id: 'ai-3',
    name: 'Reviewer',
    color: '#c678dd',
    enabled: false,
    role: 'Code Reviewer — Review for bugs, security issues, performance, and best practices.',
    config: {
      provider: 'deepseek',
      apiKey: '',
      apiEndpoint: DEFAULT_ENDPOINTS.deepseek,
      model: 'deepseek-chat',
      temperature: 0.3,
      maxTokens: 4096,
      systemPrompt: 'You are AI Reviewer, a code review specialist. Focus on finding bugs, security vulnerabilities, performance issues, and suggesting best practices. When collaborating, review the other AIs\' suggestions critically. Be concise.',
      stream: true,
    },
  },
];

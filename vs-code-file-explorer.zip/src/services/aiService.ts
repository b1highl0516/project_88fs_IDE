import { AIConfig, ChatMessage } from '../types';

export async function sendChatRequest(
  config: AIConfig,
  messages: ChatMessage[],
  onChunk: (text: string) => void,
  onDone: (fullText: string, tokensUsed?: number) => void,
  onError: (error: string) => void,
  signal?: AbortSignal
): Promise<void> {
  const { provider, apiKey } = config;

  if (!apiKey && provider !== 'custom') {
    onError('API Key is required. Please configure your API key in settings.');
    return;
  }

  try {
    if (provider === 'anthropic') {
      await sendAnthropicRequest(config, messages, onChunk, onDone, onError, signal);
    } else if (provider === 'google') {
      await sendGoogleRequest(config, messages, onChunk, onDone, onError, signal);
    } else {
      // OpenAI-compatible (OpenAI, DeepSeek, Custom)
      await sendOpenAICompatibleRequest(config, messages, onChunk, onDone, onError, signal);
    }
  } catch (err: any) {
    if (err.name === 'AbortError') {
      onDone('*(Request cancelled)*');
      return;
    }
    onError(err.message || 'Unknown error occurred');
  }
}

async function sendOpenAICompatibleRequest(
  config: AIConfig,
  messages: ChatMessage[],
  onChunk: (text: string) => void,
  onDone: (fullText: string, tokensUsed?: number) => void,
  onError: (error: string) => void,
  signal?: AbortSignal
) {
  const { apiKey, apiEndpoint, model, temperature, maxTokens, systemPrompt, stream } = config;

  const apiMessages = [];
  if (systemPrompt) {
    apiMessages.push({ role: 'system', content: systemPrompt });
  }
  for (const msg of messages) {
    if (msg.role === 'user' || msg.role === 'assistant') {
      apiMessages.push({ role: msg.role, content: msg.content });
    }
  }

  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };
  if (apiKey) {
    headers['Authorization'] = `Bearer ${apiKey}`;
  }

  const body = {
    model,
    messages: apiMessages,
    temperature,
    max_tokens: maxTokens,
    stream,
  };

  const response = await fetch(apiEndpoint, {
    method: 'POST',
    headers,
    body: JSON.stringify(body),
    signal,
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => null);
    const errorMsg = errorData?.error?.message || errorData?.message || `HTTP ${response.status}: ${response.statusText}`;
    onError(errorMsg);
    return;
  }

  if (stream && response.body) {
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let fullText = '';

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      const chunk = decoder.decode(value, { stream: true });
      const lines = chunk.split('\n').filter(line => line.trim().startsWith('data:'));

      for (const line of lines) {
        const data = line.replace('data: ', '').trim();
        if (data === '[DONE]') continue;

        try {
          const parsed = JSON.parse(data);
          const content = parsed.choices?.[0]?.delta?.content || '';
          if (content) {
            fullText += content;
            onChunk(fullText);
          }
        } catch {
          // skip unparseable lines
        }
      }
    }

    onDone(fullText);
  } else {
    const data = await response.json();
    const content = data.choices?.[0]?.message?.content || '';
    const tokensUsed = data.usage?.total_tokens;
    onChunk(content);
    onDone(content, tokensUsed);
  }
}

async function sendAnthropicRequest(
  config: AIConfig,
  messages: ChatMessage[],
  onChunk: (text: string) => void,
  onDone: (fullText: string, tokensUsed?: number) => void,
  onError: (error: string) => void,
  signal?: AbortSignal
) {
  const { apiKey, apiEndpoint, model, temperature, maxTokens, systemPrompt, stream } = config;

  const apiMessages = [];
  for (const msg of messages) {
    if (msg.role === 'user' || msg.role === 'assistant') {
      apiMessages.push({ role: msg.role, content: msg.content });
    }
  }

  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    'x-api-key': apiKey,
    'anthropic-version': '2023-06-01',
    'anthropic-dangerous-direct-browser-access': 'true',
  };

  const body: Record<string, any> = {
    model,
    messages: apiMessages,
    max_tokens: maxTokens,
    stream,
  };

  if (temperature !== undefined) {
    body.temperature = temperature;
  }
  if (systemPrompt) {
    body.system = systemPrompt;
  }

  const response = await fetch(apiEndpoint, {
    method: 'POST',
    headers,
    body: JSON.stringify(body),
    signal,
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => null);
    const errorMsg = errorData?.error?.message || `HTTP ${response.status}: ${response.statusText}`;
    onError(errorMsg);
    return;
  }

  if (stream && response.body) {
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let fullText = '';

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      const chunk = decoder.decode(value, { stream: true });
      const lines = chunk.split('\n').filter(line => line.trim().startsWith('data:'));

      for (const line of lines) {
        const data = line.replace('data: ', '').trim();
        if (data === '[DONE]') continue;

        try {
          const parsed = JSON.parse(data);
          if (parsed.type === 'content_block_delta') {
            const content = parsed.delta?.text || '';
            if (content) {
              fullText += content;
              onChunk(fullText);
            }
          }
        } catch {
          // skip
        }
      }
    }
    onDone(fullText);
  } else {
    const data = await response.json();
    const content = data.content?.[0]?.text || '';
    const tokensUsed = (data.usage?.input_tokens || 0) + (data.usage?.output_tokens || 0);
    onChunk(content);
    onDone(content, tokensUsed);
  }
}

async function sendGoogleRequest(
  config: AIConfig,
  messages: ChatMessage[],
  onChunk: (text: string) => void,
  onDone: (fullText: string, tokensUsed?: number) => void,
  onError: (error: string) => void,
  signal?: AbortSignal
) {
  const { apiKey, model, temperature, maxTokens, systemPrompt, stream } = config;

  const contents = [];
  for (const msg of messages) {
    if (msg.role === 'user' || msg.role === 'assistant') {
      contents.push({
        role: msg.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: msg.content }],
      });
    }
  }

  const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${model}:${stream ? 'streamGenerateContent' : 'generateContent'}?key=${apiKey}`;

  const body: Record<string, any> = {
    contents,
    generationConfig: {
      temperature,
      maxOutputTokens: maxTokens,
    },
  };
  if (systemPrompt) {
    body.systemInstruction = { parts: [{ text: systemPrompt }] };
  }

  const response = await fetch(endpoint, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
    signal,
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => null);
    const errorMsg = errorData?.error?.message || `HTTP ${response.status}: ${response.statusText}`;
    onError(errorMsg);
    return;
  }

  if (stream && response.body) {
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let fullText = '';
    let buffer = '';

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });

      // Google returns JSON array chunks
      try {
        const jsonChunks = buffer.match(/\{[^{}]*"text"\s*:\s*"[^"]*"[^{}]*\}/g);
        if (jsonChunks) {
          for (const jc of jsonChunks) {
            try {
              const parsed = JSON.parse(jc);
              const text = parsed.text || '';
              if (text) {
                fullText += text;
              }
            } catch { /* skip */ }
          }
          onChunk(fullText);
        }
      } catch { /* continue buffering */ }
    }
    onDone(fullText);
  } else {
    const data = await response.json();
    const content = data.candidates?.[0]?.content?.parts?.[0]?.text || '';
    const tokensUsed = data.usageMetadata?.totalTokenCount;
    onChunk(content);
    onDone(content, tokensUsed);
  }
}

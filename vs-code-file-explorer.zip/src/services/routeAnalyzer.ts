// ═══════════════════════════════════════════════════════════════════════════
// 路由效能分析引擎 - Route Performance Analysis Engine
// Analyzes routing rules, scalability, and performance ceiling
// ═══════════════════════════════════════════════════════════════════════════

import { RouteDefinition } from '../router/types';
import { matchPath, parsePattern, findBestMatch } from '../router/utils';

export interface PerformanceAxis {
  id: string;
  label: string;
  labelZh: string;
  score: number;       // 0-100 normalized score
  raw: number;         // raw measured value
  unit: string;
  description: string;
  angle: number;       // radial position in degrees
}

export interface AnalysisResult {
  axes: PerformanceAxis[];
  overall: number;          // 0-100
  grade: string;            // S/A/B/C/D
  routeCount: number;
  staticRoutes: number;
  dynamicRoutes: number;
  maxDepth: number;
  avgMatchTimeUs: number;   // microseconds
  worstMatchTimeUs: number;
  throughputOpsPerSec: number;
  scalabilityFactor: number;
  memoryEstimateKB: number;
  timestamp: number;
}

/**
 * Run complete performance analysis on the route table
 */
export function analyzeRoutes(routes: RouteDefinition[]): AnalysisResult {
  // ─── 1. Structure Analysis ───
  const allRoutes = flattenRoutes(routes);
  const routeCount = allRoutes.length;
  const staticRoutes = allRoutes.filter(r => !r.path.includes(':')).length;
  const dynamicRoutes = routeCount - staticRoutes;
  const maxDepth = Math.max(...allRoutes.map(r => r.path.split('/').filter(Boolean).length), 1);

  // ─── 2. Match Speed Benchmark ───
  const testPaths = generateTestPaths(allRoutes);
  const { avgUs, worstUs } = benchmarkMatching(routes, testPaths, 2000);

  // ─── 3. Throughput Test ───
  const throughput = benchmarkThroughput(routes, testPaths, 100);

  // ─── 4. Scalability Test ───
  const scalability = benchmarkScalability(routes, allRoutes);

  // ─── 5. Memory Estimate ───
  const memKB = estimateMemory(allRoutes);

  // ─── 6. Pattern Complexity ───
  const complexity = analyzeComplexity(allRoutes);

  // ─── 7. Collision Detection ───
  const collisionScore = analyzeCollisions(allRoutes);

  // ─── 8. Guard/Loader overhead estimate ───
  const middlewareCount = allRoutes.filter(r => r.guard || r.loader).length;
  const middlewareScore = Math.max(0, 100 - middlewareCount * 15);

  // ─── Build Axes (8 directions) ───
  const axes: PerformanceAxis[] = [
    {
      id: 'matchSpeed',
      label: 'Match Speed',
      labelZh: '匹配速度',
      score: speedToScore(avgUs),
      raw: avgUs,
      unit: 'μs',
      description: `Avg match time: ${avgUs.toFixed(1)}μs`,
      angle: 0,
    },
    {
      id: 'throughput',
      label: 'Throughput',
      labelZh: '吞吐量',
      score: throughputToScore(throughput),
      raw: throughput,
      unit: 'ops/s',
      description: `${formatNumber(throughput)} ops/sec`,
      angle: 45,
    },
    {
      id: 'scalability',
      label: 'Scalability',
      labelZh: '可擴展性',
      score: scalability,
      raw: scalability,
      unit: '%',
      description: `Scales to ${scalability >= 80 ? '10K+' : scalability >= 50 ? '1K+' : '100+'} routes`,
      angle: 90,
    },
    {
      id: 'memory',
      label: 'Memory',
      labelZh: '記憶體效率',
      score: memoryToScore(memKB),
      raw: memKB,
      unit: 'KB',
      description: `~${memKB.toFixed(1)}KB footprint`,
      angle: 135,
    },
    {
      id: 'complexity',
      label: 'Simplicity',
      labelZh: '模式簡潔度',
      score: complexity,
      raw: complexity,
      unit: '%',
      description: `Pattern complexity: ${complexity >= 80 ? 'Low' : complexity >= 50 ? 'Medium' : 'High'}`,
      angle: 180,
    },
    {
      id: 'collision',
      label: 'Isolation',
      labelZh: '路徑隔離度',
      score: collisionScore,
      raw: collisionScore,
      unit: '%',
      description: `${collisionScore >= 90 ? 'No' : collisionScore >= 60 ? 'Minor' : 'Major'} collisions`,
      angle: 225,
    },
    {
      id: 'coverage',
      label: 'Coverage',
      labelZh: '路由覆蓋率',
      score: Math.min(100, routeCount * 12),
      raw: routeCount,
      unit: 'routes',
      description: `${routeCount} routes registered`,
      angle: 270,
    },
    {
      id: 'middleware',
      label: 'Middleware',
      labelZh: '中間件效率',
      score: middlewareScore,
      raw: middlewareCount,
      unit: 'guards',
      description: `${middlewareCount} guards/loaders`,
      angle: 315,
    },
  ];

  const overall = Math.round(axes.reduce((s, a) => s + a.score, 0) / axes.length);
  const grade = overall >= 90 ? 'S' : overall >= 75 ? 'A' : overall >= 60 ? 'B' : overall >= 40 ? 'C' : 'D';

  return {
    axes,
    overall,
    grade,
    routeCount,
    staticRoutes,
    dynamicRoutes,
    maxDepth,
    avgMatchTimeUs: avgUs,
    worstMatchTimeUs: worstUs,
    throughputOpsPerSec: throughput,
    scalabilityFactor: scalability,
    memoryEstimateKB: memKB,
    timestamp: Date.now(),
  };
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

function flattenRoutes(routes: RouteDefinition[], prefix = ''): RouteDefinition[] {
  const result: RouteDefinition[] = [];
  for (const r of routes) {
    result.push({ ...r, path: prefix + r.path });
    if (r.children) {
      result.push(...flattenRoutes(r.children, r.path));
    }
  }
  return result;
}

function generateTestPaths(routes: RouteDefinition[]): string[] {
  const paths: string[] = ['/'];
  for (const r of routes) {
    // Add the literal path
    paths.push(r.path.replace(/:(\w+)/g, 'test-val'));
    // Add a non-matching variant
    paths.push(r.path + '/deep/nested/extra');
    // Add root variant
    paths.push('/' + r.path.split('/').filter(Boolean)[0] || 'x');
  }
  // Add random miss paths
  paths.push('/zzzz/404/not/found', '/xxxxxx', '/a/b/c/d/e/f');
  return [...new Set(paths)];
}

function benchmarkMatching(
  routes: RouteDefinition[],
  testPaths: string[],
  iterations: number
): { avgUs: number; worstUs: number; samples: number[] } {
  const samples: number[] = [];
  let worstUs = 0;

  for (let i = 0; i < iterations; i++) {
    const path = testPaths[i % testPaths.length];
    const start = performance.now();
    findBestMatch(routes, path);
    const elapsed = (performance.now() - start) * 1000; // to microseconds
    samples.push(elapsed);
    if (elapsed > worstUs) worstUs = elapsed;
  }

  const avgUs = samples.reduce((a, b) => a + b, 0) / samples.length;
  return { avgUs, worstUs, samples };
}

function benchmarkThroughput(
  routes: RouteDefinition[],
  testPaths: string[],
  durationMs: number
): number {
  const start = performance.now();
  let ops = 0;
  while (performance.now() - start < durationMs) {
    const path = testPaths[ops % testPaths.length];
    findBestMatch(routes, path);
    ops++;
  }
  const elapsed = performance.now() - start;
  return Math.round((ops / elapsed) * 1000);
}

function benchmarkScalability(
  _routes: RouteDefinition[],
  allRoutes: RouteDefinition[]
): number {
  // Simulate larger route tables
  const sizes = [10, 50, 100, 500];
  const times: number[] = [];

  for (const size of sizes) {
    const bigRoutes: RouteDefinition[] = [];
    for (let i = 0; i < size; i++) {
      const base = allRoutes[i % allRoutes.length];
      bigRoutes.push({
        ...base,
        path: `/gen${i}/${base.path.slice(1) || 'index'}`,
      });
    }
    const testPath = bigRoutes[Math.floor(size / 2)]?.path.replace(/:(\w+)/g, 'val') || '/';
    const start = performance.now();
    for (let j = 0; j < 200; j++) {
      findBestMatch(bigRoutes, testPath);
    }
    times.push((performance.now() - start) / 200);
  }

  // O(n) baseline: time should scale linearly
  // Score high if time growth is near-linear
  if (times.length < 2) return 80;
  const ratio = times[times.length - 1] / Math.max(times[0], 0.001);
  const idealRatio = sizes[sizes.length - 1] / sizes[0];
  const efficiency = Math.min(1, idealRatio / Math.max(ratio, 0.1));
  return Math.round(Math.min(100, efficiency * 100));
}

function estimateMemory(routes: RouteDefinition[]): number {
  // Rough estimate: each route ~ pattern string + segments array + meta
  let bytes = 0;
  for (const r of routes) {
    bytes += r.path.length * 2; // string chars
    bytes += (r.path.split('/').length) * 40; // segment objects
    bytes += 200; // base overhead
    if (r.meta) bytes += JSON.stringify(r.meta).length * 2;
  }
  return bytes / 1024;
}

function analyzeComplexity(routes: RouteDefinition[]): number {
  let totalComplexity = 0;
  for (const r of routes) {
    const parsed = parsePattern(r.path);
    let c = 0;
    c += parsed.segments.length * 5;
    c += parsed.segments.filter(s => s.type === 'param').length * 10;
    c += parsed.hasWildcard ? 20 : 0;
    totalComplexity += c;
  }
  const avg = totalComplexity / Math.max(routes.length, 1);
  // Lower complexity = higher score
  return Math.round(Math.max(0, Math.min(100, 100 - avg * 2)));
}

function analyzeCollisions(routes: RouteDefinition[]): number {
  let collisions = 0;
  for (let i = 0; i < routes.length; i++) {
    for (let j = i + 1; j < routes.length; j++) {
      const testPath = routes[i].path.replace(/:(\w+)/g, 'x');
      const m = matchPath(routes[j].path, testPath);
      if (m.match) collisions++;
    }
  }
  const maxPossible = (routes.length * (routes.length - 1)) / 2;
  return Math.round(Math.max(0, 100 - (collisions / Math.max(maxPossible, 1)) * 200));
}

function speedToScore(avgUs: number): number {
  // < 1μs = 100, 10μs = 70, 100μs = 30, 1000μs = 5
  if (avgUs <= 0.5) return 100;
  if (avgUs <= 1) return 95;
  if (avgUs <= 5) return 85;
  if (avgUs <= 10) return 75;
  if (avgUs <= 50) return 60;
  if (avgUs <= 100) return 40;
  if (avgUs <= 500) return 20;
  return 5;
}

function throughputToScore(ops: number): number {
  if (ops >= 1000000) return 100;
  if (ops >= 500000) return 90;
  if (ops >= 100000) return 80;
  if (ops >= 50000) return 70;
  if (ops >= 10000) return 55;
  if (ops >= 1000) return 35;
  return 15;
}

function memoryToScore(kb: number): number {
  if (kb <= 1) return 100;
  if (kb <= 5) return 90;
  if (kb <= 20) return 80;
  if (kb <= 50) return 65;
  if (kb <= 200) return 45;
  return 20;
}

function formatNumber(n: number): string {
  if (n >= 1000000) return (n / 1000000).toFixed(1) + 'M';
  if (n >= 1000) return (n / 1000).toFixed(1) + 'K';
  return n.toString();
}

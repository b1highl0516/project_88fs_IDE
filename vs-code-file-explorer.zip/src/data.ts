import { FileNode } from './types';

export const fileTree: FileNode[] = [
  {
    id: '1',
    name: 'src',
    type: 'folder',
    children: [
      {
        id: '1-1',
        name: 'components',
        type: 'folder',
        children: [
          {
            id: '1-1-1',
            name: 'ui',
            type: 'folder',
            children: [
              { id: '1-1-1-1', name: 'Button.tsx', type: 'file', extension: 'tsx' },
              { id: '1-1-1-2', name: 'Input.tsx', type: 'file', extension: 'tsx' },
              { id: '1-1-1-3', name: 'Modal.tsx', type: 'file', extension: 'tsx' },
              { id: '1-1-1-4', name: 'Dropdown.tsx', type: 'file', extension: 'tsx' },
              { id: '1-1-1-5', name: 'Button.module.css', type: 'file', extension: 'css' },
            ],
          },
          {
            id: '1-1-2',
            name: 'layout',
            type: 'folder',
            children: [
              { id: '1-1-2-1', name: 'Header.tsx', type: 'file', extension: 'tsx' },
              { id: '1-1-2-2', name: 'Sidebar.tsx', type: 'file', extension: 'tsx' },
              { id: '1-1-2-3', name: 'Footer.tsx', type: 'file', extension: 'tsx' },
              { id: '1-1-2-4', name: 'Layout.tsx', type: 'file', extension: 'tsx' },
            ],
          },
          { id: '1-1-3', name: 'App.tsx', type: 'file', extension: 'tsx' },
          { id: '1-1-4', name: 'App.test.tsx', type: 'file', extension: 'tsx' },
        ],
      },
      {
        id: '1-2',
        name: 'hooks',
        type: 'folder',
        children: [
          { id: '1-2-1', name: 'useAuth.ts', type: 'file', extension: 'ts' },
          { id: '1-2-2', name: 'useTheme.ts', type: 'file', extension: 'ts' },
          { id: '1-2-3', name: 'useLocalStorage.ts', type: 'file', extension: 'ts' },
          { id: '1-2-4', name: 'useDebounce.ts', type: 'file', extension: 'ts' },
        ],
      },
      {
        id: '1-3',
        name: 'utils',
        type: 'folder',
        children: [
          { id: '1-3-1', name: 'helpers.ts', type: 'file', extension: 'ts' },
          { id: '1-3-2', name: 'constants.ts', type: 'file', extension: 'ts' },
          { id: '1-3-3', name: 'api.ts', type: 'file', extension: 'ts' },
          { id: '1-3-4', name: 'validators.ts', type: 'file', extension: 'ts' },
        ],
      },
      {
        id: '1-4',
        name: 'styles',
        type: 'folder',
        children: [
          { id: '1-4-1', name: 'globals.css', type: 'file', extension: 'css' },
          { id: '1-4-2', name: 'variables.scss', type: 'file', extension: 'scss' },
          { id: '1-4-3', name: 'tailwind.css', type: 'file', extension: 'css' },
        ],
      },
      {
        id: '1-5',
        name: 'assets',
        type: 'folder',
        children: [
          {
            id: '1-5-1',
            name: 'images',
            type: 'folder',
            children: [
              { id: '1-5-1-1', name: 'logo.svg', type: 'file', extension: 'svg' },
              { id: '1-5-1-2', name: 'hero.png', type: 'file', extension: 'png' },
              { id: '1-5-1-3', name: 'banner.jpg', type: 'file', extension: 'jpg' },
            ],
          },
          {
            id: '1-5-2',
            name: 'fonts',
            type: 'folder',
            children: [
              { id: '1-5-2-1', name: 'Inter-Regular.woff2', type: 'file', extension: 'woff2' },
              { id: '1-5-2-2', name: 'Inter-Bold.woff2', type: 'file', extension: 'woff2' },
            ],
          },
        ],
      },
      {
        id: '1-6',
        name: 'types',
        type: 'folder',
        children: [
          { id: '1-6-1', name: 'index.d.ts', type: 'file', extension: 'ts' },
          { id: '1-6-2', name: 'api.types.ts', type: 'file', extension: 'ts' },
          { id: '1-6-3', name: 'env.d.ts', type: 'file', extension: 'ts' },
        ],
      },
      { id: '1-7', name: 'main.tsx', type: 'file', extension: 'tsx' },
      { id: '1-8', name: 'index.tsx', type: 'file', extension: 'tsx' },
      { id: '1-9', name: 'vite-env.d.ts', type: 'file', extension: 'ts' },
    ],
  },
  {
    id: '2',
    name: 'public',
    type: 'folder',
    children: [
      { id: '2-1', name: 'favicon.ico', type: 'file', extension: 'ico' },
      { id: '2-2', name: 'robots.txt', type: 'file', extension: 'txt' },
      { id: '2-3', name: 'manifest.json', type: 'file', extension: 'json' },
      { id: '2-4', name: 'index.html', type: 'file', extension: 'html' },
    ],
  },
  {
    id: '3',
    name: 'tests',
    type: 'folder',
    children: [
      {
        id: '3-1',
        name: '__mocks__',
        type: 'folder',
        children: [
          { id: '3-1-1', name: 'fileMock.js', type: 'file', extension: 'js' },
          { id: '3-1-2', name: 'styleMock.js', type: 'file', extension: 'js' },
        ],
      },
      { id: '3-2', name: 'setup.ts', type: 'file', extension: 'ts' },
      { id: '3-3', name: 'utils.test.ts', type: 'file', extension: 'ts' },
    ],
  },
  {
    id: '4',
    name: 'docs',
    type: 'folder',
    children: [
      { id: '4-1', name: 'README.md', type: 'file', extension: 'md' },
      { id: '4-2', name: 'CONTRIBUTING.md', type: 'file', extension: 'md' },
      { id: '4-3', name: 'CHANGELOG.md', type: 'file', extension: 'md' },
      { id: '4-4', name: 'API.md', type: 'file', extension: 'md' },
    ],
  },
  {
    id: '5',
    name: '.github',
    type: 'folder',
    children: [
      {
        id: '5-1',
        name: 'workflows',
        type: 'folder',
        children: [
          { id: '5-1-1', name: 'ci.yml', type: 'file', extension: 'yml' },
          { id: '5-1-2', name: 'deploy.yml', type: 'file', extension: 'yml' },
        ],
      },
      { id: '5-2', name: 'CODEOWNERS', type: 'file', extension: '' },
    ],
  },
  { id: '6', name: 'package.json', type: 'file', extension: 'json' },
  { id: '7', name: 'package-lock.json', type: 'file', extension: 'json' },
  { id: '8', name: 'tsconfig.json', type: 'file', extension: 'json' },
  { id: '9', name: 'vite.config.ts', type: 'file', extension: 'ts' },
  { id: '10', name: 'tailwind.config.js', type: 'file', extension: 'js' },
  { id: '11', name: '.gitignore', type: 'file', extension: '' },
  { id: '12', name: '.env', type: 'file', extension: '' },
  { id: '13', name: '.env.example', type: 'file', extension: '' },
  { id: '14', name: 'README.md', type: 'file', extension: 'md' },
  { id: '15', name: 'LICENSE', type: 'file', extension: '' },
  { id: '16', name: 'Dockerfile', type: 'file', extension: '' },
  { id: '17', name: 'docker-compose.yml', type: 'file', extension: 'yml' },
  { id: '18', name: '.eslintrc.json', type: 'file', extension: 'json' },
  { id: '19', name: '.prettierrc', type: 'file', extension: '' },
];

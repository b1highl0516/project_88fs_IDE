// ═══════════════════════════════════════════════════════════════════════════
// 路由核心組件 - Core Router Components
// Lightweight hash-based router for single-file builds
// ═══════════════════════════════════════════════════════════════════════════

import React, { createContext, useContext, useState, useEffect, useCallback, useMemo } from 'react';
import {
  RouteDefinition,
  RouterContextValue,
  RouterState,
  NavigateOptions,
  RouteMatch,
  RouteComponentProps,
} from './types';
import { findBestMatch, getCurrentLocation, matchPath } from './utils';

// ─── Router Context ──────────────────────────────────────────────────────────
const RouterContext = createContext<RouterContextValue | null>(null);

export function useRouter(): RouterContextValue {
  const ctx = useContext(RouterContext);
  if (!ctx) throw new Error('useRouter must be used within a RouterProvider');
  return ctx;
}

// ─── Navigation Hooks ────────────────────────────────────────────────────────
export function useNavigate() {
  const { navigate } = useRouter();
  return navigate;
}

export function useLocation() {
  const { state } = useRouter();
  return {
    path: state.currentPath,
    query: state.query,
    hash: state.hash,
    params: state.params,
  };
}

export function useParams<T extends Record<string, string> = Record<string, string>>(): T {
  const { state } = useRouter();
  return state.params as T;
}

export function useQuery(): URLSearchParams {
  const { state } = useRouter();
  return state.query;
}

export function useMatch(pattern: string): RouteMatch | null {
  const { match } = useRouter();
  return match(pattern);
}

export function useIsActive(path: string, exact: boolean = false): boolean {
  const { isActive } = useRouter();
  return isActive(path, exact);
}

// ─── Router Provider ─────────────────────────────────────────────────────────
interface RouterProviderProps {
  routes: RouteDefinition[];
  children?: React.ReactNode;
  fallback?: React.ReactNode;
  onNavigate?: (path: string, prevPath: string) => void;
}

export function RouterProvider({
  routes,
  children,
  fallback = <DefaultNotFound />,
  onNavigate,
}: RouterProviderProps) {
  const [state, setState] = useState<RouterState>(() => {
    const loc = getCurrentLocation();
    return {
      currentPath: loc.path,
      params: {},
      query: loc.query,
      hash: loc.hash,
      isNavigating: false,
      loaderData: null,
      error: null,
    };
  });

  // Handle hash change events
  useEffect(() => {
    const handleHashChange = () => {
      const loc = getCurrentLocation();
      const match = findBestMatch(routes, loc.path);

      setState(prev => {
        if (onNavigate && prev.currentPath !== loc.path) {
          onNavigate(loc.path, prev.currentPath);
        }
        return {
          ...prev,
          currentPath: loc.path,
          params: match?.params || {},
          query: loc.query,
          hash: loc.hash,
          isNavigating: false,
        };
      });
    };

    window.addEventListener('hashchange', handleHashChange);
    handleHashChange(); // Initial sync

    return () => window.removeEventListener('hashchange', handleHashChange);
  }, [routes, onNavigate]);

  // Navigate function
  const navigate = useCallback((to: string, options: NavigateOptions = {}) => {
    setState(prev => ({ ...prev, isNavigating: true }));

    let finalPath = to;

    // Preserve query if requested
    if (options.preserveQuery) {
      const currentQuery = getCurrentLocation().query.toString();
      if (currentQuery) {
        finalPath += (finalPath.includes('?') ? '&' : '?') + currentQuery;
      }
    }

    // Preserve hash if requested
    if (options.preserveHash) {
      const currentHash = window.location.hash.split('#')[1] || '';
      if (currentHash && !finalPath.includes('#')) {
        finalPath += '#' + currentHash;
      }
    }

    if (options.replace) {
      window.history.replaceState(options.state || null, '', '#' + finalPath);
    } else {
      window.history.pushState(options.state || null, '', '#' + finalPath);
    }

    // Trigger hashchange manually since pushState doesn't fire it
    window.dispatchEvent(new HashChangeEvent('hashchange'));
  }, []);

  const back = useCallback(() => window.history.back(), []);
  const forward = useCallback(() => window.history.forward(), []);

  const match = useCallback((pattern: string): RouteMatch | null => {
    const result = matchPath(pattern, state.currentPath);
    if (result.match) {
      const routeDef = routes.find(r => r.path === pattern);
      if (routeDef) {
        return {
          route: routeDef,
          params: result.params,
          path: pattern,
          score: result.score,
        };
      }
    }
    return null;
  }, [state.currentPath, routes]);

  const isActive = useCallback((path: string, exact: boolean = false): boolean => {
    if (exact) {
      return state.currentPath === path;
    }
    return state.currentPath.startsWith(path);
  }, [state.currentPath]);

  const contextValue = useMemo<RouterContextValue>(() => ({
    state,
    navigate,
    back,
    forward,
    match,
    isActive,
    routes,
  }), [state, navigate, back, forward, match, isActive, routes]);

  // Find matching route
  const currentMatch = useMemo(() => findBestMatch(routes, state.currentPath), [routes, state.currentPath]);

  return (
    <RouterContext.Provider value={contextValue}>
      {children}
      <RouteRenderer match={currentMatch} fallback={fallback} />
    </RouterContext.Provider>
  );
}

// ─── Route Renderer ──────────────────────────────────────────────────────────
function RouteRenderer({
  match,
  fallback,
}: {
  match: RouteMatch | null;
  fallback: React.ReactNode;
}) {
  const { state } = useRouter();

  if (!match) {
    return <>{fallback}</>;
  }

  const Component = match.route.component;
  const props: RouteComponentProps = {
    params: match.params,
    query: state.query,
    path: state.currentPath,
  };

  return <Component {...props} />;
}

// ─── Link Component ──────────────────────────────────────────────────────────
interface LinkProps extends Omit<React.AnchorHTMLAttributes<HTMLAnchorElement>, 'href'> {
  to: string;
  replace?: boolean;
  activeClassName?: string;
  activeStyle?: React.CSSProperties;
  exact?: boolean;
  preserveQuery?: boolean;
}

export function Link({
  to,
  replace = false,
  activeClassName,
  activeStyle,
  exact = false,
  preserveQuery = false,
  className,
  style,
  children,
  onClick,
  ...rest
}: LinkProps) {
  const { navigate, isActive } = useRouter();
  const active = isActive(to, exact);

  const handleClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    // Allow modifier keys for new tab, etc.
    if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;

    e.preventDefault();
    navigate(to, { replace, preserveQuery });
    onClick?.(e);
  };

  const finalClassName = [className, active && activeClassName].filter(Boolean).join(' ');
  const finalStyle = active ? { ...style, ...activeStyle } : style;

  return (
    <a
      href={'#' + to}
      className={finalClassName || undefined}
      style={finalStyle}
      onClick={handleClick}
      {...rest}
    >
      {children}
    </a>
  );
}

// ─── NavLink Component (with active state) ───────────────────────────────────
export function NavLink(props: LinkProps) {
  return (
    <Link
      activeClassName="active"
      {...props}
    />
  );
}

// ─── Redirect Component ──────────────────────────────────────────────────────
interface RedirectProps {
  to: string;
  replace?: boolean;
}

export function Redirect({ to, replace = true }: RedirectProps) {
  const navigate = useNavigate();

  useEffect(() => {
    navigate(to, { replace });
  }, [navigate, to, replace]);

  return null;
}

// ─── Route Guard Component ───────────────────────────────────────────────────
interface GuardedRouteProps {
  guard: () => boolean | string;
  children: React.ReactNode;
  fallback?: React.ReactNode;
}

export function GuardedRoute({ guard, children, fallback }: GuardedRouteProps) {
  const navigate = useNavigate();
  const result = guard();

  useEffect(() => {
    if (typeof result === 'string') {
      navigate(result, { replace: true });
    }
  }, [result, navigate]);

  if (result === false) {
    return <>{fallback || null}</>;
  }

  if (typeof result === 'string') {
    return null; // Redirecting
  }

  return <>{children}</>;
}

// ─── Switch Component (render first match only) ──────────────────────────────
interface SwitchProps {
  children: React.ReactNode;
}

export function Switch({ children }: SwitchProps) {
  const { state } = useRouter();
  const childArray = React.Children.toArray(children);

  for (const child of childArray) {
    if (React.isValidElement(child)) {
      const props = child.props as { path?: string };
      if (props.path) {
        const result = matchPath(props.path, state.currentPath);
        if (result.match) {
          return <>{child}</>;
        }
      }
    }
  }

  // Return last child as fallback (usually a catch-all or NotFound)
  return <>{childArray[childArray.length - 1]}</>;
}

// ─── Route Component (declarative route definition) ─────────────────────────
interface RouteProps {
  path: string;
  component?: React.ComponentType<RouteComponentProps>;
  children?: React.ReactNode;
  exact?: boolean;
}

export function Route({ path, component: Component, children, exact = false }: RouteProps) {
  const { state } = useRouter();
  const result = matchPath(path, state.currentPath);

  if (!result.match) return null;
  if (exact && path !== state.currentPath) return null;

  if (Component) {
    return <Component params={result.params} query={state.query} path={state.currentPath} />;
  }

  return <>{children}</>;
}

// ─── Default 404 Component ───────────────────────────────────────────────────
function DefaultNotFound() {
  const { state } = useRouter();

  return (
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      height: '100%',
      color: '#6e6e6e',
      fontFamily: 'system-ui, sans-serif',
    }}>
      <div style={{ fontSize: '48px', marginBottom: '16px', opacity: 0.3 }}>404</div>
      <div style={{ fontSize: '14px', marginBottom: '8px' }}>Page not found</div>
      <code style={{
        fontSize: '12px',
        padding: '4px 8px',
        backgroundColor: '#1e1e1e',
        borderRadius: '4px',
        color: '#ce9178',
      }}>
        {state.currentPath}
      </code>
      <Link
        to="/"
        style={{
          marginTop: '16px',
          fontSize: '12px',
          color: '#007acc',
          textDecoration: 'none',
        }}
      >
        ← Back to home
      </Link>
    </div>
  );
}

// ─── Exports ─────────────────────────────────────────────────────────────────
export type { RouteDefinition, RouteComponentProps, NavigateOptions };

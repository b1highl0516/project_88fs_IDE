// ═══════════════════════════════════════════════════════════════════════════
// 路由類型定義 - Router Type Definitions
// Lightweight type-safe routing inspired by Wouter + TanStack Router
// ═══════════════════════════════════════════════════════════════════════════

export interface RouteDefinition {
  path: string;
  component: React.ComponentType<RouteComponentProps>;
  title?: string;
  icon?: string;
  children?: RouteDefinition[];
  guard?: RouteGuard;
  loader?: RouteLoader;
  meta?: RouteMeta;
}

export interface RouteComponentProps {
  params: Record<string, string>;
  query: URLSearchParams;
  path: string;
}

export type RouteGuard = (ctx: RouteContext) => boolean | Promise<boolean> | string;

export type RouteLoader<T = unknown> = (ctx: RouteContext) => T | Promise<T>;

export interface RouteMeta {
  requiresAuth?: boolean;
  layout?: 'default' | 'full' | 'minimal';
  breadcrumb?: string;
  [key: string]: unknown;
}

export interface RouteContext {
  path: string;
  params: Record<string, string>;
  query: URLSearchParams;
  hash: string;
}

export interface RouteMatch {
  route: RouteDefinition;
  params: Record<string, string>;
  path: string;
  score: number;
}

export interface RouterState {
  currentPath: string;
  params: Record<string, string>;
  query: URLSearchParams;
  hash: string;
  isNavigating: boolean;
  loaderData: unknown;
  error: Error | null;
}

export interface NavigateOptions {
  replace?: boolean;
  state?: unknown;
  preserveQuery?: boolean;
  preserveHash?: boolean;
}

export type NavigateFn = (to: string, options?: NavigateOptions) => void;

export interface RouterContextValue {
  state: RouterState;
  navigate: NavigateFn;
  back: () => void;
  forward: () => void;
  match: (pattern: string) => RouteMatch | null;
  isActive: (path: string, exact?: boolean) => boolean;
  routes: RouteDefinition[];
}

// Route path utilities
export interface PathPattern {
  pattern: string;
  segments: PathSegment[];
  hasWildcard: boolean;
}

export interface PathSegment {
  type: 'static' | 'param' | 'wildcard';
  value: string;
  name?: string;
}

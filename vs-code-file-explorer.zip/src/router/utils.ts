// ═══════════════════════════════════════════════════════════════════════════
// 路由工具函數 - Router Utility Functions
// ═══════════════════════════════════════════════════════════════════════════

import { PathPattern, PathSegment, RouteDefinition, RouteMatch } from './types';

/**
 * Parse a route path pattern into segments
 * Examples:
 *   /users/:id → [static: 'users', param: 'id']
 *   /files/* → [static: 'files', wildcard: '*']
 */
export function parsePattern(pattern: string): PathPattern {
  const segments: PathSegment[] = [];
  const parts = pattern.split('/').filter(Boolean);
  let hasWildcard = false;

  for (const part of parts) {
    if (part.startsWith(':')) {
      segments.push({ type: 'param', value: part, name: part.slice(1) });
    } else if (part === '*' || part === '**') {
      segments.push({ type: 'wildcard', value: part });
      hasWildcard = true;
    } else {
      segments.push({ type: 'static', value: part });
    }
  }

  return { pattern, segments, hasWildcard };
}

/**
 * Match a path against a pattern and extract params
 */
export function matchPath(
  pattern: string,
  path: string
): { match: boolean; params: Record<string, string>; score: number } {
  const parsed = parsePattern(pattern);
  const pathParts = path.split('/').filter(Boolean);
  const params: Record<string, string> = {};
  let score = 0;

  // Exact match gets highest priority
  if (pattern === path) {
    return { match: true, params: {}, score: 1000 };
  }

  // Handle root path
  if (pattern === '/' && pathParts.length === 0) {
    return { match: true, params: {}, score: 999 };
  }

  // Check segment by segment
  let pathIdx = 0;
  for (let i = 0; i < parsed.segments.length; i++) {
    const seg = parsed.segments[i];

    if (seg.type === 'wildcard') {
      // Wildcard matches rest of path
      params['*'] = pathParts.slice(pathIdx).join('/');
      score += 1;
      return { match: true, params, score };
    }

    if (pathIdx >= pathParts.length) {
      return { match: false, params: {}, score: 0 };
    }

    const pathPart = pathParts[pathIdx];

    if (seg.type === 'static') {
      if (seg.value !== pathPart) {
        return { match: false, params: {}, score: 0 };
      }
      score += 10; // Static matches score higher
    } else if (seg.type === 'param') {
      params[seg.name!] = pathPart;
      score += 5; // Param matches score lower than static
    }

    pathIdx++;
  }

  // If we've consumed all pattern segments, check if path has more
  if (pathIdx < pathParts.length && !parsed.hasWildcard) {
    return { match: false, params: {}, score: 0 };
  }

  return { match: true, params, score };
}

/**
 * Find the best matching route from a list
 */
export function findBestMatch(
  routes: RouteDefinition[],
  path: string,
  basePath: string = ''
): RouteMatch | null {
  let bestMatch: RouteMatch | null = null;

  for (const route of routes) {
    const fullPattern = joinPaths(basePath, route.path);
    const result = matchPath(fullPattern, path);

    if (result.match) {
      if (!bestMatch || result.score > bestMatch.score) {
        bestMatch = {
          route,
          params: result.params,
          path: fullPattern,
          score: result.score,
        };
      }
    }

    // Check children recursively
    if (route.children) {
      const childMatch = findBestMatch(route.children, path, fullPattern);
      if (childMatch && (!bestMatch || childMatch.score > bestMatch.score)) {
        bestMatch = childMatch;
      }
    }
  }

  return bestMatch;
}

/**
 * Join path segments
 */
export function joinPaths(...paths: string[]): string {
  return '/' + paths
    .map(p => p.replace(/^\/|\/$/g, ''))
    .filter(Boolean)
    .join('/');
}

/**
 * Build a path with params
 */
export function buildPath(pattern: string, params: Record<string, string> = {}): string {
  let result = pattern;
  for (const [key, value] of Object.entries(params)) {
    result = result.replace(`:${key}`, encodeURIComponent(value));
  }
  return result;
}

/**
 * Parse query string
 */
export function parseQuery(search: string): URLSearchParams {
  return new URLSearchParams(search);
}

/**
 * Build query string
 */
export function buildQuery(params: Record<string, string | number | boolean>): string {
  const searchParams = new URLSearchParams();
  for (const [key, value] of Object.entries(params)) {
    if (value !== undefined && value !== null) {
      searchParams.set(key, String(value));
    }
  }
  return searchParams.toString();
}

/**
 * Get current location info
 */
export function getCurrentLocation(): { path: string; query: URLSearchParams; hash: string } {
  // For hash-based routing (works in static files)
  const hash = window.location.hash.slice(1) || '/';
  const [path, queryString] = hash.split('?');
  const query = new URLSearchParams(queryString || '');
  const hashPart = '';

  return {
    path: path || '/',
    query,
    hash: hashPart,
  };
}

/**
 * Generate unique route key
 */
export function generateRouteKey(route: RouteDefinition, index: number): string {
  return `${route.path}-${index}`;
}
